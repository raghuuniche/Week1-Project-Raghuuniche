# Production backup and recovery policy — policy approved, launch blocked

## Status and launch gate

Investigation date: 2026-10-10. Deployment metadata reports no active published
app. The application uses managed `DATABASE_URL`; project instructions identify
it as Replit-managed PostgreSQL. Secret existence was checked without reading
credentials. No production database was queried, exported, restored or changed.

**The operator approved the ownership, provider-only storage and security policy
below, policy only.** Daily backups, 7-day retention, maximum 24-hour record loss
and 4-hour recovery remain approved targets, not verified guarantees.
No production backup mechanism has been implemented or verified by this work.
Real-data launch remains blocked until the actual production provider and target,
location suitability, security and retention obligations are confirmed, protection
is configured with explicit authorization, and recovery is verified.
Development checkpoints and
`scripts/rehearse-recovery.sh` do not satisfy this gate.

### Current prerequisite blocker

The operator confirmed this is a new application with no existing production
database and requested a quick proof of concept before production planning.
A fresh deployment metadata check also reports no active published app.
Actual provider-backup verification remains incomplete and deferred until a
production target exists and the required confirmations and target-specific
authorizations are supplied. No production setup, export, restore or cost
authorization was granted by that clarification; real-data launch remains blocked.

## Provider capabilities and limits

Official Replit documentation consulted on the investigation date:

- [Data recovery](https://docs.replit.com/features/data-and-storage/data-recovery):
  production point-in-time recovery (PITR) and daily scheduled full restore
  points. Core supports up to 7 days; Pro/Enterprise up to 28 days, with a
  default 7-day window. Scheduled backups require enabling a retention period.
- [Development and production](https://docs.replit.com/features/data-and-storage/development-and-production):
  publishing creates a separate production database. Current infrastructure is
  Helium; legacy databases may be Neon. Confirm the actual target in Database
  Settings rather than assuming either from development or secret presence.
- [Database](https://docs.replit.com/features/data-and-storage/sql-database):
  Database Settings and Monitoring provide operator management surfaces.

Daily scheduling uses the browser's UTC offset near midnight; daylight-saving
changes can shift it by an hour. Record the operator's time zone and actual UTC
schedule. Longer retention can increase usage costs; a plan downgrade can
reduce the window to 7 days.

These sources establish available features, not this app's enabled settings,
an independent off-site copy, a contractual recovery guarantee, or measured
RPO/RTO. Encryption algorithms, backup location, key management, transport
protection and who can restore must be confirmed for the actual production
service before accepting real records. Do not infer these from the ORM.

## Approval record — completed policy decisions, verification outstanding

Initially, the operator approved only the daily/7-day/24-hour-loss/4-hour-recovery
targets, supplied no owner designation and deferred independent-copy storage.
The subsequent explicit decisions supersede those open items: **Practice Director
or Manager** owns recovery and provides primary/alternate cover; **provider-only
backups** are approved. The operator approved the simple recovery/security rules
and a **provider-supported region, subject to legal suitability**, with no specific
geographic preference. All approvals remain policy only.

| Decision | Approved policy / outstanding verification |
| --- | --- |
| Accountable owner | Practice Director or Manager; owns risk acceptance, recovery authorization and validated reopening |
| Backup administration and incident cover | Primary: an authorized Practice Director or Manager. Alternate: another authorized Practice Director or Manager when the primary is unavailable. Confirm actual assignees and access in restricted operations records before launch |
| Escalation | Responsible Director/Manager handles missing/failed backups and incidents; another authorized Director/Manager covers absence. Contact provider support promptly if recovery is blocked or the 4-hour target is at risk; no additional hierarchy |
| Frequency | Daily backups approved as a policy target; provider scheduling and supplementary PITR await configuration approval |
| Retention | 7-day backup retention approved; proposed 7-day PITR window still requires configuration approval |
| Maximum acceptable record loss (RPO) | 24 hours approved as a target, not a verified guarantee; prove actual restore-point age meets it |
| Recovery-time objective (RTO) | 4 hours approved as a target, from incident declaration through validated reopening; not yet measured |
| Destination and region | Actual production database provider's managed backup storage, in a provider-supported region subject to legal suitability; no specific geographic preference. Confirm actual database and backup locations and applicable obligations before launch |
| Encryption and key management | Require provider-managed encryption at rest and protected transport, with provider-managed keys; actual encryption/transport and key-management evidence remains required before launch |
| Restricted access | Backup administration and restores restricted to authorized Practice Directors/Managers; verify effective permissions and provider controls before launch. General staff access does not authorize recovery |
| Independent/off-site copy | Not required under the approved provider-only policy; provider/account dependence accepted as a residual risk. No independent copy is claimed |
| Retention versus record obligations | Keep backups for 7 days; this is not business-record retention. Director/Manager must confirm applicable legal retention, deletion/hold and location obligations before launch; if incompatible, stop and obtain revised policy approval |
| Approval and production authorization | Ownership, provider-only storage, region rule, security, retention and residual risks approved as policy only; no authorization for publishing, configuration changes, exports, restores, deletion or costs |

Accepted residual risks: provider/account loss or a provider-wide incident may
prevent recovery; provider-managed keys do not give the practice independent key
custody or recovery capability. Seven-day backups cannot recover older lost
records. Missing/stale backups or a difficult restore can exceed the approved
24-hour loss or 4-hour recovery targets. Policy acceptance is not evidence that
these targets are met, nor acceptance of unverified legal or security suitability.
If an independent copy is required later, obtain separate approval for its
destination, region, encryption, keys, access, schedule, retention, costs and
verification before implementation.

### Simple operating responsibilities

The primary authorized Director/Manager checks backup freshness daily and leads
recovery; the alternate provides cover when unavailable. A missing, failed or
stale backup is handled when detected rather than waiting for the next daily
check. Contact provider support promptly if recovery is blocked or the 4-hour
target is at risk. Keep launch blocked (or maintain write suspension during
recovery) while required evidence or validation is missing.

The accountable Director/Manager reviews access, retention and location
suitability after provider/plan changes and approves actual record loss and
validated reopening. This is a role-based policy, not a new authorization feature
or a grant of application Administrator access. Record actual primary/alternate
assignments and contact channels outside Git before launch; do not invent
assignees or put personal contact details in this document.

## Operator setup procedure — only after target-specific authorization

1. Confirm the published app and its production database in Replit's Database
   tool. Record a non-secret target identifier, provider, region, plan, approved
   owner roles and incident contact path in a restricted operations record.
   Never copy a connection string into this document, logs or chat.
2. Obtain explicit authorization for the named target, retention, costs and
   configuration actions. Publishing is a separate authorized action, not a
   backup prerequisite this procedure may perform implicitly.
3. Select **Production → Settings**. Set the supported PITR window to the
   approved value. Under **Advanced → Scheduled backups**, choose the approved
   **Keep backups for** period to enable daily backups. Record the UTC schedule.
4. Confirm encryption/key management, storage location and operator-only access
   using provider evidence and actual account settings. Restrict collaborators,
   restore privileges and credentials. Store any required credentials only in
   the secure, intended environment; do not repurpose development credentials.
5. Observe the first successful scheduled restore point and a second subsequent
   daily point. Record their UTC times and confirm the gap and latest age are
   within the approved loss window. Verify PITR's earliest/latest available
   times separately. Settings alone are not proof of a successful backup.
6. Confirm the primary/alternate Director/Manager assignments and contact path
   implement the approved simple operating responsibilities above. Verify
   provider-support access and review retention/access/location after plan or
   provider changes. Keep real-data launch blocked for stale backups or missing
   evidence.

No startup, build, post-merge DDL, application bootstrap, production migration
script or synthetic-runner changes are required or authorized by this policy.

## Provider-specific recovery procedure

1. Declare an incident; start the recovery timer. The accountable operator
   authorizes the exact database and selected recovery point. Suspend writes
   through an approved maintenance method and inform affected staff.
2. Inspect available restore points; select a UTC point before corruption.
   Record the expected record-loss interval and obtain approval for that loss.
   Preserve the current state using an approved provider mechanism where
   available; do not assume a failed database can be exported safely.
3. Prefer an isolated provider-supported recovery target for a rehearsal.
   Confirm availability with the provider first; these cited docs do not promise
   a clone/restore-to-new-database option. If unavailable, arrange an explicitly
   approved maintenance-window drill with disposable non-real production data,
   never an unapproved switch of a live real-data database.
4. For scheduled backup recovery, open **Production → Settings → Advanced →
   Scheduled backups → View all backups**, choose the approved point's
   **Restore**, enter `restore` and choose **Continue**. This switches the active
   database to that point; connected services can reconnect briefly. The docs
   state the current data is not deleted, but establish how to switch back
   before treating that as a rollback guarantee.
5. For PITR, use the production database's point-in-time restore interface,
   inspect the available UTC range and choose the authorized timestamp. Follow
   the actual confirmation UI; stop if its target or effects differ from the
   approved procedure.
6. Validate schema compatibility and protected aggregate checks: organizations,
   practices, identity links, memberships, role grants and the singleton
   Administrator bootstrap audit. Confirm referential consistency, authorized
   practice access and denied cross-practice access without exposing records.
   Do not rerun bootstrap or schema push as a recovery step.
7. Database restore does not restore code. Confirm the deployed revision is
   compatible; any code rollback or republish needs separate approval and
   schema-diff review. Do not publish blindly onto restored data.
8. Reopen only after the owner accepts validation and actual record loss.
   Record elapsed time through reopening, compare with RTO, and document missed
   objectives. Maintain write suspension and escalate if checks fail.

## Evidence required before closing the launch gate

Keep the detailed evidence in operator-restricted storage, not Git:

- Policy approval, actual accountable owner and primary/alternate assignments,
  contact path and explicit target-specific action authorizations.
- Actual target/provider/region/plan and enabled retention/schedule settings.
- Database/backup location suitability and applicable retention, deletion/hold
  obligations; resolve any conflict with the approved 7-day backup window.
- Provider-managed encryption, transport, key management and restricted
  administration/restore access evidence for every backup copy.
- Successful daily backup timestamps and available PITR range.
- Authorized recovery-drill result, selected point, actual record-loss interval,
  measured end-to-end recovery time and integrity/access-check outcomes.
- Alert/escalation ownership, retention-expiry handling and provider-only risk
  acceptance, or verified independent-copy recovery if required.

Only a redacted pass/fail summary belongs in project documentation. No
credentials, practice records, identity details or decrypted backup archives
belong in the repository, workspace outputs or synthetic rehearsal directories.

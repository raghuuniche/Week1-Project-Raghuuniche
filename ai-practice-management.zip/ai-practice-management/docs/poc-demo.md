# Role-preview proof of concept

This is a development-only demonstration using synthetic consulting-practice
records. It is not a production system, real sign-in implementation, permission
administration feature, or verified production backup mechanism.

## Demo flow

1. Open Northstar and explicitly start the demo session.
2. Open the role demo. Use **Preview role** in the top-right corner to compare
   Executive, Practice Director, Manager, Team Member and Administrator views.
3. Explore the available screens for each role. Preview permissions affect
   synthetic browser data only; they never change the actual signed-in identity,
   practice memberships or Administrator grant.
4. As Director or Manager, add pipeline opportunities or import synthetic CSV
   or Excel `.xlsx` entries. Download the CSV template for the supported columns:
   `name,client,owner,stage,value,closeDate,probability`.
5. Review imported rows and any validation errors before confirming. Any errors
   must be corrected before committing the import. Duplicate opportunity
   name/client pairs in the current practice are skipped, not overwritten.
6. Compare dashboard/report totals after changes. Switch to Team Member to see
   the narrower assigned-work view; switch to Administrator to see the simulated
   access explanation rather than practice records.
7. End the demo to clear its tab-local data, or use the demo reset control after
   confirmation to start again with the synthetic examples.

## Import limits and storage

- Synthetic/test data only. Do not upload real client, staff or practice records.
- CSV and `.xlsx`, at most 5 MB and 1,000 nonempty data rows per import.
- Excel imports read the first worksheet. Save legacy `.xls` as `.xlsx` first.
- Use plain nonnegative numbers without currency symbols; probability is 0–100.
- Use valid `YYYY-MM-DD` dates or Excel date cells.
- The selected demo practice supplies scope, not a column in the file.
- Files are parsed in the browser; they are not uploaded to a backend or stored
  as archives. Demo records are stored only in this browser tab's session storage,
  not the application database. Reloading the tab preserves an active demo;
  ending the session clears its demo records. This is not durable shared storage
  or a backup.
- The PoC is gated by development mode and an active synthetic demo session.
  Production builds do not enable this role-preview surface.

## Production remains a separate decision

The owner requested a quick PoC before production planning. Real-data launch
remains blocked by the requirements in
[the production recovery policy](production-recovery-policy.md).
The [rollout decision plan](production-rollout-plan.md) is a conditional draft
for review after demo acceptance, not evidence of approval or launch readiness.
No production configuration, publishing, exports, restores, costs, startup DDL
or Administrator bootstrap changes are authorized by this PoC.

Parser checks: `pnpm --filter @workspace/scripts run test:pipeline-import`.

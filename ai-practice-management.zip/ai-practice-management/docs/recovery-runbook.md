# Foundation recovery rehearsal — operator runbook

The synthetic rehearsal now also preserves shared pipeline/delivery/goal rows
(including retained deletions and exact decimals), assignments and row versions,
business audit snapshots, import retry receipts and expired session metadata.
Snapshot comparison covers every field of these tables; restored scope and
assignment probes are additional checks, not real sign-in or provider recovery.
The migration ledger is tested by `check:business`; this rehearsal creates its
synthetic source with Drizzle rather than performing a real-target migration.
Passing this local rehearsal never clears the unverified provider recovery gate.

## Purpose and limits

Prove that a PostgreSQL custom archive can restore the committed foundation
schema, synthetic records, identity bindings, memberships, global Administrator
grant and singleton bootstrap audit into a **different, isolated database**.
This command is safe to run in a development workspace or a disposable staging
runner. It never connects to the workspace's database or any remote database.

This is not a production restore procedure, scheduled backup service, Microsoft
sign-in test, or permission-management feature. It does not establish a
production recovery-time objective (RTO) or recovery-point objective (RPO).
Small fixture timings are not estimates for a real database. Before real-data
launch, operators must separately approve backup ownership, retention,
encryption, off-site storage, acceptable record loss and recovery time, and
prove recovery of that approved backup mechanism. Do not use this command to
back up company data.

The separate [production policy draft](production-recovery-policy.md) records
provider capabilities, operator approvals and the real-data launch gate. It is
not proof that production backups have been enabled or recovery verified.

**Never wire this command into application startup, deployment, or post-merge
setup.** Those paths must remain free of schema changes and account bootstrap.
No schema change to the live foundation is needed.

## Prerequisites

- Locked dependencies installed (`pnpm install --frozen-lockfile`).
- Node.js 24, pnpm 10.26.1, and a non-root Unix operator.
- PostgreSQL 16 tools on PATH: `initdb`, `pg_ctl`, `createdb`, `pg_dump`,
  `pg_restore`; also Bash, `node`, `pnpm` and `truncate`.
- Writable private `/tmp` and `generated-artifacts/recovery/`; enough space for
  two fresh clusters and an archive.
- Development/staging runtime only, not `NODE_ENV=production` and not a
  deployment (`REPLIT_DEPLOYMENT` must be absent).

No credentials need to be supplied. The wrapper removes inherited `PG*`,
`*DATABASE_URL`, `BOOTSTRAP_*`, `SESSION_SECRET` and `RECOVERY_*` variables.
It creates its own environment-scoped local connection settings. Do not paste
connection strings into command arguments, chat, logs, documentation or Git.
If a future approved procedure needs remote credentials, use the workspace's
secure environment configuration, restricted to the intended environment; do
not alter this runner to accept remote targets.

## Run the rehearsal

From the repository root:

```sh
pnpm run rehearse:recovery
```

The wrapper:

1. Rejects production/deployment execution before opening any database.
2. Creates a mode-0700 temporary parent with an ownership marker and two
   independently initialized PostgreSQL clusters (`source` and `restore`).
   TCP is disabled. Local trust authentication works only through their private
   Unix sockets. Both use test-only role `recovery_fixture` and database
   `recovery_fixture_test`; their data directories and sockets are different.
3. Applies the current committed Drizzle schema **only to the fresh source**
   using the explicit test command. No database URL is accepted from the caller.
4. In an empty source, creates 2 synthetic organizations, 3 practices, 8 users,
   8 identity links, 7 memberships, 1 global grant and 1 bootstrap audit.
   Five users cover all five practice roles. Separate fixtures cover an
   Administrator without membership, an inactive membership and a disabled user.
   All identities use `https://recovery-fixture.invalid/tenant`, reserved for
   synthetic data; no real Entra tenant/object ID or bootstrap command is used.
5. Checks the source's relationships, boundaries and constraints; writes a
   full-row JSON manifest with exact identifiers, values and timestamps.
6. Creates `foundation.dump` with `pg_dump --format=custom --no-owner
   --no-privileges` and seals its SHA-256 in the manifest. Only the synthetic
   foundation tables may exist in `public`.
7. **Stops the source.** Verifies the sealed archive hash and that the separate
   restore target contains no objects in `public`.
8. Uses `pg_restore --exit-on-error --single-transaction --no-owner
   --no-privileges` to reconstruct schema and data. It does not use `--clean`,
   `DROP`, an existing live schema, or an application account-bootstrap command.
9. Verifies same PostgreSQL version, every restored row against the source
   manifest, relational bindings, access boundaries, and 13 constraint probes.
   Probe writes are rolled back.
10. Stops both owned clusters and removes only its own temporary directory.
    A cleanup failure makes the command fail, rather than reporting success.

The separate clusters use private sockets on internal port 25433, not TCP port
25433. Concurrent rehearsals have different directories and do not share
targets. No existing service is reused or stopped.

## What PASS verifies

- All record counts and **all field values**, including timestamps, match.
- Practices still belong to the expected organization.
- Each assigned user retains their exact role in the assigned practice.
- No assigned user gains access to an unassigned practice, including another
  organization's practice; executives get no implicit cross-practice access.
- Global Administrator access stays separate from practice membership.
- Inactive memberships, disabled users, unknown subjects and wrong issuers
  remain denied.
- The only synthetic global grant maps to the intended identity. The singleton
  audit still maps to that same user, grant, issuer, subject and operator.
- Identity and membership uniqueness, all foundation foreign-key paths,
  role/status checks, audit singleton/repeat protection and Administrator
  deletion restriction still reject invalid writes with the expected SQLSTATE.

Boundary verification uses database joins matching the current foundation's
active user / exact issuer-subject / active exact-practice membership rules.
It does **not** claim to exercise an HTTP session, real SSO or the application's
authentication adapter. Run `pnpm run check:foundation` separately for the
existing API/session/browser gate.

## Read the evidence

Each execution prints a unique path:
`generated-artifacts/recovery/run-<UTC timestamp>-<random>/`.
These files are excluded from Git and deployment and created under a private
umask. Retain the desired synthetic evidence using your approved operator
storage, not a Git commit.

| File | Meaning |
| --- | --- |
| `status` | `PASS` only after verification **and cleanup**; otherwise `FAIL`. |
| `cleanup-status` | `PASS` only when both owned clusters were stopped; CI rejects failed cleanup even for expected corruption. |
| `failure.json` | Structured synthetic-only failure code and phase for the three known corruption assertions; unrelated errors do not receive these codes. |
| `foundation.dump` | Synthetic PostgreSQL custom archive. |
| `manifest.json` | Expected full records, source version and archive SHA-256. |
| `verification.json` | Passed checks, counts, timestamp and archive hash. |
| `rollback-verification.json` | Only for `restore-transaction`: valid archive seal, expected post-data restore error, and an empty target after rollback. |
| `timing.json` | Preparation/backup and restore/verify elapsed seconds. |
| `source.log`, `restore.log` | Private cluster initialization/start/stop logs. |
| `schema.log`, `restore-command.log` | Explicit source schema application and restore diagnostics. |

Require exit code 0 **and** `status=PASS`. A verification file alone is not
proof of success if cleanup subsequently failed. Never treat a previous run's
evidence as the current run.

## Confirm failures are detected

Each command below creates new disposable targets, deliberately damages only
synthetic data or its archive, and **must exit nonzero**:

```sh
pnpm run rehearse:recovery --fault=archive
pnpm run rehearse:recovery --fault=membership
pnpm run rehearse:recovery --fault=audit
```

Expected failures:

- `archive`: sealed SHA-256 differs after archive truncation; restore is blocked.
- `membership`: an inactive membership is improperly activated after restore;
  the denied-user assertion fails.
- `audit`: the restored audit subject is changed; the grant/audit/identity
  binding assertion fails.

Also verify that `NODE_ENV=production pnpm run rehearse:recovery` and
`REPLIT_DEPLOYMENT=1 pnpm run rehearse:recovery` are rejected before any cluster
creation. Unknown options or extra arguments fail; there is no target-URL flag.
Run the unmodified command again to obtain fresh PASS evidence.

### Confirm failed restores leave no partial records

```sh
pnpm run rehearse:recovery --fault=restore-transaction
```

This additional synthetic scenario is separate from the three corruption
expectations above. It must return **0** and write `status=PASS` and
`cleanup-status=PASS` only after observing the intended `pg_restore` exit **1**
and proving complete rollback. Unexpected restore success or a different error,
remaining objects/records, or failed owned-cluster cleanup fails the rehearsal.

After the normal source fixture checks, it creates a test-only immutable UUID
function and a unique expression index on synthetic users. It then deliberately
replaces that function with one returning a constant UUID, without rebuilding
the existing index. This controlled inconsistency exists only in the disposable
source; it is never applied to the committed application schema or a live target.
`pg_dump` archives the final function and index definition and seals the actual
archive hash as usual. Preflight confirms the seal is valid, the source is stopped,
and the restore database is empty.

Verbose restore evidence must show all seven foundation tables' data processed
before rebuilding `recovery_restore_transaction_unique` fails with the expected
duplicate constant UUID. With `--exit-on-error --single-transaction`, this
post-data error rolls back the earlier schema and data writes. A fresh, owned
restore connection checks every non-system schema: only the original empty
`public` remains, with zero relations (including indexes/sequences), functions,
types and constraints. With no user relations, no partial records can remain.
The archive seal is checked again before writing `rollback-verification.json`;
`verification.json` is not written, because restoration did not succeed.
The exit trap must still stop the owned clusters and remove their temporary
directory before a PASS status is written.

This proves rollback for this controlled PostgreSQL 16 post-data failure, not
every possible archive failure, interruption, or production recovery mechanism.
The archive-truncation scenario still proves rejection **before** restoration
and does not itself demonstrate transactional rollback.

## Required CI branch check

The independent **Recovery gate** job in `.github/workflows/foundation.yml`
runs on every pull request and push to `main`/`master`, and can be started
manually. There are deliberately no path filters: changes to schema, fixtures,
scripts or locked dependencies cannot bypass recovery validation. The job has
no dependency on the Foundation gate, dependency scanning, Microsoft sign-in
or membership-management work.

After its first GitHub run, repository administrators must require the exact
status check **Recovery gate** in branch protection/rulesets for the protected
merge branch. Keep **Foundation gate** required separately. Adding the workflow
does not configure GitHub branch protection automatically.

To reproduce that job locally:

```sh
pnpm --filter @workspace/scripts run test:recovery-ci
pnpm --filter @workspace/scripts run test:recovery-safety
pnpm --filter @workspace/scripts run test:recovery-cleanup
pnpm run check:recovery
```

`test:recovery-safety` uses only disposable synthetic directories, inert command
spies and a blocked PostgreSQL client. It checks production/deployment rejection,
unknown or extra arguments, PostgreSQL 15/17 tool rejection, and missing or invalid
ownership markers. It requires the expected rejection reason and proves no
cluster creation, schema command, database connection or evidence write occurs.
Positive controls confirm valid invocations reach the inert boundary, without
starting a database. This is guard regression coverage, not real backup verification.

`test:recovery-cleanup` also injects synchronous `pg_dump` exits 1 and 74 after
writing a nonempty inert partial archive. It runs the actual shell wrapper with
only controlled command spies on PATH and no inherited credentials or real
database processes. The checks require seed and backup to run, but sealing,
preflight, restore and verification never to run; status must be `FAIL`, both
owned synthetic cluster markers must be stopped, and their temporary directory
must be removed with `cleanup-status=PASS`. A successful control proves the same
spies can reach sealing, preflight and restore without the injected failure.
Private call logs, console logs and partial-archive evidence remain under
`generated-artifacts/recovery/backup-command-test-*/`. The partial archive is
deliberately invalid and must never be used for recovery. This tests backup
command failure, separately from interrupted cleanup, sealed-archive corruption
and valid-seal transactional restore rollback.

`check:recovery` calls `pnpm run rehearse:recovery` five times with fresh source
and restore clusters each time: normal, archive, membership, audit and
restore-transaction. All
PostgreSQL tools and both servers must be major version 16. It never supplies
production credentials, real records, an existing target URL or bootstrap.
CI disables package-installation creation of a default cluster before installing
PostgreSQL 16. The runner never connects to or modifies any pre-existing system
service, using only its own private Unix sockets.

The normal run must return 0, write `status=PASS`, pass verification with the
source stopped, and clean up successfully. Negative runs must return exactly
1, write a failed status, clean up successfully, and produce the following
structured reason at the expected phase:

| Scenario | Phase | Required failure code |
| --- | --- | --- |
| Archive truncation | `preflight` | `ARCHIVE_INTEGRITY_MISMATCH` |
| Inactive membership activated | `verify` | `INACTIVE_MEMBERSHIP_ALLOWED` |
| Audit subject changed | `verify` | `AUDIT_IDENTITY_BINDING_BROKEN` |

The additional `restore-transaction` scenario must return 0 with successful
cleanup and rollback evidence confirming a valid seal, source stopped, the
specific expected restore error with exit 1, and no remaining schema or data.
It must not produce successful-restoration evidence or a corruption failure code.

An unexpected success, missing tools, process timeout, schema failure, unrelated
assertion, missing evidence or failed cleanup fails the overall gate. The suite
continues through all five scenarios to collect diagnostics, with a private
`ci-*/summary.json` and per-scenario console logs under the ignored evidence
directory.

Only on a failed job **in a private GitHub repository**, CI uploads
`generated-artifacts/recovery/` as `recovery-synthetic-evidence-<run>-<attempt>`,
retained for **one day** and limited to people with repository artifact access.
It does not upload unrelated diagnostics, hidden files, secrets or real data.
Local files are mode 0600 under private directories. GitHub artifacts do not
preserve Unix permission bits; repository access, not file modes, protects
downloaded evidence. If the repository is public, upload is skipped to avoid
publishing even synthetic archives; use a private repository for retained CI
evidence. Do not copy real backups into this directory or publish these
artifacts elsewhere. Successful and expected-fault runs are not uploaded when
the overall job passes.

## Troubleshooting and cleanup

- Missing tools/dependencies: install the prerequisites in the development
  runner, then retry. Do not fall back to a remote database.
- Schema/seed/restore/verification failure: inspect that run's private logs and
  `status`. Fix the schema or runner deliberately, then rerun into new clusters.
  Do not bypass assertions or restore over an existing database.
- Termination: normal errors, SIGINT and SIGTERM trigger cleanup. Power loss or
  SIGKILL cannot run a shell trap. If a temporary directory remains, inspect
  its ownership, `owner-marker`, `source/pg/postmaster.pid` and
  `restore/pg/postmaster.pid`. Stop only those owned clusters with
  `pg_ctl -D <owned directory>/source/pg -m immediate -w stop` (and `restore`).
  Remove that exact temporary parent only after both servers stop. Never use
  broad database cleanup commands or delete a directory belonging to another
  run. A cleanup failure preserves the directory and reports failure.
- Disk space: archives/evidence intentionally remain after cluster cleanup.
  After retaining needed synthetic evidence, remove only the selected
  `generated-artifacts/recovery/run-*` directory.

## Verified rehearsal

On 2026-10-10, PostgreSQL 16.10 in the development workspace successfully
restored the fixtures into the second cluster with the source stopped. Full-row
equality, all five roles, denial boundaries, grant/audit binding and all 13
constraint probes passed. The archive, inactive-membership and audit corruption
checks were also run and rejected; production and deployment runtime guards
rejected execution. The additional valid-seal `restore-transaction` scenario
also failed at the intended post-data unique index, left the separate restore
database empty after rollback, and stopped and removed both owned clusters.
This verifies the rehearsal mechanism, not production backup coverage.

# Shared first-release workspace — implementation handoff

## Authorization and readiness

The owner accepted the demonstrated role PoC and commissioned shared pipeline,
delivery, goals and scoped dashboards/reports. Additional spending is forbidden;
development stays within included Pro credits. No production target, publishing,
real-data import/migration, paid service or provider configuration was authorized.
Operational metrics examples, practice currencies/time zones, legal
retention/deletion/holds/location, cohort and named operators still require owner
sign-off before a real-data pilot. Recovery remains unverified; launch is blocked.

The main Preview remains the synthetic role demo. Shared screens are under
`/workspace` and require a verified provider session; a demo session is never
upgraded to a real identity. Production builds remove demo routes/assets/seeds
and the role picker. Business state never falls back to local/session storage.

## Identity and membership coordination

The existing Microsoft company sign-in work supplies the verified adapter using
`createApp`'s adapter seam, after session middleware in Entra mode. Preserve
issuer + tenant-stable immutable subject bindings, rotate/save the session after
verification, and do not trust arbitrary request headers/email/role selections.
The normal server provides no test login route and no Entra impersonation path.
Provider sessions use PostgreSQL, hashed session IDs and fixed expiration, with
revocation by logout. Demo memory sessions stay development-only.

Existing Administrator membership work owns entitlement-management screens/API
and attributable permission-change history. It must preserve active membership
and verified identity constraints and use transaction-safe changes; business
writes hold user/membership locks so a simultaneous revocation cannot authorize
a write after revocation commits. Global Administrator grants confer no business
access. No duplicate SSO or Administrator provisioning feature was added here.

## Implemented workflows and contracts

- Director: practice-scoped pipeline, delivery and goal create/edit/retained
  delete; pipeline import. Manager: pipeline create/edit/retained delete/import,
  delivery create/edit, read goals/reports; no goal edits or delivery deletion.
- Executive: read-only authorized practices, including aggregate totals across
  explicit Executive memberships grouped by currency and reporting time zone.
- Team Member: own assigned delivery/goals only, own delivery-status updates;
  other assignments, pipeline and aggregate reports denied at the API.
  Financial/client fields are omitted, not just visually hidden.
- Every business request resolves active server-owned user/identity/membership.
  Writes derive organization/practice from access, never from an input role or
  scope. Assignments require a verified active member in the selected practice.
- Money/goal quantities use decimal strings and numeric(16,2), not floating
  arithmetic. Weighted pipeline rounds half-up once after summation. Open
  pipeline excludes Won/Lost. Closed values and delivery budget are not revenue.
  Calendar dates are `YYYY-MM-DD`; report filters are inclusive on close/end/due
  dates. No exchange-rate conversion or mixed-currency aggregate is performed.
- CSV or first XLSX worksheet imports preserve exact decimal source values,
  verify owner UUIDs, preview invalid rows/duplicates, use 5 MB/1,000-row limits
  and commit nothing if any row fails validation. Duplicate keys are per-practice
  NFKC/trim/whitespace-collapse/lowercase name + client, protected by a partial
  unique constraint. Existing records are skipped, not overwritten.
- Confirmation uses a UUID receipt key scoped to practice and actor plus a
  validated-payload hash. Same-payload retries replay the committed result;
  changed payload with that key conflicts. Receipt, all inserts and audits share
  a transaction. Concurrent direct entries cannot bypass uniqueness.
- Edits/status changes/deletions require the last-read row version. Conflict
  responses preserve drafts; explicit reload is required. Confirmed deletion
  retains record/history, excluding the row from active lists/totals.
- Auth/scope/query failures hide protected cached rows. Session changes clear
  caches; practice changes discard dialogs/drafts. Save failures remain visible
  and do not pretend local data was saved. Polling updates other sessions.
- Audit snapshots/actor IDs are retained in restricted server tables; no audit
  browse/export route or automatic purge is exposed. Sensitive row payloads are
  never logged. Legal holds and destruction policies are not inferred from
  seven-day backup retention.

## Schema deployment compatibility

See `lib/db/migrations/README.md`. SQL baseline and additive migration are
versioned and tested only in new disposable clusters. No startup, build,
post-merge or main-workflow schema application occurs. A named target must first
be separately approved, reconciled and backed up. Apply compatible additive
schema before enabling the new adapter/workspace; older foundation code can
continue with the added tables. Do not drop data to roll back application code.
The workspace database has intentionally not been migrated or seeded.

## Synthetic evidence and repeatable verification

Current local outcomes: shared-data gate passed (18 API assertions/subtests),
foundation gate passed (types, builds, desktop/mobile session journeys), import
parser regression passed (8 tests), and all five recovery gate scenarios matched
their required outcome/cleanup. These are synthetic development results only.

- `pnpm run check:business`: SQL baseline + incremental migration on a fresh,
  private loopback cluster; typechecks and API tests. Proven: spoofing/demo and
  Administrator denial, practice/organization/assignment boundaries, field
  omission, role writes, CSRF denial, validation, concurrent version conflicts,
  attributable retained history, atomic invalid import rollback, concurrent
  retries and entry/import uniqueness, scoped exact date/currency summaries.
  Two independent signed database sessions read committed rows after actual
  API process termination/restart; revocation, disabled users, logout and
  expiration reject subsequent access. No external provider sign-in claimed.
- The isolated browser fixture verified provider-session workspace loading,
  opening a record form, and same-context identity switching to an Administrator
  clearing old practice data. It is test-only, loopback-bound and database-guarded;
  neither product server nor production build imports the test sign-in route.
- `pnpm run check:foundation`: foundation regression, builds, demo exclusion and
  existing desktop/mobile demo-entry checks. Demo checks use a development
  frontend; a production build must never offer demo entry.
- `pnpm --filter @workspace/scripts run test:pipeline-import`: parser regression.
- `pnpm run check:recovery`: isolated source-stop/archive/restore verification
  now includes synthetic business data, audits, receipts and expired session
  metadata. Local results do not establish approved provider backup recovery.

Generated logs/screenshots remain ignored under `generated-artifacts`. No
real practice/client/staff data, provider credentials or paid integrations were
used. Remaining company sign-in/membership work, pilot source reconciliation,
legal/operational sign-offs and approved-target backup recovery must precede
pilot/launch; this handoff is not a go-live approval.

# Northstar production rollout decision plan

Prepared 2026-10-10. **Draft for owner approval; not launch authorization.**

### Subsequent owner decision — 2026-10-10

The owner confirmed that the demo works in a separate browser tab and then
stated: “lets approve the demo version and move forward”. This records G0
acceptance and commissioning of the first-release workflow scope: shared
pipeline, delivery, goals, scoped dashboards and reports with demonstrated
role behavior. No additional spending is authorized; work must stay within
the owner's Pro plan credits.

This does not approve production targets, publishing, real-data migration,
identity-provider changes or backup actions. Remaining G1 operational decisions
(currency/time-zone examples, legal retention/holds, pilot cohort and operators)
must be confirmed before pilot use. Development implementation retains records
on deletion, does not purge history, uses calendar-only inclusive report dates,
and never combines different currencies. Recovery remains unverified and launch
blocked. Later sections' pending statements describe the original decision pack;
this record supersedes them only for demo acceptance and implementation scope.

## 1. Decision and current status

The owner requested a quick role proof of concept before production planning.
This document is a conditional decision pack, not evidence that the demo has
been accepted. No recorded demo acceptance was found in the project context.
Review [the demo walkthrough](poc-demo.md) first; record acceptance or required
changes before commissioning production implementation.

The foundation and synthetic role demo exist. Real business records are not
backed by shared business tables; Microsoft company sign-in is deferred, and
Administrator membership management is separate work. The
[recovery policy](production-recovery-policy.md) reports no existing production
database or active published app as of its investigation. This plan does not
independently inspect deployment metadata or any database.

**Actual provider-backup verification is unverified. Real-data launch is blocked.**
Policy approval, development checkpoints, disposable recovery rehearsals and
passing demo tests cannot close that gate.

This planning task authorizes no publishing, production database creation,
configuration, migrations, exports, restores, deletion, purchases or costs.
Approval of this document must not be treated as permission for those actions.
The owner must separately authorize each named target and action.

## 2. Agreed demonstration scope and production decisions

The agreed PoC covers role views, entry, dashboards/reports and CSV/Excel
pipeline import. The behaviors below describe the current demonstration and
propose the first production release; they are **not an approved production
permission specification**. The owner and accountable Director/Manager must
confirm them at demo acceptance.

| Workflow | Demonstrated behavior / proposed first release | Production acceptance decision |
| --- | --- | --- |
| Executive oversight | Read-only pipeline, delivery, goals, dashboards and aggregate reports across permitted practices | Define explicit organization/practice entitlements; never interpret Executive as unrestricted access to every organization |
| Practice Director | Select permitted practice; create/edit/delete/import opportunities, manage delivery and create/edit goals | Confirm practice scope and deletion/hold rules; practice selection must not grant membership |
| Manager | Practice-scoped opportunity entry/import and delivery management; read goals and reports | Confirm whether goals remain Director-write-only and whether Managers may delete delivery records |
| Team Member | Own assigned delivery and goals; update own delivery status; no financial pipeline or aggregate reports | Confirm assignment visibility and permitted status transitions; deny other staff's records and financial fields at the API |
| Administrator | Demo explains access only, with no practice records or real grants | Separate membership-management work defines permitted administration; identity or a global Administrator grant alone grants no practice access |
| Pipeline import | Director/Manager preview CSV or first `.xlsx` worksheet, fix all errors, then confirm; duplicate name/client within practice skipped, not overwritten | Retain 5 MB/1,000-row pilot limits unless approved otherwise; define normalized duplicate keys and concurrent/retry behavior before production |
| Dashboards/reports | Scoped pipeline, delivery and goal summaries respond to synthetic edits | Agree metric definitions, currency, rounding, reporting date range and time zone; reconcile totals with source records |

Demo pipeline columns are `name,client,owner,stage,value,closeDate,probability`.
The selected practice supplies scope; input cannot choose a different practice.
Dates use `YYYY-MM-DD` or Excel dates, values are nonnegative, and probabilities
are 0–100. Production must resolve owners to verified staff identities, not
accept display names as identity or access authority.

Initial metric proposals: open pipeline excludes Won/Lost; weighted value is
the sum of open value × probability/100; Won and Lost totals remain separate.
Delivery risk counts At risk/Off track records. These are planning proposals
based on the demo, not accounting revenue recognition or an agreed financial
reporting standard. Confirm treatment of currency, close-date boundaries, burn,
completed work and goal progress before staff rely on totals.

First release should stay within pipeline, delivery, goals, scoped dashboards
and reports. Skills/certifications, library, meetings/actions, AI capability
records, automatic AI processing and summary exports are not implicitly included.
Weekly/monthly sharing already has separate proposed work. No AI service or
third-party data transfer is budgeted or authorized here.

## 3. Durable shared-data requirements

Keep the approved React/TypeScript/Vite, Express, PostgreSQL/Drizzle modular
monolith. Do not replace the database or restore `.migration-backup/` wholesale.
Production business work requires:

- Server-owned organizations, practices, verified staff/identity references,
  assignments, opportunities, projects and goals. Business rows carry enforced
  organization/practice scope and referential integrity.
- Shared database reads and writes through authenticated APIs. A save succeeds
  only after the server commits; show explicit failures without pretending a
  browser-local fallback succeeded.
- Durable real-auth sessions independent of process memory; restart, multiple
  app instances and different devices must not lose committed business data.
  Demo session memory is not the production session design.
- Server-side permission checks on lists, individual records, totals, writes,
  imports and administration. UI filtering is not authorization. No financial
  fields in responses to Team Members lacking financial access.
- Validation, fixed-precision monetary storage, approved currency/date semantics
  and database constraints. Do not equate project budget or Won pipeline with
  booked revenue without an agreed rule.
- Atomic import confirmation with repeat/retry protection; concurrent imports
  cannot bypass duplicate checks. Editing needs conflict detection so one user
  does not silently overwrite another's newer work.
- Attributable change history for material writes, imports, permission changes
  and approved deletions, with access and retention defined by the owner.
  Do not place sensitive payloads in application logs.
- Versioned, reviewed schema changes and a code/schema compatibility plan.
  No startup-time, build-time or post-merge production DDL; approve target-specific
  migration execution separately.
- Confirm business-record retention, deletion/hold and location obligations.
  Seven-day backup retention is not record retention.

Acceptance must prove shared state using two authorized sessions/devices and an
app restart, not just refresh the same demo tab. Recovery checks must extend to
new business tables as well as the existing identity/membership foundation.

## 4. Demo-to-production separation

The demo remains development-only, uses synthetic browser-tab session storage,
and provides no real identity, membership or Administrator grant. Ending it
clears tab-local records. Production must not expose the role picker, synthetic
seed data, demo reset, demo entry or demo authentication fallback.

Use synthetic fixtures for development and pre-launch verification. No client,
staff or practice records should enter the demo, repository, mockup sandbox,
build outputs or recovery-rehearsal directories. Do not migrate demo state into
production or automatically copy development seeds into the production target.
Inspect any future provisioning/data-copy behavior before authorizing it.

Production credentials, sessions and permitted callback origins must be
environment-specific. Company SSO must bind verified approved-tenant identities,
not email guesses; a role preview must never alter the signed-in identity.
The global Administrator bootstrap remains an explicitly authorized operator
procedure, not a demo control or public endpoint.

## 5. Data onboarding and controlled pilot

These are future steps, not actions to run under this planning task:

1. **Inventory and consent:** Director/Manager identifies source systems,
   practices, record counts, currencies, reporting time zone and legal retention,
   deletion/hold and location requirements. Owner approves the minimum dataset
   and authorized pilot users. Keep identities and contact details outside Git.
2. **Mapping:** Establish organization/practice IDs and verified staff references,
   supported stages/statuses, ownership and assignment rules. Resolve ambiguous
   names, duplicate clients/opportunities and invalid dates before import.
   Proposed default is manual onboarding of projects/goals; only pipeline has a
   demonstrated import. Broader import tooling needs its own approved scope.
3. **Synthetic dry run:** Validate mappings, error handling, totals, duplicate
   retries, limits and practice scoping with representative synthetic files.
   The browser PoC parser is not a production ingestion endpoint.
4. **Protection first:** Only after separate target setup authorization, confirm
   production security, named primary/alternate operators and verified provider
   recovery. Do not load real onboarding records to obtain backup evidence.
5. **Authorized real-data load:** Following the real-data gate, stage the approved
   source in restricted storage, preview/reconcile it, and obtain Director/Manager
   confirmation before committing. Never store source files or row-level evidence
   in Git. File retention/disposal follows the approved legal policy.
6. **Reconcile and release:** Compare source/accepted/rejected/duplicate counts,
   values by practice and stage, assignments and dashboard totals. Resolve every
   discrepancy; retain restricted evidence and a redacted pass/fail summary.
   Start with one approved practice and a small named cohort, then expand only
   after owner acceptance. Pilot duration/cohort are decisions, not set facts.

Before loading, agree a failed-import cancellation/correction procedure.
After loading, suspend writes on integrity/access failure, preserve evidence,
and let the authorized Director/Manager approve corrective action. Do not
automatically delete records or restore the live database to undo onboarding.

### 5.1 Readiness and evidence boundary

The following prepared workflow and checked examples are **synthetic only**.
Demo acceptance/first-release development approval is recorded above; named
production scope, operational currency/time-zone examples, pilot cohort, legal
decisions and verified provider recovery remain pending. A passing rehearsal is
neither real identity approval nor permission to access, export, load, delete,
restore, publish or incur costs. Obtain additional authorization identifying the
target, practice, dataset, operator and exact action, with verified recovery,
before any real-data step. Never use real onboarding data to verify recovery.

Keep actual source files, identity/contact lists, reviewer names and row-level
evidence in approved restricted storage **outside the repository and generated
build/test directories**. Ignoring a local file in Git is not secure storage.
Only invented fixtures and redacted pass/fail evidence belong here. Do not
include credentials, source hashes that disclose sensitive content, or contacts
in public logs. Retention/disposal and legal holds require their existing
separate decision; no automatic purge or deletion is proposed.

### 5.2 Approved mapping register (restricted template)

Create a versioned register before staging even one real record. The accountable
Director/Manager reviews business meaning; the identity/membership operator
confirms identity and effective scope using the existing access process.
Neither a display name, email match nor a role preview proves identity.

| Register item | Required evidence and rule |
| --- | --- |
| Batch and revision | Restricted source reference, immutable source version, sheet/count inventory, mapping revision, selected target practice, reviewer and decision time; an amended batch must not reuse prior approval |
| Organization/practice | Source practice key → approved server organization/practice IDs; one selected authorized practice per confirmation; no source-supplied practice column can change scope |
| Staff/assignment | Source owner key → verified active server user UUID with active membership in the selected practice; preserve approved tenant-stable identity binding, not display-name matching; unknown, ambiguous, disabled or out-of-practice owners are blocking exceptions |
| Currency | Approved practice currency; source values must match it. No implicit conversion or summing different currencies. No currency column exists in the supported pipeline template: currency agreement is a staging prerequisite |
| Dates/time zone | Approved practice reporting time zone and calendar interpretation; exact valid `YYYY-MM-DD` close/end/due dates, inclusive period bounds. Translate an approved Excel date cell via the existing parser. Ambiguous local dates/timestamps require a documented source correction, not a guessed timezone conversion |
| Monetary values | Nonnegative plain decimal strings, no symbols/group separators, at most two fractional digits within numeric(16,2). Do not silently round excess precision. Weighted open value is rounded half-up once after summation, not per row |
| Stages/statuses | Explicit source-to-target dictionary: Qualification, Discovery, Proposal, Negotiation, Won, Lost; delivery On track, At risk, Off track, Complete; goals retain current/positive target/unit. Unsupported labels require correction, never a guessed default |
| Duplicate decisions | Per-practice NFKC, trim, whitespace-collapse and lowercase of opportunity name + client. Record exact source row and existing/same-file counterpart. Skip without overwrite. Different owner/value/stage/date/probability on that key is a business conflict: resolve or explicitly approve exclusion with evidence before proceeding |
| Effective permission | Director/Manager may confirm pipeline; Manager cannot write goals or delete delivery; Team Member/Executive/Administrator do not gain import rights. Register mappings do not grant membership or bypass server checks |

Pipeline uses the [PoC limits](poc-demo.md): CSV or first `.xlsx` worksheet,
maximum 5 MB and 1,000 nonempty data rows, columns
`name,client,owner,stage,value,closeDate,probability`. Inventory all workbook
sheets; move approved rows to the first sheet or explicitly exclude other
sheets with review. Do not quietly drop them. Legacy `.xls` requires approved
conversion to `.xlsx`. `owner` in a shared-workspace file must resolve to a
verified UUID, not the demo's free-text alias; `closeDate` maps to server
`dueDate`. Export-style practice/currency columns are unsupported.
The browser parser is not a backend ingestion endpoint.

Projects/delivery and goals remain **proposed manual onboarding**, not bulk
pipeline imports. Do not disguise them as opportunities. For each approved
manual entry, record source reference, target ID/version, practice, verified
assignee, date and status or goal quantities. Reconcile entry counts, assignment
counts, delivery budget/burn and At risk/Off track counts, and goal current/
target/unit/met counts separately. Budget, burn and Won pipeline are not booked
revenue. Broader import tooling requires separate scope approval.

### 5.3 Reconciliation worksheet and acceptance rules

1. **Freeze the source and baseline:** record nonempty source-row count and
   scoped active-record baseline at the same cutoff (exclude retained deletions).
   Reconcile each practice separately; record currency, time zone, date window
   and stage/status/unit definitions. Assign unique source-row references.
2. **Classify every row:** exactly one of accepted-for-preview, rejected, or
   duplicate-skipped. Keep error reasons and counterpart references. Counts
   obey `source = accepted + rejected + duplicate`. Blank lines are not data
   rows; an unparseable file or amount is an unresolved source exception, not
   zero rows/value. No unexplained exclusions are allowed.
3. **Bridge values before confirmation:** for each source practice, currency
   and stage, prove `source value = accepted value + rejected value + duplicate
   value`. Keep rejected source currencies/practices visible rather than
   silently remapping them. Also record accepted target practice/stage/assignee
   counts after mapping. Monetary bridge totals are unweighted; weighted
   dashboard totals are a separate calculation.
4. **Block on errors:** any rejected row, unresolved duplicate conflict,
   assignment mismatch, count difference or value difference blocks the
   *entire* confirmation, even if other rows are eligible. Accepted preview
   count is not inserted count. All-duplicate previews commit nothing.
5. **Review:** the named accountable Director/Manager checks the register,
   exception decisions, source bridge, proposed target rows, baseline and
   expected report totals. Record role, effective practice access, exact
   revision, date/time, decision, discrepancy count, correction owner and
   due date. A reviewer outside the selected practice cannot approve it.
   Approval requires zero unresolved discrepancies and explicit approval of
   every exclusion; Engineering records technical checks, not business consent.
6. **Commit only under separate authorization:** reconfirm source/register
   revision and current scope. Persist the server confirmation receipt/key.
   A same-key/same-payload retry replays the receipt, not a new insertion;
   changed payload must use a new key after fresh review, never bypass a conflict.
   Unexpected response/timeout means unknown outcome: retrieve the original
   receipt before attempting another load.
7. **Reconcile saved state:** compare receipt inserted/skipped counts to preview.
   Concurrency may increase skips; investigate rather than equating preview
   accepted count with insertion. With no other writes, `active after = active
   before + inserted`; scope/stage values and assignments equal the baseline
   plus actual inserted rows. If writes occurred, reconcile attributable
   changes at the cutoff before approval. Review full-period and agreed
   date-filtered dashboard/report totals, never an organization-wide mixed-
   currency grand total. Manual entries get equivalent before/after checks.
8. **Release:** Director/Manager signs the reconciled saved-state revision;
   product owner accepts the named cohort/go-no-go. Store restricted evidence
   and only a redacted result in Git. Approval simulation below does not satisfy
   these real operational sign-offs.

### 5.4 Correction handling

| State/problem | Required response |
| --- | --- |
| Invalid preview or mapping | Cancel without committing. Preserve original source, row dispositions and errors; assign a correction owner. Correct the source/register into a new revision, state reason and old/new disposition, rerun all reconciliation checks and obtain fresh review |
| Duplicate with conflicting content | Do not overwrite via re-import. Director/Manager chooses documented source correction, justified exclusion, or separately approved version-aware edit of the existing record. Preserve the counterpart and both values; no unresolved conflict may pass |
| Changed file/practice/staff or stale approval | Invalidate preview and review; re-resolve current access/mappings and start a new revision. Old sign-off never covers new data |
| Interrupted confirmation/retry | Preserve original key/payload reference and inspect receipt/saved state. No new-key blind retry. Replayed receipt is evidence of the same operation, not added rows |
| Post-commit discrepancy/integrity or access failure | Suspend affected writes/pilot release, preserve restricted source, receipts and audit evidence, notify accountable Director/Manager and alternate. No automatic deletion/restore or data patch. Require a separately authorized correction plan, named records/target, expected versions and verified recovery |
| Authorized correction completed | Reconcile baseline, change history and all scoped totals/assignments again; Director/Manager records reopening approval and owner records renewed go/no-go. Recovery policy governs any separately authorized recovery, not this ledger |

### 5.5 Repeatable synthetic evidence and coordination

Run `pnpm --filter @workspace/scripts run test:onboarding-reconciliation`.
The pure ledger rehearsal has no file-upload, database, network, environment,
production-target or load path. Its mapping IDs and reviewer labels are invented.
It models business decisions only; it is not an identity verifier or a new import
tool. It deliberately consumes already-structured rows, not CSV/Excel.
The example ledger spans two practices for planning; its committable count is
the dataset total across **separate practice-scoped confirmations**, never a
multi-practice import request.

| Invented fixture revision | Source | Accepted preview | Rejected | Duplicate skipped | Committable |
| --- | ---: | ---: | ---: | ---: | ---: |
| Initial | 10 | 4 | 4 | 2 | 0 |
| Corrected with fresh review | 10 | 8 | 0 | 2 | 8 |
| New preview against synthetic saved baseline | 10 | 0 | 0 | 10 | 0 |

The four initial errors are unknown owner, currency mismatch, impossible date
and unapproved practice. Corrections explicitly resolve owner, currency, date
and practice in a new revision, preserving original evidence. One same-file
duplicate uses case/whitespace/full-width Unicode normalization; another matches
an existing opportunity. A conflicting duplicate blocks the batch. The new
preview row above demonstrates deduplication, **not** receipt replay.

For corrected accepted rows dated within October 2026:

| Target scope | Accepted count | Open count/value | Weighted open | Won | Lost |
| --- | ---: | --- | ---: | ---: | ---: |
| Synthetic A / USD / `America/New_York` | 6 | 4 / 270.01 | 118.00 | 200.00 | 50.00 |
| Synthetic B / GBP / `Europe/London` | 2 | 2 / 90.01 | 45.01 | 0.00 | 0.00 |

Time-zone identifiers in the fixture are `America/New_York` and `Europe/London`;
these examples are not approved operational choices. Synthetic A has a baseline
Proposal of USD 30.00 at 50%: expected after-load count 7, open value 300.01,
weighted open 133.00, Won/Lost unchanged. B has no baseline. Source value bridges
are asserted separately per practice/currency/stage, including rejected rows.
No combined USD/GBP total is defined.

Coordination, without duplicating existing tests:

- `test:pipeline-import` and the existing isolated import checks own real CSV/
  XLSX decoding, first-sheet behavior, byte/row limits and stale/cancelled parser
  reads. This ledger covers dispositions, mappings and business sign-off only.
- `check:business` already owns server permission/assignment checks, atomic
  rollback, concurrent uniqueness, same-key receipts and exact scoped summaries.
  No new database fixture or ingestion endpoint is created for this rehearsal.
- The existing report date-boundary follow-up owns inclusive boundary, timezone
  and report regressions. This ledger uses an agreed fixed October period for
  arithmetic reconciliation; it does not claim to close that follow-up.
- Existing shared-form/import-retry, identity/membership, retention/holds and
  recovery work remain prerequisites. Do not create parallel implementations or
  treat these synthetic results as proof of real recovery or pilot readiness.

## 6. Accountability and coordination

Roles below are proposed delivery responsibilities; actual assignees remain
unconfirmed. Record named owners, alternates and contact paths in restricted
operations records, not this repository.

| Accountable role | Required decision / evidence |
| --- | --- |
| Product owner | Demo acceptance, initial workflow scope, cohort, budget ceiling, separate action authorizations and final go/no-go |
| Practice Director or Manager | Business definitions, onboarding reconciliation, legal suitability, risk acceptance and validated reopening; approved recovery policy assigns accountability here |
| Primary authorized Director/Manager | Daily backup-freshness check, incident declaration/response and provider escalation; actual assignment/access required |
| Alternate authorized Director/Manager | Cover primary absence; separately prove effective recovery privileges |
| Engineering delivery lead | Shared business API/storage implementation, server-enforced access, imports, migration review, release compatibility and technical acceptance evidence |
| Company identity operator | Coordinate tenant/app registration and verified Microsoft sign-in with the existing SSO work; no tenant changes under this plan |
| Authorized application Administrator | Coordinate existing membership-management work; no implied practice access or provider restore authority |

No additional recovery hierarchy or authorization feature is proposed.

Coordinate rather than recreate the following existing work:

- **Microsoft company sign-in after the pilot:** consume its verified tenant
  identity/session contract; `AUTH_MODE=entra` currently means configuration
  required, not working SSO. Preserve tenant-stable identity binding used by
  operator bootstrap. Track sign-in and persistent session readiness together.
- **Administrators assign practice access:** use that work for grant/revoke
  workflows and effective practice access; do not implement a second user or
  membership system in the business modules.
- **Provider-backup verification:** use the recovery policy and its separate,
  target-authorized verification process. Existing wrong-cluster, interrupted
  cleanup, inherited-credential and failed-backup checks strengthen disposable
  rehearsals only. They cannot verify provider backups or authorize a restore.
- **Demo/import isolation, report date boundaries, expired sessions and vulnerable
  dependencies:** coordinate the already listed checks before release; do not
  duplicate their tasks. Summary exports remain optional separate scope.

## 7. Phases, acceptance gates and launch decision

| Gate / sequence | Acceptance evidence and approver | Current status |
| --- | --- | --- |
| G0 — Demo accepted | Owner accepts demonstrated role/workflow behavior | Accepted: “lets approve the demo version and move forward” |
| G1 — Production design/budget approved | Owner + Director/Manager confirm workflow matrix, entitlements, metrics, data volumes, legal obligations, accountable people, estimates and pilot scope | Demonstrated first-release development scope commissioned within included Pro credits only; operational/pilot decisions remain open, not launch approval |
| G2 — Implementation ready | Engineering proves durable shared data, atomic/retry-safe import, concurrent editing, consistent totals and explicit errors; existing sign-in/membership work supplies verified contracts | Open; foundation/demo are not this evidence |
| G3 — Target actions separately authorized | Owner names target/provider/region/plan and approves bounded setup, schema changes and costs; publishing and backup/drill actions separately specified | No authorization granted |
| G4 — Security/recovery ready for real data | Authorized Director/Manager accepts restricted evidence listed below | **Unverified; blocks real-data launch** |
| G5 — Pilot accepted | Reconciled authorized onboarding, role-by-role checks with distinct real identities, support/incident cover and owner go/no-go | Blocked by previous gates |
| G6 — Broader rollout | Owner accepts pilot outcomes, capacity/cost measurements and remaining issues before adding practices/users | Not authorized |

G2 checks use synthetic isolated environments. An authorized non-real-data
production verification deployment may occur only under G3 to establish G4;
this is not real-data launch and must not bypass G0/G1 or action authorization.

Required acceptance checks for G2–G5:

- Director/Manager authorized create/edit/delete and import behavior, rejected
  invalid imports without partial commits, duplicates and retries without
  overwritten records, and reconciled dashboards after commit.
- Executive read-only scoped aggregation, Team Member own-status updates only,
  denied financial access, and Administrator with no practice membership denied
  business records. Test direct API requests and cross-practice IDs, not just
  navigation. Membership revocation and expired sessions deny subsequent access.
- Independent users see the same committed data after restart; concurrent edits
  detect conflicts. Empty/error states distinguish missing data from failed loads.
- Report boundaries, currency/rounding and totals match signed-off examples.
  Foundation validation (`pnpm run check:foundation`) and relevant existing checks
  pass; test success alone is not business or recovery approval.
- Production build excludes demo entry/role preview; no synthetic business seeds,
  demo auth fallback, secrets in client bundles or real records in logs.
- Actual database/backup locations, encryption at rest, protected transport,
  provider-managed keys, legal retention and Director/Manager-only backup
  administration/restores have target-specific evidence.
- Two successful subsequent daily backup points and their ages/gap satisfy the
  24-hour loss target; verify available PITR range separately. Approved backup
  retention is seven days; proposed seven-day PITR still needs configuration
  authorization. Settings screenshots alone are insufficient.
- Explicitly authorized provider recovery drill proves integrity and effective
  practice access, including business tables, records actual loss and elapsed
  time from incident declaration through validated reopening, and compares
  against 24-hour RPO / 4-hour RTO. Prove code/schema compatibility and safe
  recovery handling. No automatic bootstrap, schema push, republish or restore.

The accountable Director/Manager keeps detailed evidence restricted; only a
redacted pass/fail summary belongs here. Missing/stale backup, unresolved access
failure, legal conflict or unmeasured recovery keeps launch blocked. After launch,
check backup freshness daily with alternate cover; escalate promptly to provider
support if recovery is blocked or the four-hour target is at risk. Provider-only
storage is the approved policy, with provider/account-loss dependence accepted;
do not invent an independent-copy requirement or claim independent recovery.

## 8. Estimated costs for approval — USD, not a quote

Official documentation consulted 2026-10-10:
[Cloud August 2026 pricing updates](https://docs.replit.com/billing/aug-cloud-billing-updates),
[publishing/database billing](https://docs.replit.com/billing/about-usage-based-billing),
[Core](https://docs.replit.com/billing/plans/replit-core) and
[Pro](https://docs.replit.com/billing/plans/replit-pro).
Reconfirm live rates, actual plan/credits and target before authorizing spend.
No billing settings or resources were changed for this estimate.

Planning rates from those docs: Autoscale $1/month base, $0.60/million compute
units and $0.40/million requests; outbound transfer $0.05/GiB; database compute
$0.16/compute-hour and storage $0.35/GiB-month. Compute-hours are billed database
units, not necessarily one unit per elapsed hour; capacity determines consumption.
Model the frontend as static and one stateless Autoscale API; actual topology and
any additional billable services require review.

| Gross monthly component (before credits/tax) | Low-use pilot assumption | Higher-use sensitivity, not a cap |
| --- | --- | --- |
| Autoscale base | $1.00 | $1.00 |
| API compute | 20 million units → $12.00 | 100 million units → $60.00 |
| Requests | 100,000 → $0.04 | 1 million → $0.40 |
| Database compute | 50 compute-hours → $8.00 | 744 compute-hours → $119.04 |
| Database storage | 5 GiB-month → $1.75 | 20 GiB-month → $7.00 |
| Outbound transfer | 5 GiB → $0.25 | 10 GiB → $0.50 |
| **Modeled usage subtotal** | **$23.04/month** | **$187.94/month** |

These are illustrative consumption inputs, not measured workload forecasts.
Backup/PITR billable storage, drill resources and any unmodeled charges must be
confirmed for the actual provider/plan; neither scenario claims backups are free.
The database-storage line is not proof that seven-day recovery costs fit it.

Core is documented at $30/month monthly or $25/month on annual billing;
Pro at $100/month monthly or $95/month on annual billing. Annual figures are
monthly equivalents with an annual commitment. Verify actual plan and eligible
credits without counting them twice. With monthly Core and no credit offset,
modeled totals are $53.04–$217.94/month **plus unpriced items**. Existing account
subscription may make incremental subscription cost zero; do not assume that.
Seven-day policy does not by itself justify buying a higher plan.

Proposed approval envelope: up to **$250/month gross usage plus the separately
approved subscription**, only after confirming backup/drill costs fit; otherwise
return for revised approval. This is a requested budget, not an enforced platform
spend cap or a granted purchase authorization. Proposed delivery lead reviews
usage weekly during pilot and flags 80% of the approved envelope to the owner;
owner approves scope/capacity adjustment before expansion.

Implementation estimate, including coordinated existing work rather than
double-counting it:

| Workstream | Indicative engineer-days (8 hours/day) |
| --- | --- |
| Confirm scope, permissions, data and migration design | 2–3 |
| Shared business APIs/storage, imports and connected UI | 7–12 |
| Existing Microsoft sign-in and membership work combined | 4–7 |
| Onboarding/reconciliation and pilot support preparation | 2–4 |
| Security/access checks and authorized recovery evidence | 3–6 |
| **Total planning range** | **18–32 days / 144–256 hours** |

At an illustrative $100/hour external engineering rate: **$14,400–$25,600
one-time**; internal staffing uses the same hours with the owner's actual rate.
This is not a contractor quote. Excludes taxes, tenant license changes, legal
advice, domain purchase, paid support and new AI/third-party services. Company
identity operator must confirm any incremental Microsoft licensing cost.
Allow at least two observed daily backup points plus approval/provider waiting
time; effort-days are not a promised launch date. Revise after demo acceptance,
record volumes and the existing work owners' estimates.

## 9. Owner approval record to complete

All items below are **pending**, unless explicitly approved in a later record:

- Demo accepted (date, accepted behavior and required changes).
- First-release workflow/permission matrix, currency/time zone/metric definitions
  and exclusions approved.
- Pilot practices/cohort, source ownership, onboarding mapping and reconciliation
  thresholds approved; legal retention/deletion/hold/location resolved.
- Delivery lead, identity operator, authorized Administrator and accountable/
  primary/alternate Director/Manager assigned in restricted records.
- Implementation effort/rate and monthly usage/subscription envelope approved,
  including confirmed backup/drill and identity-license costs.
- Separate named-target setup/publishing/schema and backup verification/drill
  authorizations recorded; approval of the plan alone does not cover them.
- G4 recovery/security evidence accepted and G5 pilot go/no-go recorded before
  any broader rollout.

**Plan completion is documentation completion only. It does not mean demo
acceptance, production readiness, verified backups or permission to launch.**

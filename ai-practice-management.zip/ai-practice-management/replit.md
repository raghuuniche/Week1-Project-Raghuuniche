# Northstar — AI Practice Management foundation

## Scope and owner decisions

- The owner wants a quick proof of concept first, then production planning. This is a new application with no existing production database; do not treat PoC work as authorization for production setup or real-data launch.
- Approved stack: React + TypeScript + Vite, Express, PostgreSQL, Drizzle; modular monolith.
- The owner has now requested a synthetic role-preview PoC: top-right role picker, role-specific views, data entry, dashboards/reports and Excel/CSV pipeline import. Keep it separate from real authorization and production data. Do not restore `.migration-backup/` wholesale.
- The owner deferred Microsoft Entra ID until after initial demonstration. `AUTH_MODE=entra` is currently a configuration-required state, not working SSO.
- Development demonstration is explicitly enabled with `AUTH_MODE=demo` only in the development environment. Never set it shared or in production, or use it as an auth fallback.
- Demo identity/data is synthetic and isolated. No real-data or Administrator access.
- Recovery policy is approved, policy only: daily backups, 7-day retention, maximum 24-hour record-loss and 4-hour recovery targets, not verified guarantees. Practice Director or Manager is accountable and primary operator; another authorized Director/Manager provides alternate cover. Check backup freshness daily; contact provider support promptly if recovery is blocked or the 4-hour target is at risk. Keep authorization/recovery simple, with no additional hierarchy or features.
- Provider-only managed backup storage is approved; no independent copy is required and provider/account loss may prevent recovery. Use a provider-supported region subject to legal suitability, provider-managed encryption at rest and protected transport, provider-managed keys, and backup administration/restores restricted to authorized Directors/Managers. Seven-day backups are not business-record retention; confirm legal retention, deletion/hold and location obligations before launch.
- Real-data launch remains blocked pending actual primary/alternate assignments, target/database and backup locations, security/access and retention evidence, separately authorized production configuration, and verified recovery. Policy approval authorizes no publishing, configuration changes, exports, restores, deletion or costs and grants no application Administrator access. See `docs/production-recovery-policy.md`.
- Identity alone and a global Administrator grant alone both grant no practice access.

## Run and verify

- Managed API workflow: `artifacts/api-server: API Server`, `/api`.
- Managed web workflow: `artifacts/practice-management: web`, `/`.
- `pnpm run typecheck`.
- `pnpm run check:poc` is the frontend-only synthetic role/import gate. It owns development and production-preview servers, intercepts session API calls in disposable browser contexts, and never starts PostgreSQL or the real API. Requires Chromium; CI installs it explicitly.
- `pnpm run check:foundation` is the isolated pre-merge gate; it owns temporary PostgreSQL and test app processes, never the workspace/production database.
- `pnpm --filter @workspace/api-server run test` requires a separate loopback `FOUNDATION_TEST_DATABASE_URL` with schema; no fallback to application `DATABASE_URL`.
- `pnpm --filter @workspace/scripts run test:browser` (requires running workflows and Chromium).
- Development DB schema: `pnpm --filter @workspace/db run push`; no startup-time or production build DDL.
- Secrets: `DATABASE_URL` (managed), `SESSION_SECRET` (at least 32 characters).
- README.md documents setup, mode switches, identity boundaries, and operator-only Administrator bootstrap.
- Demo sessions are in memory, signed and CSRF-protected; API restart ends them.
- Shared pipeline/delivery/goal records, attributable audits, import receipts and provider session storage are implemented. No live seed records or workspace/production schema changes are authorized.
- `pnpm run check:business` verifies manual versioned migrations and the scoped shared-data API using a newly owned loopback database, including conflicts, retries, two sessions and real API process restart. Its `--serve-ui` fixture mode is test-only and loopback-bound.
- Demo assets/routes/storage are excluded from production frontend builds; synthetic identities never access the shared workspace.

## Organization

- Web UI/design tokens: `artifacts/practice-management/`.
- API authentication/authorization: `artifacts/api-server/src/auth/`, `src/middlewares/`.
- API contract: `lib/api-spec/openapi.yaml`; regenerate after changes.
- Relational foundation: `lib/db/src/schema/`.
- Operator bootstrap: `scripts/src/bootstrap-admin.ts`; no HTTP bootstrap endpoint.
- The mockup sandbox is not the product. Source backup is preserved, not served.

## Future work

Connect and verify Microsoft Entra ID and Administrator membership management
through their existing separate work. The provider adapter installs verified
issuer/subject sessions, not identity headers or client-selected roles. Business
authorization rechecks active identity/membership at the server on every request.
Production data use, target migrations and publishing remain out of scope.
See `docs/production-rollout-plan.md` for the conditional owner decision pack,
workflow/acceptance gates and illustrative costs. The owner accepted the demo
and commissioned shared first-release development with no additional spending.
The plan grants no production action/spend authority; recovery is unverified.
See `docs/shared-workspace-handoff.md` for exact contracts, rollout compatibility,
verification evidence and remaining launch prerequisites.

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Only this runner's new loopback cluster is allowed; no inherited credentials.
unset DATABASE_URL FOUNDATION_TEST_DATABASE_URL PGHOST PGPORT PGDATABASE PGUSER PGPASSWORD PGOPTIONS PGSERVICE PGSERVICEFILE
unset SESSION_SECRET REPLIT_DEPLOYMENT
export NODE_ENV=test
for tool in initdb pg_ctl createdb psql node pnpm setsid; do
  command -v "$tool" >/dev/null || { echo "Required tool missing: $tool" >&2; exit 1; }
done
output="$PWD/generated-artifacts/business-gate"
mkdir -p "$output"
temporary="$(mktemp -d)"
pids=()
cleanup() {
  result=$?
  trap - EXIT
  for pid in "${pids[@]}"; do
    kill -- "-$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
  done
  if [[ -f "$temporary/pg/postmaster.pid" ]]; then
    if ! pg_ctl -D "$temporary/pg" -m fast -w stop >>"$output/postgres.log" 2>&1; then result=1; fi
  fi
  if [[ -f "$temporary/pg/postmaster.pid" ]]; then
    echo "Cleanup uncertain; disposable database retained at $temporary" >&2
    result=1
  else
    rm -rf "$temporary"
  fi
  exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT TERM
echo "Starting synthetic business verification in a new disposable cluster"
initdb -D "$temporary/pg" -U foundation_test --auth=trust --no-locale >"$output/postgres.log" 2>&1
pg_ctl -D "$temporary/pg" -l "$output/postgres.log" -o "-h 127.0.0.1 -p 25440 -k $temporary" -w start >>"$output/postgres.log" 2>&1
createdb -h 127.0.0.1 -p 25440 -U foundation_test foundation_test_business
export FOUNDATION_TEST_DATABASE_URL="postgresql://foundation_test@127.0.0.1:25440/foundation_test_business"
export DATABASE_URL="$FOUNDATION_TEST_DATABASE_URL"
psql "$FOUNDATION_TEST_DATABASE_URL" -v ON_ERROR_STOP=1 -f lib/db/migrations/0000_foundation.sql >"$output/migration.log"
psql "$FOUNDATION_TEST_DATABASE_URL" -v ON_ERROR_STOP=1 -f lib/db/migrations/0001_shared_business.sql >>"$output/migration.log"
if [[ "${1:-}" == "--serve-ui" ]]; then
  export BASE_PATH=/ PORT=25442
  # The generated secret is for this throwaway loopback server only.
  export SESSION_SECRET="$(node -e 'process.stdout.write(require("node:crypto").randomBytes(48).toString("hex"))')"
  pnpm --filter @workspace/practice-management run build
  setsid pnpm --filter @workspace/api-server exec tsx src/tests/business-browser-fixture.ts &
  pids+=("$!")
  wait "${pids[0]}"
  exit $?
fi
pnpm run typecheck
pnpm --filter @workspace/api-server run test
echo "Business gate passed: migrated schema, scoped API, atomic imports, conflicts, actual process restart."

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

# This runner owns its database and app processes. Never inherit cloud targets.
unset DATABASE_URL FOUNDATION_TEST_DATABASE_URL PGHOST PGPORT PGDATABASE PGUSER PGPASSWORD PGOPTIONS PGSERVICE PGSERVICEFILE
unset SESSION_SECRET REPLIT_DEPLOYMENT
export NODE_ENV=test
for tool in initdb pg_ctl createdb curl setsid node pnpm; do
  command -v "$tool" >/dev/null || { echo "Required tool missing: $tool" >&2; exit 1; }
done

output="$PWD/generated-artifacts/foundation-gate"
mkdir -p "$output"
temporary="$(mktemp -d)"
pids=()
cleanup() {
  result=$?
  trap - EXIT
  for pid in "${pids[@]}"; do kill -- "-$pid" 2>/dev/null || true; done
  if [[ -f "$temporary/pg/postmaster.pid" ]]; then
    pg_ctl -D "$temporary/pg" -m immediate -w stop >>"$output/postgres.log" 2>&1 || true
  fi
  rm -rf "$temporary"
  exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT TERM

echo "Starting disposable PostgreSQL (no workspace/production credentials)"
initdb -D "$temporary/pg" -U foundation_test --auth=trust --no-locale >"$output/postgres.log" 2>&1
# Only loopback TCP; socket is in our private temporary directory.
pg_ctl -D "$temporary/pg" -l "$output/postgres.log" -o "-h 127.0.0.1 -p 25432 -k $temporary" -w start >>"$output/postgres.log" 2>&1
createdb -h 127.0.0.1 -p 25432 -U foundation_test foundation_test_gate
export FOUNDATION_TEST_DATABASE_URL="postgresql://foundation_test@127.0.0.1:25432/foundation_test_gate"
export DATABASE_URL="$FOUNDATION_TEST_DATABASE_URL"
export SESSION_SECRET="$(node -e 'process.stdout.write(require("node:crypto").randomBytes(48).toString("hex"))')"
export AUTH_MODE=demo
export BASE_PATH=/
export PORT=25002
export FOUNDATION_BASE_URL=http://127.0.0.1:25000

pnpm run typecheck
# DDL is confined to the brand-new test cluster. No live schema pushes.
pnpm --filter @workspace/db run push-force
pnpm --filter @workspace/api-server run test
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/practice-management run build
if grep -El 'Director Lumen|Calder Retail|select-preview-role|Start demo session|northstar.poc.session' artifacts/practice-management/dist/public/assets/*.js; then
  echo "Production must exclude demo entry, role picker and synthetic records" >&2
  exit 1
fi

setsid env PORT=25001 node artifacts/api-server/dist/index.mjs >"$output/api.log" 2>&1 &
pids+=("$!")
# Demo API/browser checks belong to development. Production was checked above.
setsid pnpm --filter @workspace/practice-management run dev --strictPort >"$output/web.log" 2>&1 &
pids+=("$!")
setsid pnpm --filter @workspace/scripts exec tsx src/foundation-test-proxy.ts >"$output/router.log" 2>&1 &
pids+=("$!")

ready=false
for attempt in $(seq 1 60); do
  for pid in "${pids[@]}"; do
    kill -0 "$pid" 2>/dev/null || { echo "A required foundation service exited. See $output" >&2; exit 1; }
  done
  if curl --fail --silent "$FOUNDATION_BASE_URL/api/healthz" >/dev/null &&
     curl --fail --silent "$FOUNDATION_BASE_URL/" >/dev/null; then
    ready=true
    break
  fi
  sleep 1
done
[[ "$ready" == true ]] || { echo "Required foundation services did not become ready. See $output" >&2; exit 1; }
pnpm --filter @workspace/scripts run test:browser
echo "Foundation gate passed: types, PostgreSQL/API boundaries, desktop/mobile sessions."

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

# Frontend-only synthetic gate. No API, PostgreSQL, recovery or live credentials.
unset DATABASE_URL FOUNDATION_TEST_DATABASE_URL SESSION_SECRET AUTH_MODE REPLIT_DEPLOYMENT
unset PGHOST PGPORT PGDATABASE PGUSER PGPASSWORD PGOPTIONS PGSERVICE PGSERVICEFILE
unset REPL_ID NODE_ENV
export BASE_PATH=/
output="$PWD/generated-artifacts/poc-gate"
mkdir -p "$output"
pids=()
cleanup() {
  result=$?
  trap - EXIT
  for pid in "${pids[@]}"; do kill -- "-$pid" 2>/dev/null || true; done
  exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT TERM

pnpm --filter @workspace/scripts run test:pipeline-import
PORT=25102 pnpm --filter @workspace/practice-management exec vite build --outDir "$output/production" >"$output/build.log" 2>&1
setsid env PORT=25101 pnpm --filter @workspace/practice-management run dev >"$output/development.log" 2>&1 &
pids+=("$!")
setsid env PORT=25102 pnpm --filter @workspace/practice-management exec vite preview --outDir "$output/production" --strictPort >"$output/production.log" 2>&1 &
pids+=("$!")
ready=false
for attempt in $(seq 1 60); do
  for pid in "${pids[@]}"; do
    kill -0 "$pid" 2>/dev/null || { echo "PoC server exited. See $output" >&2; exit 1; }
  done
  if curl --fail --silent http://127.0.0.1:25101/ >/dev/null &&
     curl --fail --silent http://127.0.0.1:25102/ >/dev/null; then
    ready=true
    break
  fi
  sleep 1
done
[[ "$ready" == true ]] || { echo "PoC servers did not become ready. See $output" >&2; exit 1; }
pnpm --filter @workspace/scripts run test:poc:browser "$@"
echo "PoC gate passed (synthetic browser data only; no database or real API)."

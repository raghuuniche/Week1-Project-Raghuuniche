#!/usr/bin/env bash
# Explicit operator/test command only; never call from startup or post-merge.
set -euo pipefail
cd "$(dirname "$0")/.."
umask 077

if [[ "${NODE_ENV:-}" == production || -n "${REPLIT_DEPLOYMENT:-}" ]]; then
  echo "Recovery rehearsal is forbidden in a deployment/production runtime." >&2
  exit 1
fi
fault="${1:-}"
case "$fault" in
  ""|--fault=archive|--fault=membership|--fault=audit|--fault=restore-transaction) ;;
  *) echo "Usage: pnpm rehearse:recovery [--fault=archive|--fault=membership|--fault=audit|--fault=restore-transaction]" >&2; exit 1 ;;
esac
[[ $# -le 1 ]] || { echo "Only one fault option is allowed." >&2; exit 1; }

# Do not inherit any DB credentials, service files, SSL settings, bootstrap
# identities, or authentication secrets. Child commands receive local targets only.
for key in $(compgen -e); do
  case "$key" in
    PG*|*DATABASE_URL|BOOTSTRAP_*|SESSION_SECRET|RECOVERY_*) unset "$key" ;;
  esac
done
export NODE_ENV=test
export LC_ALL=C
for tool in initdb pg_ctl createdb pg_dump pg_restore pnpm node truncate; do
  command -v "$tool" >/dev/null || { echo "Required tool missing: $tool" >&2; exit 1; }
done
for tool in initdb pg_ctl createdb pg_dump pg_restore; do
  [[ "$("$tool" --version)" =~ \(PostgreSQL\)\ 16\. ]] || {
    echo "Recovery rehearsal requires PostgreSQL 16 tools: $tool" >&2
    exit 1
  }
done

mkdir -p generated-artifacts/recovery
output="$(mktemp -d "$PWD/generated-artifacts/recovery/run-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXX")"
echo "RECOVERY_EVIDENCE=$output"
temporary="$(mktemp -d /tmp/recovery-XXXXXX)"
export RECOVERY_ROOT="$temporary" RECOVERY_OUTPUT="$output"
printf 'synthetic-recovery-v1\n' >"$temporary/owner-marker"
cleanup() {
  result=$?
  cleanup_result=PASS
  trap - EXIT
  for target in source restore; do
    if [[ -f "$temporary/$target/pg/postmaster.pid" ]]; then
      if ! pg_ctl -D "$temporary/$target/pg" -m immediate -w stop >>"$output/$target.log" 2>&1; then
        echo "Could not stop owned $target cluster; see $output/$target.log" >&2
        result=1
        cleanup_result=FAIL
      fi
      if [[ -f "$temporary/$target/pg/postmaster.pid" ]]; then
        echo "Owned $target cluster still has a postmaster marker; retaining $temporary." >&2
        result=1
        cleanup_result=FAIL
      fi
    fi
  done
  if [[ "$result" == 0 ]]; then
    rm -rf "$temporary"
    printf 'PASS\n' >"$output/status"
  else
    # Do not delete a directory while its owned server is still running.
    if [[ ! -f "$temporary/source/pg/postmaster.pid" && ! -f "$temporary/restore/pg/postmaster.pid" ]]; then
      rm -rf "$temporary"
    fi
    printf 'FAIL (exit %s)\n' "$result" >"$output/status"
    echo "Recovery rehearsal failed. Evidence: $output" >&2
  fi
  printf '%s\n' "$cleanup_result" >"$output/cleanup-status"
  exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT TERM

for target in source restore; do
  mkdir -p "$temporary/$target/socket"
  initdb -D "$temporary/$target/pg" -U recovery_fixture --auth-local=trust --auth-host=reject --no-locale >"$output/$target.log" 2>&1
  # No TCP listener at all; sockets are inside a private mode-0700 directory.
  pg_ctl -D "$temporary/$target/pg" -l "$output/$target.log" \
    -o "-h '' -p 25433 -k $temporary/$target/socket" -w start >>"$output/$target.log" 2>&1
  createdb -h "$temporary/$target/socket" -p 25433 -U recovery_fixture recovery_fixture_test
done

echo "Preparing synthetic source in a new private cluster."
SECONDS=0
export DATABASE_URL="postgresql://recovery_fixture@localhost:25433/recovery_fixture_test?host=$temporary/source/socket"
pnpm --filter @workspace/db run push-force >"$output/schema.log" 2>&1
unset DATABASE_URL
pnpm --filter @workspace/scripts run recovery:fixtures seed
if [[ "$fault" == --fault=restore-transaction ]]; then
  pnpm --filter @workspace/scripts run recovery:fixtures prepare-restore-transaction
fi
pg_dump -h "$temporary/source/socket" -p 25433 -U recovery_fixture -d recovery_fixture_test \
  --format=custom --no-owner --no-privileges --file="$output/foundation.dump"
pnpm --filter @workspace/scripts run recovery:fixtures seal
backup_seconds=$SECONDS

# Verification cannot accidentally read the source after this point.
pg_ctl -D "$temporary/source/pg" -m fast -w stop >>"$output/source.log" 2>&1
if [[ "$fault" == --fault=archive ]]; then
  truncate -s 32 "$output/foundation.dump"
fi
pnpm --filter @workspace/scripts run recovery:fixtures preflight
echo "Restoring archive into the separate empty cluster (source is stopped)."
SECONDS=0
restore_exit=0
pg_restore -h "$temporary/restore/socket" -p 25433 -U recovery_fixture -d recovery_fixture_test \
  --verbose --exit-on-error --single-transaction --no-owner --no-privileges "$output/foundation.dump" >"$output/restore-command.log" 2>&1 || restore_exit=$?
if [[ "$fault" == --fault=restore-transaction ]]; then
  [[ "$restore_exit" == 1 ]] || { echo "Expected controlled pg_restore failure (exit 1), got $restore_exit." >&2; exit 1; }
  pnpm --filter @workspace/scripts run recovery:fixtures verify-restore-rollback
  printf '{"prepareAndBackupSeconds":%s,"restoreAndVerifySeconds":%s}\n' "$backup_seconds" "$SECONDS" >"$output/timing.json"
  echo "Controlled restore error and empty target after rollback confirmed. Evidence: $output"
  exit 0 # EXIT trap still requires successful owned-cluster cleanup.
fi
[[ "$restore_exit" == 0 ]] || exit "$restore_exit"
case "$fault" in
  --fault=membership) pnpm --filter @workspace/scripts run recovery:fixtures fault-membership ;;
  --fault=audit) pnpm --filter @workspace/scripts run recovery:fixtures fault-audit ;;
esac
pnpm --filter @workspace/scripts run recovery:fixtures verify
printf '{"prepareAndBackupSeconds":%s,"restoreAndVerifySeconds":%s}\n' "$backup_seconds" "$SECONDS" >"$output/timing.json"
echo "Recovery rehearsal passed. Synthetic archive, manifest and evidence: $output"

#!/bin/bash
set -euo pipefail
pnpm install --frozen-lockfile
# Schema application is explicit and environment-scoped, never a merge side effect.
# Never migrate, seed, or bootstrap an Administrator automatically.

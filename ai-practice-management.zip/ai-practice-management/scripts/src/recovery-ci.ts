import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, openSync, closeSync, readFileSync, writeFileSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const scenarios = [
  { name: "normal", phase: null, code: null },
  { name: "archive", phase: "preflight", code: "ARCHIVE_INTEGRITY_MISMATCH" },
  { name: "membership", phase: "verify", code: "INACTIVE_MEMBERSHIP_ALLOWED" },
  { name: "audit", phase: "verify", code: "AUDIT_IDENTITY_BINDING_BROKEN" },
  { name: "restore-transaction", phase: null, code: null },
] as const;

type Result = {
  exit: number | null; signal: string | null; status: string; cleanup: string;
  failure?: { syntheticOnly?: boolean; phase?: string; code?: string };
  verification?: { syntheticOnly?: boolean; sourceStoppedBeforeRestore?: boolean };
  rollback?: {
    syntheticOnly?: boolean; sourceStoppedBeforeRestore?: boolean;
    archiveIntegrityVerified?: boolean; restoreExitCode?: number;
    expectedError?: string; schemaAndDataEmpty?: boolean;
  };
};

export function validateResult(name: string, result: Result) {
  const scenario = scenarios.find((item) => item.name === name);
  assert.ok(scenario, "Known CI scenario required");
  assert.equal(result.signal, null, "Rehearsal must not be killed");
  assert.equal(result.cleanup, "PASS\n", "Owned clusters must be cleaned up");
  if (scenario.name === "normal" || scenario.name === "restore-transaction") {
    assert.equal(result.exit, 0, "Successful rehearsal assertions must return zero");
    assert.equal(result.status, "PASS\n");
    assert.equal(result.failure, undefined, "Normal run must not contain failure evidence");
    if (scenario.name === "normal") {
      assert.equal(result.verification?.syntheticOnly, true);
      assert.equal(result.verification?.sourceStoppedBeforeRestore, true);
      assert.equal(result.rollback, undefined);
    } else {
      assert.equal(result.verification, undefined, "Broken restore must not claim successful restoration");
      assert.equal(result.rollback?.syntheticOnly, true);
      assert.equal(result.rollback?.sourceStoppedBeforeRestore, true);
      assert.equal(result.rollback?.archiveIntegrityVerified, true);
      assert.equal(result.rollback?.restoreExitCode, 1);
      assert.equal(result.rollback?.expectedError, "recovery_restore_transaction_unique");
      assert.equal(result.rollback?.schemaAndDataEmpty, true);
    }
  } else {
    assert.equal(result.exit, 1, "Fault must fail, not succeed or crash");
    assert.equal(result.status, "FAIL (exit 1)\n");
    assert.deepEqual(result.failure, {
      syntheticOnly: true, phase: scenario.phase, code: scenario.code,
    }, "Fault must be rejected for its exact expected reason and phase");
    assert.equal(result.verification, undefined, "Fault must not reach successful verification");
    assert.equal(result.rollback, undefined, "Existing faults must not claim rollback verification");
  }
}

function main() {
  process.umask(0o077);
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
  const evidenceRoot = path.join(root, "generated-artifacts/recovery");
  mkdirSync(evidenceRoot, { recursive: true, mode: 0o700 });
  const suite = mkdtempSync(path.join(evidenceRoot, "ci-"));
  const results: { scenario: string; passed: boolean; evidence?: string }[] = [];
  let failed = false;
  for (const scenario of scenarios) {
    const log = path.join(suite, `${scenario.name}.log`);
    const fd = openSync(log, "w", 0o600);
    let execution;
    try {
      execution = spawnSync("pnpm", ["run", "rehearse:recovery",
        ...(scenario.name === "normal" ? [] : [`--fault=${scenario.name}`])],
      { cwd: root, stdio: ["ignore", fd, fd], timeout: 180_000, killSignal: "SIGTERM" });
    } finally { closeSync(fd); }
    let evidence: string | undefined;
    try {
      assert.equal(execution.error, undefined, "Rehearsal process must start and finish");
      const markers = [...readFileSync(log, "utf8").matchAll(/^RECOVERY_EVIDENCE=(.+)$/gm)];
      assert.equal(markers.length, 1, "Exactly one fresh evidence directory required");
      evidence = markers[0]![1]!;
      assert.equal(path.dirname(evidence), evidenceRoot, "Evidence must stay in the ignored synthetic directory");
      assert.match(path.basename(evidence), /^run-[\w-]+$/);
      const json = (name: string) => JSON.parse(readFileSync(path.join(evidence!, name), "utf8"));
      validateResult(scenario.name, {
        exit: execution.status, signal: execution.signal,
        status: readFileSync(path.join(evidence, "status"), "utf8"),
        cleanup: readFileSync(path.join(evidence, "cleanup-status"), "utf8"),
        verification: existsSync(path.join(evidence, "verification.json")) ? json("verification.json") : undefined,
        failure: existsSync(path.join(evidence, "failure.json")) ? json("failure.json") : undefined,
        rollback: existsSync(path.join(evidence, "rollback-verification.json")) ? json("rollback-verification.json") : undefined,
      });
      results.push({ scenario: scenario.name, passed: true, evidence });
      console.log(`${scenario.name}: expected recovery outcome and cleanup confirmed.`);
    } catch {
      failed = true;
      results.push({ scenario: scenario.name, passed: false, evidence });
      console.error(`${scenario.name}: unexpected recovery outcome; inspect private synthetic evidence in ${suite}`);
    }
  }
  writeFileSync(path.join(suite, "summary.json"), JSON.stringify({
    syntheticOnly: true, passed: !failed, results,
  }, null, 2) + "\n", { mode: 0o600 });
  process.exitCode = failed ? 1 : 0;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();

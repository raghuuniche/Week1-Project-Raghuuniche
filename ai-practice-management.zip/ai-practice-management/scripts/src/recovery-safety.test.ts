import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import {
  chmodSync, copyFileSync, existsSync, mkdirSync, mkdtempSync,
  readFileSync, readdirSync, realpathSync, renameSync, rmSync, statSync,
  symlinkSync, writeFileSync,
} from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import test from "node:test";

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const scripts = path.join(repo, "scripts");
const require = createRequire(import.meta.url);
const pgTools = ["initdb", "pg_ctl", "createdb", "pg_dump", "pg_restore"];
const requiredTools = [...pgTools, "pnpm", "node", "truncate"];
const phases = ["seed", "seal", "preflight", "verify", "fault-membership", "fault-audit",
  "prepare-restore-transaction", "verify-restore-rollback"];
const boundaryExit = 86;

// Deliberately do not spread process.env: credentials, deployment settings and
// Node preload options from the operator must never enter these child processes.
function environment(extra: NodeJS.ProcessEnv = {}): NodeJS.ProcessEnv {
  return { PATH: process.env.PATH, NODE_ENV: "test", ...extra };
}

function run(command: string, args: string[], cwd: string, env: NodeJS.ProcessEnv) {
  const result = spawnSync(command, args, {
    cwd, env, encoding: "utf8", timeout: 15_000, maxBuffer: 1_000_000,
  });
  assert.equal(result.error, undefined, "Child must start and finish, not time out");
  assert.equal(result.signal, null, "Rejection must not be a killed process");
  return result;
}

function calls(log: string): { tool: string; args: string[] }[] {
  return existsSync(log)
    ? readFileSync(log, "utf8").trim().split("\n").filter(Boolean).map((line) => JSON.parse(line))
    : [];
}

test("shell guards reject before creating any cluster, evidence or schema", async (t) => {
  const root = mkdtempSync("/tmp/recovery-safety-shell-");
  t.after(() => rmSync(root, { recursive: true, force: true }));
  const bin = path.join(root, "bin");
  mkdirSync(bin);
  mkdirSync(path.join(root, "scripts"));
  copyFileSync(path.join(scripts, "rehearse-recovery.sh"), path.join(root, "scripts/rehearse-recovery.sh"));
  const log = path.join(root, "calls.jsonl");
  writeFileSync(path.join(bin, "dirname"), `#!${process.execPath}
console.log(require("node:path").dirname(process.argv[2]));
`);
  chmodSync(path.join(bin, "dirname"), 0o700);
  // Every external command available on PATH is inert. Even mkdir/mktemp are
  // intercepted, so a removed guard cannot create a cluster or touch a real DB.
  for (const tool of [...requiredTools, "mkdir", "mktemp", "date", "rm"]) {
    const stub = path.join(bin, tool);
    writeFileSync(stub, `#!${process.execPath}
const fs = require("node:fs");
const tool = ${JSON.stringify(tool)};
const args = process.argv.slice(2);
fs.appendFileSync(process.env.SAFETY_LOG, JSON.stringify({tool, args}) + "\\n");
if (${JSON.stringify(pgTools)}.includes(tool) && args.length === 1 && args[0] === "--version") {
  console.log(tool + " (PostgreSQL) " + (process.env.WRONG_TOOL === tool ? process.env.WRONG_VERSION : "16.6"));
} else {
  console.error("SYNTHETIC_COMMAND_BOUNDARY");
  process.exit(${boundaryExit});
}
`);
    chmodSync(stub, 0o700);
  }
  const invoke = (args: string[], extra: NodeJS.ProcessEnv = {}) => {
    rmSync(log, { force: true });
    return run("/bin/bash", [path.join(root, "scripts/rehearse-recovery.sh"), ...args], root,
      environment({ PATH: bin, SAFETY_LOG: log, ...extra }));
  };
  const cases = [
    { name: "production", args: [], env: { NODE_ENV: "production" }, message: /forbidden/ },
    { name: "deployment", args: [], env: { REPLIT_DEPLOYMENT: "1" }, message: /forbidden/ },
    { name: "nonempty deployment flag", args: [], env: { REPLIT_DEPLOYMENT: "0" }, message: /forbidden/ },
    { name: "unknown option", args: ["--unsafe"], env: {}, message: /Usage:/ },
    { name: "unknown fault", args: ["--fault=other"], env: {}, message: /Usage:/ },
    { name: "positional argument", args: ["seed"], env: {}, message: /Usage:/ },
    { name: "extra option", args: ["--fault=archive", "--unsafe"], env: {}, message: /Only one/ },
    { name: "duplicate option", args: ["--fault=audit", "--fault=audit"], env: {}, message: /Only one/ },
  ];
  for (const item of cases) {
    await t.test(item.name, () => {
      const result = invoke(item.args, item.env);
      assert.equal(result.status, 1);
      assert.match(result.stderr, item.message);
      assert.deepEqual(calls(log), [], "No tool, cluster or schema command may run");
      assert.ok(!existsSync(path.join(root, "generated-artifacts")));
    });
  }
  for (const tool of requiredTools) {
    await t.test(`missing ${tool} rejects before any tool or allocation`, () => {
      const stub = path.join(bin, tool);
      const omitted = path.join(root, `omitted-${tool}`);
      // Remove only this command from PATH. The remaining stubs still use the
      // absolute Node shebang, so omitting node cannot disable the spies.
      renameSync(stub, omitted);
      try {
        const result = invoke([]);
        assert.equal(result.status, 1);
        assert.equal(result.stderr, `Required tool missing: ${tool}\n`);
        assert.equal(result.stdout, "", "No evidence location may be announced");
        assert.deepEqual(calls(log), [],
          "No version check, cluster/schema command or directory allocation may run");
        assert.ok(!existsSync(path.join(root, "generated-artifacts")),
          "Missing tools must be rejected before evidence directory allocation");
      } finally {
        renameSync(omitted, stub);
      }
    });
  }
  for (const tool of pgTools) {
    for (const version of ["15.9", "17.2"]) {
      await t.test(`${tool} rejects PostgreSQL ${version}`, () => {
        const result = invoke([], { WRONG_TOOL: tool, WRONG_VERSION: version });
        assert.equal(result.status, 1);
        assert.match(result.stderr, new RegExp(`requires PostgreSQL 16 tools: ${tool}`));
        assert.deepEqual(calls(log), pgTools.slice(0, pgTools.indexOf(tool) + 1)
          .map((name) => ({ tool: name, args: ["--version"] })));
        assert.ok(!existsSync(path.join(root, "generated-artifacts")));
      });
    }
  }
  // Positive controls prove stubs and PATH are usable and allowed options get
  // past the guards, but stop before even allocating an evidence directory.
  for (const args of [[], ["--fault=archive"], ["--fault=membership"], ["--fault=audit"], ["--fault=restore-transaction"]]) {
    await t.test(`valid invocation reaches synthetic boundary: ${args.join(" ") || "normal"}`, () => {
      const result = invoke(args);
      assert.equal(result.status, boundaryExit);
      assert.match(result.stderr, /SYNTHETIC_COMMAND_BOUNDARY/);
      assert.deepEqual(calls(log), [
        ...pgTools.map((tool) => ({ tool, args: ["--version"] })),
        { tool: "mkdir", args: ["-p", "generated-artifacts/recovery"] },
      ]);
    });
  }
});

test("rehearsal strips inherited sentinels but supplies its own local settings", async (t) => {
  // These values are invented here, never copied from the operator environment.
  // Include both familiar settings and arbitrary names to exercise each glob.
  const sentinelKeys = [
    "PGHOST", "PGHOSTADDR", "PGPORT", "PGUSER", "PGPASSWORD", "PGDATABASE",
    "PGSERVICE", "PGSERVICEFILE", "PGPASSFILE", "PGSSLMODE", "PGSSLROOTCERT",
    "PGOPTIONS", "PG_FAKE_EXTENSION",
    "DATABASE_URL", "TEST_DATABASE_URL", "OTHER_DATABASE_URL",
    "BOOTSTRAP_EMAIL", "BOOTSTRAP_PROVIDER_SUBJECT", "BOOTSTRAP_FAKE_EXTENSION",
    "SESSION_SECRET",
    "RECOVERY_ROOT", "RECOVERY_OUTPUT", "RECOVERY_FAKE_EXTENSION",
  ];
  const sentinels = Object.fromEntries(sentinelKeys.map(key =>
    [key, `INERT_INHERITED_SENTINEL_${key}`]));
  for (const fault of ["", "archive", "membership", "audit", "restore-transaction"]) {
    await t.test(fault || "normal", () => {
      const root = mkdtempSync("/tmp/recovery-environment-safety-");
      t.after(() => rmSync(root, { recursive: true, force: true }));
      const bin = path.join(root, "bin");
      const temporary = path.join(root, "owned");
      const output = path.join(root, "generated-artifacts/recovery/inert-run");
      const log = path.join(root, "calls.jsonl");
      const localUrl = `postgresql://recovery_fixture@localhost:25433/recovery_fixture_test?host=${temporary}/source/socket`;
      mkdirSync(bin);
      mkdirSync(path.join(root, "scripts"));
      copyFileSync(path.join(scripts, "rehearse-recovery.sh"),
        path.join(root, "scripts/rehearse-recovery.sh"));
      // dirname runs before the stripping boundary, only to locate the script.
      writeFileSync(path.join(bin, "dirname"), `#!${process.execPath}
console.log(require("node:path").dirname(process.argv[2]));
`);
      chmodSync(path.join(bin, "dirname"), 0o700);
      for (const tool of [...pgTools, "pnpm", "node", "truncate", "mkdir", "mktemp", "date", "rm"]) {
        const stub = path.join(bin, tool);
        writeFileSync(stub, `#!${process.execPath}
const fs = require("node:fs");
const path = require("node:path");
const tool = ${JSON.stringify(tool)};
const args = process.argv.slice(2);
const root = ${JSON.stringify(root)};
const temporary = ${JSON.stringify(temporary)};
const output = ${JSON.stringify(output)};
const sentinels = ${JSON.stringify(sentinels)};
const safe = (p) => {
  const resolved = path.resolve(p);
  if (!resolved.startsWith(root + "/")) throw new Error("Outside sandbox");
  return resolved;
};
// Record only known fake values, not an environment dump or arbitrary settings.
const inherited = Object.fromEntries(Object.entries(sentinels)
  .filter(([key, value]) => process.env[key] === value));
const local = {
  root: process.env.RECOVERY_ROOT === temporary,
  output: process.env.RECOVERY_OUTPUT === output,
  database: process.env.DATABASE_URL === ${JSON.stringify(localUrl)},
  databaseAbsent: process.env.DATABASE_URL === undefined,
  testMode: process.env.NODE_ENV === "test",
};
fs.appendFileSync(${JSON.stringify(log)}, JSON.stringify({tool, args, inherited, local}) + "\\n");
if (${JSON.stringify(pgTools)}.includes(tool) && args.length === 1 && args[0] === "--version") {
  console.log(tool + " (PostgreSQL) 16.6");
} else if (tool === "date") {
  console.log("20000101T000000Z");
} else if (tool === "mkdir") {
  for (const p of args.filter(a => !a.startsWith("-"))) fs.mkdirSync(safe(p), {recursive:true});
} else if (tool === "mktemp") {
  const directory = args[1] === "/tmp/recovery-XXXXXX" ? temporary : output;
  fs.mkdirSync(safe(directory), {mode:0o700});
  console.log(directory);
} else if (tool === "rm") {
  for (const p of args.filter(a => !a.startsWith("-"))) fs.rmSync(safe(p), {recursive:true, force:true});
} else if (tool === "initdb") {
  fs.mkdirSync(safe(args[args.indexOf("-D") + 1]), {recursive:true});
} else if (tool === "pg_ctl") {
  const marker = path.join(safe(args[args.indexOf("-D") + 1]), "postmaster.pid");
  if (args.at(-1) === "start") fs.writeFileSync(marker, "inert-marker\\n");
  else if (args.at(-1) === "stop") fs.rmSync(marker, {force:true});
  else throw new Error("Unexpected pg_ctl operation");
} else if (tool === "pg_restore" && ${JSON.stringify(fault)} === "restore-transaction") {
  process.exit(1);
} else if (!["pnpm", "createdb", "pg_dump", "pg_restore", "truncate"].includes(tool)) {
  throw new Error("Unexpected command");
}
`);
        chmodSync(stub, 0o700);
      }
      const env = environment({ PATH: bin, ...sentinels });
      type EnvironmentCall = {
        tool: string; args: string[]; inherited: Record<string, string>;
        local: { root: boolean; output: boolean; database: boolean; databaseAbsent: boolean; testMode: boolean };
      };
      const recorded = () => calls(log) as EnvironmentCall[];
      // A positive control proves the spy sees every injected marker when no
      // sanitizer intervenes. This still invokes only the inert executable.
      assert.equal(run(path.join(bin, "initdb"), ["--version"], root, env).status, 0);
      assert.deepEqual(recorded()[0].inherited, sentinels);
      rmSync(log);

      const result = run("/bin/bash", [path.join(root, "scripts/rehearse-recovery.sh"),
        ...(fault ? [`--fault=${fault}`] : [])], root, env);
      assert.equal(result.status, 0, result.stderr);
      const observed = recorded();
      assert.deepEqual(observed.slice(0, pgTools.length).map(({ tool, args }) => ({ tool, args })),
        pgTools.map(tool => ({ tool, args: ["--version"] })));
      for (const call of observed) {
        assert.deepEqual(call.inherited, {}, `${call.tool} must not inherit any fake credential`);
        assert.equal(call.local.testMode, true);
        if (call.tool !== "mktemp" && call.args[0] !== "--version" &&
            call.tool !== "date" && !(call.tool === "mkdir" && call.args[1] === "generated-artifacts/recovery")) {
          assert.equal(call.local.root, true, `${call.tool} receives runner-owned root`);
          assert.equal(call.local.output, true, `${call.tool} receives runner-owned evidence path`);
        }
        const schema = call.tool === "pnpm" && call.args.includes("push-force");
        assert.equal(call.local.database, schema, "Only schema push receives the local database URL");
        assert.equal(call.local.databaseAbsent, !schema, "Schema URL must be unset for later commands");
      }
      const packageCalls = observed.filter(call => call.tool === "pnpm");
      const expectedPhases = ["seed",
        ...(fault === "restore-transaction" ? ["prepare-restore-transaction"] : []),
        "seal", "preflight",
        ...(fault === "restore-transaction" ? ["verify-restore-rollback"] :
          [...(fault === "membership" || fault === "audit" ? [`fault-${fault}`] : []), "verify"]),
      ];
      assert.deepEqual(packageCalls.map(call => call.args), [
        ["--filter", "@workspace/db", "run", "push-force"],
        ...expectedPhases.map(phase => ["--filter", "@workspace/scripts", "run", "recovery:fixtures", phase]),
      ]);
      for (const tool of ["initdb", "pg_ctl", "createdb", "pg_dump", "pg_restore"]) {
        assert.ok(observed.some(call => call.tool === tool && call.args[0] !== "--version"),
          `${tool} must reach its inert operational spy`);
      }
      assert.equal(observed.some(call => call.tool === "truncate"), fault === "archive");
      assert.equal(readFileSync(path.join(output, "status"), "utf8"), "PASS\n");
      assert.equal(readFileSync(path.join(output, "cleanup-status"), "utf8"), "PASS\n");
      assert.ok(!existsSync(temporary), "Inert clusters must be cleaned up");
    });
  }
});

test("fixture guards reject before any database connection, query or evidence write", async (t) => {
  const root = mkdtempSync("/tmp/recovery-");
  chmodSync(root, 0o700);
  const evidenceRoot = path.join(repo, "generated-artifacts/recovery");
  mkdirSync(evidenceRoot, { recursive: true, mode: 0o700 });
  const output = mkdtempSync(path.join(evidenceRoot, "safety-"));
  t.after(() => {
    rmSync(root, { recursive: true, force: true });
    rmSync(output, { recursive: true, force: true });
  });
  const log = path.join(root, "calls.jsonl");
  const preload = path.join(root, "database-spy.mjs");
  writeFileSync(preload, `
import pg from ${JSON.stringify(pathToFileURL(require.resolve("pg")).href)};
import { appendFileSync } from "node:fs";
for (const method of ["connect", "query"]) {
  pg.Client.prototype[method] = async function (...args) {
    appendFileSync(process.env.SAFETY_LOG, JSON.stringify({tool: method, args: []}) + "\\n");
    throw new Error("Synthetic database boundary");
  };
}
`);
  const marker = path.join(root, "owner-marker");
  const invoke = (args: string[], extra: NodeJS.ProcessEnv = {}) => {
    rmSync(log, { force: true });
    return run(process.execPath, [
      "--import", require.resolve("tsx"), "--import", preload,
      path.join(scripts, "src/recovery-fixtures.ts"), ...args,
    ], scripts, environment({
      RECOVERY_ROOT: root, RECOVERY_OUTPUT: output, SAFETY_LOG: log, ...extra,
    }));
  };
  const rejected = (args: string[], env: NodeJS.ProcessEnv, message: RegExp) => {
    const result = invoke(args, env);
    assert.equal(result.status, 1);
    assert.match(result.stderr, message);
    assert.deepEqual(calls(log), [], "No connection or SQL may run");
    assert.deepEqual(readdirSync(output), [], "No evidence/schema may be written");
  };
  writeFileSync(marker, "synthetic-recovery-v1\n", { mode: 0o600 });
  for (const phase of phases) {
    await t.test(`${phase}: production and deployment`, () => {
      rejected([phase], { NODE_ENV: "production" }, /Production runtime forbidden/);
      rejected([phase], { REPLIT_DEPLOYMENT: "1" }, /Deployment runtime forbidden/);
      rejected([phase], { REPLIT_DEPLOYMENT: "0" }, /Deployment runtime forbidden/);
    });
    await t.test(`${phase}: extra argument`, () => {
      rejected([phase, "--unsafe"], {}, /Exactly one rehearsal phase required/);
    });
  }
  await t.test("missing, unknown and option-shaped phases", () => {
    rejected([], {}, /Exactly one rehearsal phase required/);
    for (const phase of ["unknown", "--unsafe", "--fault=archive"]) {
      rejected([phase], {}, /Known rehearsal phase required/);
    }
  });
  for (const content of ["", "not-owned\n", "synthetic-recovery-v1", "synthetic-recovery-v2\n"]) {
    await t.test(`invalid ownership marker ${JSON.stringify(content)}`, () => {
      writeFileSync(marker, content);
      rejected(["seed"], {}, /Expected values to be strictly equal/);
    });
  }
  await t.test("missing ownership marker", () => {
    rmSync(marker);
    rejected(["seed"], {}, /Recovery phase failed/);
  });
  await t.test("nonprivate owned root", () => {
    writeFileSync(marker, "synthetic-recovery-v1\n");
    chmodSync(root, 0o755);
    try { rejected(["seed"], {}, /Private temporary directory required/); }
    finally { chmodSync(root, 0o700); }
  });
  await t.test("valid ownership reaches the inert database spy", () => {
    const result = invoke(["seed"]);
    assert.equal(result.status, 1);
    assert.deepEqual(calls(log), [{ tool: "connect", args: [] }]);
    assert.deepEqual(readdirSync(output), []);
  });
  await t.test("redirected and unapproved directories reject before phase work", async (t) => {
    // Reserve every path ourselves. Links point only at test-owned directories;
    // never redirect, rename or remove an existing operator directory.
    const rootLink = mkdtempSync("/tmp/recovery-");
    const evidenceTarget = mkdtempSync(path.join(evidenceRoot, "directory-safety-"));
    const evidenceLink = path.join(output, "redirected");
    const outsideOutput = path.join(root, "generated-artifacts/recovery-other/run");
    t.after(() => {
      rmSync(rootLink, { recursive: true, force: true });
      rmSync(evidenceLink, { recursive: true, force: true });
      rmSync(evidenceTarget, { recursive: true, force: true });
      rmSync(path.join(root, "generated-artifacts"), { recursive: true, force: true });
    });
    rmSync(rootLink, { recursive: true });
    symlinkSync(root, rootLink, "dir");
    symlinkSync(evidenceTarget, evidenceLink, "dir");
    mkdirSync(outsideOutput, { recursive: true, mode: 0o700 });

    // Apart from redirection, both targets satisfy the normal directory guards.
    assert.match(rootLink, /^\/tmp\/recovery-[a-zA-Z0-9]+$/);
    assert.equal(realpathSync(rootLink), root);
    assert.equal(statSync(rootLink).uid, process.getuid?.());
    assert.equal(statSync(rootLink).mode & 0o777, 0o700);
    assert.equal(readFileSync(path.join(rootLink, "owner-marker"), "utf8"), "synthetic-recovery-v1\n");
    assert.ok(evidenceLink.startsWith(evidenceRoot + "/"));
    assert.equal(realpathSync(evidenceLink), evidenceTarget);
    assert.equal(realpathSync(outsideOutput), outsideOutput);

    const cases = [
      { name: "symlinked recovery root", env: { RECOVERY_ROOT: rootLink },
        message: /Expected values to be strictly equal/ },
      { name: "symlinked evidence directory", env: { RECOVERY_OUTPUT: evidenceLink },
        message: /Expected values to be strictly equal/ },
      { name: "evidence outside approved location", env: { RECOVERY_OUTPUT: outsideOutput },
        message: /Ignored evidence directory required/ },
    ];
    for (const { name, env, message } of cases) {
      for (const phase of phases) {
        await t.test(`${phase}: ${name}`, () => {
          const result = invoke([phase], env);
          assert.equal(result.status, 1);
          assert.match(result.stderr, message, "The directory guard itself must reject");
          assert.deepEqual(calls(log), [], "No connection or SQL may run");
          assert.deepEqual(readdirSync(output), ["redirected"], "No evidence may be written at the valid output");
          assert.deepEqual(readdirSync(evidenceTarget), [], "No evidence may be written through the link");
          assert.deepEqual(readdirSync(outsideOutput), [], "No evidence may be written outside the approved location");
        });
      }
    }
    for (const validOutput of [output, evidenceTarget]) {
      await t.test(`real evidence directory reaches inert connection: ${path.basename(validOutput)}`, () => {
        const result = invoke(["seed"], { RECOVERY_OUTPUT: validOutput });
        assert.equal(result.status, 1);
        assert.match(result.stderr, /Recovery phase failed/);
        assert.deepEqual(calls(log), [{ tool: "connect", args: [] }],
          "Real owned root and approved real evidence directory must pass the guards");
        assert.deepEqual(readdirSync(evidenceTarget), []);
        assert.deepEqual(readdirSync(output), ["redirected"]);
      });
    }
    await t.test("real approved directory permits synthetic archive sealing without a database", () => {
      const manifest = path.join(evidenceTarget, "manifest.json");
      writeFileSync(manifest, '{"archiveSha256":""}\n', { mode: 0o600 });
      writeFileSync(path.join(evidenceTarget, "foundation.dump"), "", { mode: 0o600 });
      const result = invoke(["seal"], { RECOVERY_OUTPUT: evidenceTarget });
      assert.equal(result.status, 0, result.stderr);
      assert.deepEqual(calls(log), [], "Sealing must never use the database");
      assert.deepEqual(JSON.parse(readFileSync(manifest, "utf8")), {
        archiveSha256: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      }, "Valid directories must allow the expected evidence update");
      assert.deepEqual(readdirSync(evidenceTarget).sort(), ["foundation.dump", "manifest.json"]);
      assert.deepEqual(readdirSync(output), ["redirected"]);
      assert.deepEqual(readdirSync(outsideOutput), []);
    });
  });
});

test("connected fixture targets are checked and closed before seed or fault SQL", async (t) => {
  const root = mkdtempSync("/tmp/recovery-");
  chmodSync(root, 0o700);
  writeFileSync(path.join(root, "owner-marker"), "synthetic-recovery-v1\n", { mode: 0o600 });
  const evidenceRoot = path.join(repo, "generated-artifacts/recovery");
  mkdirSync(evidenceRoot, { recursive: true, mode: 0o700 });
  const output = mkdtempSync(path.join(evidenceRoot, "connected-safety-"));
  t.after(() => {
    rmSync(root, { recursive: true, force: true });
    rmSync(output, { recursive: true, force: true });
  });
  const log = path.join(root, "calls.jsonl");
  const preload = path.join(root, "connected-database-spy.mjs");
  const identitySql = "SELECT current_database() AS db, current_user AS usr, inet_server_addr() AS addr, current_setting('data_directory') AS directory";
  const versionSql = "SHOW server_version_num";
  // Replace the entire Client, not just query(): no original pg method can
  // open a socket, authenticate or execute SQL even when a guard regresses.
  writeFileSync(preload, `
import pg from ${JSON.stringify(pathToFileURL(require.resolve("pg")).href)};
import { appendFileSync } from "node:fs";
const record = (tool, args = []) =>
  appendFileSync(process.env.SAFETY_LOG, JSON.stringify({tool, args}) + "\\n");
pg.Client = class {
  constructor(options) { record("client", [options]); }
  async connect() { record("connect"); }
  async query(sql) {
    record("query", [sql]);
    if (sql === ${JSON.stringify(identitySql)}) {
      if (process.env.SYNTHETIC_CHECK_FAILURE === "identity-query") throw new Error("Synthetic identity query rejection");
      if (process.env.SYNTHETIC_CHECK_FAILURE === "identity-missing-row") return { rows: [] };
      return { rows: [JSON.parse(process.env.SYNTHETIC_IDENTITY)] };
    }
    if (sql === ${JSON.stringify(versionSql)}) {
      if (process.env.SYNTHETIC_CHECK_FAILURE === "version-query") throw new Error("Synthetic version query rejection");
      if (process.env.SYNTHETIC_CHECK_FAILURE === "version-missing-row") return { rows: [] };
      return { rows: [{ server_version_num: process.env.SYNTHETIC_VERSION }] };
    }
    throw new Error("Synthetic post-validation SQL boundary");
  }
  async end() {
    record("end-start");
    await new Promise(resolve => setTimeout(resolve, 10));
    record("end-complete");
  }
};
`);
  const connectedPhases = [
    { phase: "seed", target: "source", firstSql: 'SELECT count(*)::int AS n FROM "organizations"' },
    { phase: "fault-membership", target: "restore", firstSql: "UPDATE practice_memberships SET active = true WHERE user_id = $1" },
    { phase: "fault-audit", target: "restore", firstSql: "UPDATE administrator_bootstrap_audits SET provider_subject = 'synthetic-broken-link'" },
    { phase: "prepare-restore-transaction", target: "source", firstSql: "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename" },
  ] as const;
  for (const { phase, target, firstSql } of connectedPhases) {
    const identity = {
      db: "recovery_fixture_test", usr: "recovery_fixture",
      addr: null, directory: path.join(root, target, "pg"),
    };
    const prefix = [
      { tool: "client", args: [{
        host: path.join(root, target, "socket"), port: 25433,
        user: "recovery_fixture", database: "recovery_fixture_test",
        password: "", ssl: false, connectionTimeoutMillis: 5000,
        options: "-c statement_timeout=10000 -c search_path=public",
      }] },
      { tool: "connect", args: [] },
      { tool: "query", args: [identitySql] },
    ];
    const closed = [
      { tool: "end-start", args: [] },
      { tool: "end-complete", args: [] },
    ];
    const invoke = (changes: Record<string, unknown>, version = "160006", checkFailure = "") => {
      rmSync(log, { force: true });
      return run(process.execPath, [
        "--import", require.resolve("tsx"), "--import", preload,
        path.join(scripts, "src/recovery-fixtures.ts"), phase,
      ], scripts, environment({
        RECOVERY_ROOT: root, RECOVERY_OUTPUT: output, SAFETY_LOG: log,
        SYNTHETIC_IDENTITY: JSON.stringify({ ...identity, ...changes }),
        SYNTHETIC_VERSION: version,
        SYNTHETIC_CHECK_FAILURE: checkFailure,
      }));
    };
    const mismatches = [
      { name: "wrong database", changes: { db: "other_synthetic_database" } },
      { name: "wrong user", changes: { usr: "other_synthetic_user" } },
      { name: "TCP address", changes: { addr: "127.0.0.1" } },
      { name: "wrong data directory", changes: { directory: path.join(root, target === "source" ? "restore" : "source", "pg") } },
    ];
    for (const { name, changes } of mismatches) {
      await t.test(`${phase}: rejects ${name}`, () => {
        const result = invoke(changes);
        assert.equal(result.status, 1);
        assert.match(result.stderr, /Expected values to be strictly deep-equal/);
        assert.deepEqual(calls(log), [...prefix, ...closed],
          "Identity rejection must await close without version, seed or fault SQL");
        assert.deepEqual(readdirSync(output), [], "Rejected target cannot write evidence");
      });
    }
    for (const version of ["150009", "170002"]) {
      await t.test(`${phase}: rejects PostgreSQL ${version}`, () => {
        const result = invoke({}, version);
        assert.equal(result.status, 1);
        assert.match(result.stderr, /Only PostgreSQL 16 clusters permitted/);
        assert.deepEqual(calls(log), [
          ...prefix, { tool: "query", args: [versionSql] }, ...closed,
        ], "Version rejection must await close without seed or fault SQL");
        assert.deepEqual(readdirSync(output), []);
      });
    }
    const checkFailures = [
      { failure: "identity-query", reachesVersion: false, message: /Recovery phase failed/ },
      { failure: "identity-missing-row", reachesVersion: false, message: /Expected values to be strictly deep-equal/ },
      { failure: "version-query", reachesVersion: true, message: /Recovery phase failed/ },
      { failure: "version-missing-row", reachesVersion: true, message: /Recovery phase failed/ },
    ];
    for (const { failure, reachesVersion, message } of checkFailures) {
      await t.test(`${phase}: closes after ${failure}`, () => {
        const result = invoke({}, "160006", failure);
        assert.equal(result.status, 1);
        assert.match(result.stderr, message);
        assert.deepEqual(calls(log), [
          ...prefix,
          ...(reachesVersion ? [{ tool: "query", args: [versionSql] }] : []),
          ...closed,
        ], "Failed metadata check must complete close exactly once without seed or fault SQL");
        assert.deepEqual(readdirSync(output), [], "Failed metadata check cannot write evidence or schema");
      });
    }
    await t.test(`${phase}: matching target reaches only the inert SQL boundary`, () => {
      const result = invoke({});
      assert.equal(result.status, 1);
      assert.match(result.stderr, /Recovery phase failed/);
      assert.deepEqual(calls(log), [
        ...prefix, { tool: "query", args: [versionSql] },
        { tool: "query", args: [firstSql] }, ...closed,
      ], "Valid identity must pass both checks before phase SQL");
      assert.deepEqual(readdirSync(output), []);
    });
  }
});

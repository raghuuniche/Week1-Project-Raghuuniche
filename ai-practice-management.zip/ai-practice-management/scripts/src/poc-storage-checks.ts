import assert from "node:assert/strict";
import type { Browser, Page } from "playwright";
import { absent, disposable, fill, start, state, storageFaults, storageKey, visibleIds } from "./poc-browser-harness";

const readWarning = "Saved demo data in this tab could not be read, so the seed data was loaded instead.";
const writeWarning = "Could not save demo changes in this browser tab. Changes will be lost on reload.";
const clearWarning = "This browser blocked clearing the tab's synthetic demo data. Close this tab to discard it.";
const protectedPaths = ["/poc", "/poc/pipeline", "/poc/delivery", "/poc/goals", "/poc/reports", "/poc/access"];
const marker = "Synthetic storage failure opportunity";

async function warning(page: Page, id: string, message: string) {
  const alert = page.getByTestId(id);
  await alert.waitFor();
  assert.equal(await alert.getAttribute("role"), "alert");
  assert.equal(await alert.innerText(), message);
}

async function createOpportunity(page: Page) {
  await page.getByTestId("button-new-opportunity").click();
  await fill(page, {
    "input-opp-name": marker, "input-opp-client": "Synthetic client",
    "input-opp-owner": "Synthetic alias", "input-opp-value": "12345",
    "input-opp-close": "2026-12-15",
  });
  await page.getByTestId("button-save-opportunity").click();
  await page.getByTestId("dialog-opportunity").waitFor({ state: "hidden" });
  await page.getByRole("cell", { name: marker, exact: true }).waitFor();
}

async function signedOut(page: Page) {
  await page.getByTestId("button-start-demo").waitFor();
  await absent(page, "select-preview-role", "select-practice", "nav-poc", "poc-notice",
    "table-pipeline", "table-delivery", "table-goals", "table-report-stage",
    "stat-open-pipeline", "stat-projects", "stat-goal-progress", "report-total-count",
    "button-new-opportunity", "button-new-project", "button-new-goal", "alert-storage");
  assert.equal(await page.getByText(marker, { exact: true }).count(), 0, "Ended records must not remain in the protected UI");
  assert.equal(await page.locator('[data-testid^="row-opportunity-"], [data-testid^="row-project-"], [data-testid^="row-goal-"], [data-testid^="dash-goal-"]').count(), 0);
}

export async function storageChecks(browser: Browser) {
  // Compare fallback with the healthy store's complete fixture, not just a row count.
  let seed: Awaited<ReturnType<typeof state>>;
  await disposable(browser, async (page) => {
    await start(page);
    seed = await state(page);
    assert.equal(seed.role, "executive");
    assert.equal(seed.practiceId, "p1");
    assert.equal(seed.opps.length, 11);
    assert.equal(seed.projects.length, 7);
    assert.equal(seed.goals.length, 7);
  });

  for (const corrupt of ["{not valid saved JSON", JSON.stringify({ role: "not-a-role", practiceId: "p1", opps: [], projects: [], goals: [] })]) {
    await disposable(browser, async (page) => {
      await start(page);
      await page.evaluate(({ key, corrupt }) => sessionStorage.setItem(key, corrupt), { key: storageKey, corrupt });
      await page.reload();
      await warning(page, "alert-storage", readWarning);
      assert.deepEqual(await state(page), seed!, "Unreadable saved state must be replaced with the complete seed");
      await page.goto("/poc/pipeline");
      await visibleIds(page, "row-opportunity-", seed!.opps.map((o) => o.id));
      await absent(page, "alert-storage"); // Repaired saved state loads cleanly on the next navigation.
    });
  }
  console.log("PASS: corrupt JSON and invalid saved shape load complete seeds with an explicit read warning");

  await disposable(browser, async (page, context) => {
    await storageFaults(context, { blockWrites: true });
    await start(page);
    await warning(page, "alert-storage", writeWarning);
    assert.equal(await page.evaluate((key) => sessionStorage.getItem(key), storageKey), null);
    assert.ok(await page.evaluate(() => window.__pocStorageFaults.failedWrites > 0), "Initial save must hit the injected failure");
    await page.goto("/poc/pipeline");
    await warning(page, "alert-storage", writeWarning);
    await visibleIds(page, "row-opportunity-", seed!.opps.map((o) => o.id));
    // Do not use role()/state(): with writes blocked, persisted state is not live React state.
    await page.getByTestId("select-preview-role").selectOption("practice_director");
    await page.getByTestId("button-new-opportunity").waitFor();
    await createOpportunity(page);
    await warning(page, "alert-storage", writeWarning);
    assert.equal(await page.evaluate((key) => sessionStorage.getItem(key), storageKey), null);
    await page.reload();
    await warning(page, "alert-storage", writeWarning);
    await visibleIds(page, "row-opportunity-", seed!.opps.map((o) => o.id));
    assert.equal(await page.getByTestId("select-preview-role").inputValue(), "executive");
    assert.equal(await page.getByText(marker, { exact: true }).count(), 0, "Unsaved edits are lost on reload, as warned");

    // Recovery: a later successful state change saves and dismisses the save warning.
    await page.evaluate(() => { window.__pocStorageFaults.blockWrites = false; });
    await page.getByTestId("select-preview-role").selectOption("practice_director");
    await page.waitForFunction((key) => sessionStorage.getItem(key) !== null && !document.querySelector('[data-testid="alert-storage"]'), storageKey);
    assert.deepEqual(await state(page), { ...seed!, role: "practice_director" });
    await page.getByTestId("button-logout").click();
    await signedOut(page);
    await page.waitForFunction((key) => sessionStorage.getItem(key) === null, storageKey);
    await absent(page, "alert-demo-clear");
  });
  console.log("PASS: blocked writes warn, keep in-memory edits usable, lose them on reload, and recover without server writes");

  await disposable(browser, async (page, context) => {
    await start(page);
    await page.getByTestId("select-preview-role").selectOption("practice_director");
    await page.waitForFunction((key) => JSON.parse(sessionStorage.getItem(key)!).role === "practice_director", storageKey);
    const saved = await state(page);
    await storageFaults(context, { blockWrites: true });
    await page.goto("/poc/pipeline");
    await warning(page, "alert-storage", writeWarning);
    const beforeEdit = await page.evaluate(() => window.__pocStorageFaults.failedWrites);
    await createOpportunity(page);
    await page.waitForFunction((before) => window.__pocStorageFaults.failedWrites > before, beforeEdit);
    assert.deepEqual(await state(page), saved, "A failed write must preserve the last successfully saved snapshot");
    await page.reload();
    await warning(page, "alert-storage", writeWarning);
    await visibleIds(page, "row-opportunity-", saved.opps.filter((o) => o.practiceId === "p1").map((o) => o.id));
    assert.equal(await page.getByText(marker, { exact: true }).count(), 0);
    assert.deepEqual(await state(page), saved);
    await page.getByTestId("button-logout").click();
    await signedOut(page);
    await page.waitForFunction((key) => sessionStorage.getItem(key) === null, storageKey);
    await absent(page, "alert-demo-clear");
  });
  console.log("PASS: blocked edits preserve the last saved snapshot and End demo still clears it");

  await disposable(browser, async (page, context) => {
    await storageFaults(context, { blockRemoval: true });
    await start(page);
    await page.getByTestId("select-preview-role").selectOption("practice_director");
    await page.goto("/poc/pipeline");
    await createOpportunity(page);
    await page.waitForFunction(({ key, marker }) => JSON.parse(sessionStorage.getItem(key)!).opps.some((o: { name: string }) => o.name === marker), { key: storageKey, marker });
    const saved = await state(page);
    const beforeEnd = await page.evaluate(() => window.__pocStorageFaults.failedRemovals);
    await page.getByTestId("button-logout").click();
    await signedOut(page);
    await warning(page, "alert-demo-clear", clearWarning);
    assert.ok(await page.evaluate((before) => window.__pocStorageFaults.failedRemovals > before, beforeEnd), "End demo must hit the injected removal failure");
    assert.deepEqual(await state(page), saved, "Blocked removal leaves bytes, not active protected access");
    // Reload and direct URL entry must not remount stale records while signed out.
    await page.reload();
    await signedOut(page);
    await warning(page, "alert-demo-clear", clearWarning);
    for (const path of protectedPaths) {
      await page.goto(path);
      await signedOut(page);
      await warning(page, "alert-demo-clear", clearWarning);
      assert.deepEqual(await state(page), saved);
    }
  });
  console.log("PASS: blocked End demo removal warns while unmounting protected records, including reload and direct routes");
}

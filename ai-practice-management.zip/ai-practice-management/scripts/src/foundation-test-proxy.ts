// CI-only same-origin router. The product uses Replit's managed artifact router.
import { createServer, request } from "node:http";

createServer((req, res) => {
  const port = req.url === "/api" || req.url?.startsWith("/api/") ? 25001 : 25002;
  const upstream = request({
    hostname: "127.0.0.1",
    port,
    path: req.url,
    method: req.method,
    headers: req.headers,
  }, (reply) => {
    res.writeHead(reply.statusCode ?? 502, reply.headers);
    reply.pipe(res);
  });
  upstream.on("error", () => {
    res.writeHead(502);
    res.end("Foundation test service unavailable");
  });
  req.pipe(upstream);
}).listen(25000, "127.0.0.1", () => {
  process.stdout.write("Foundation test router ready\n");
});

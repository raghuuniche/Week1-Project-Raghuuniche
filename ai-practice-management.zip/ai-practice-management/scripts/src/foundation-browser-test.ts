import assert from "node:assert/strict";
import { mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import { chromium } from "playwright";

const baseURL = process.env.FOUNDATION_BASE_URL ?? "http://localhost:80";
const output = new URL("../../generated-artifacts/foundation-gate/", import.meta.url).pathname;
// Fail promptly if the required API is missing or demo mode was not configured.
const status = await fetch(new URL("/api/auth/status", baseURL), { signal: AbortSignal.timeout(10_000) });
assert.equal(status.status, 200, "Foundation API must be running");
const configuration = await status.json() as { demoAvailable?: boolean };
assert.equal(configuration.demoAvailable, true, "Browser checks require explicit demo mode");
await mkdir(output, { recursive: true });
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH ?? (existsSync("/repl/tools/bin/chromium") ? "/repl/tools/bin/chromium" : undefined),
  args: ["--no-sandbox"],
});
try {
  for (const viewport of [{ width: 1440, height: 900 }, { width: 390, height: 844 }]) {
    const context = await browser.newContext({ baseURL, viewport });
    context.setDefaultTimeout(10_000);
    const page = await context.newPage();
    const errors: string[] = [];
    page.on("pageerror", (error) => errors.push(error.message));
    await page.goto("/");
    await page.getByTestId("button-start-demo").waitFor();
    assert.equal(await page.getByTestId("banner-demo").count(), 0);
    assert.equal((await context.request.get("/api/foundation")).status(), 401);
    await page.getByTestId("button-start-demo").click();
    await page.getByTestId("banner-demo").waitFor();
    await page.getByTestId("text-scope").waitFor();
    assert.equal((await context.request.get("/api/foundation")).status(), 200);
    assert.equal((await context.request.get("/api/practices/11111111-1111-1111-1111-111111111111/access")).status(), 403);
    assert.equal((await context.request.get("/api/admin/setup")).status(), 403);
    assert.match(await page.getByTestId("fact-data").innerText(), /None/);
    assert.match(await page.getByTestId("fact-admin").innerText(), /None/);
    assert.match(await page.getByTestId("fact-identity").innerText(), /No/);
    assert.match(await page.getByTestId("fact-modules").innerText(), /Not enabled/);
    assert.equal(await page.evaluate<boolean>("document.documentElement.scrollWidth <= window.innerWidth"), true);
    await page.screenshot({ path: `${output}/foundation-active-${viewport.width}.jpg` });
    await page.reload();
    await page.getByTestId("text-scope").waitFor();
    if (viewport.width < 768) await page.getByTestId("button-menu").click();
    await page.locator('a[href="/account"]:visible').first().click();
    await page.getByText("Pilot User", { exact: true }).waitFor();
    await page.goto("/security");
    await page.getByTestId("panel-entra").waitFor();
    await page.goto("/access-denied");
    await page.getByTestId("status-no-access").waitFor();
    await page.getByTestId("link-account").click();
    await page.getByText("Pilot User", { exact: true }).waitFor();
    await page.goto("/does-not-exist");
    assert.match(await page.locator("main").innerText(), /not found|nothing|couldn.t find|does not exist/i);
    await page.goto("/");
    await page.getByTestId("text-scope").waitFor();
    await page.getByTestId("button-logout").click();
    await page.getByTestId("button-start-demo").waitFor();
    assert.equal(await page.getByTestId("panel-foundation").count(), 0);
    assert.equal((await context.request.get("/api/foundation")).status(), 401);
    await page.reload();
    await page.getByTestId("button-start-demo").waitFor();
    assert.equal(await page.getByTestId("banner-demo").count(), 0);
    await page.goto("/account");
    await page.getByTestId("button-start-demo").waitFor();
    assert.equal(await page.getByText("Pilot User", { exact: true }).count(), 0);
    assert.deepEqual(errors, []);
    await context.close();
    process.stdout.write(`Verified ${viewport.width}px: explicit demo entry, persisted session, navigation, no-access, not-found, and logout.\n`);
  }
} finally {
  await browser.close();
}

import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile, stat, realpath } from "node:fs/promises";
import path from "node:path";
import pg from "pg";

// No import of @workspace/db's runtime pool: never falls back to DATABASE_URL.
const tables = [
  "organizations", "practices", "users", "identity_links",
  "practice_memberships", "global_administrator_grants", "administrator_bootstrap_audits",
  "business_records", "business_audits", "business_imports", "authentication_sessions",
] as const;
const expectedCounts = [2, 3, 8, 8, 7, 1, 1, 4, 2, 1, 1];
const roles = ["executive", "practice_director", "manager", "team_member", "administrator"];
const id = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
const issuer = "https://recovery-fixture.invalid/tenant";
const operator = "synthetic-recovery-operator";
type Snapshot = Record<string, unknown[]>;
type Manifest = { format: number; syntheticOnly: boolean; snapshot: Snapshot; archiveSha256: string; postgresVersion: string };

class RecoveryFailure extends Error {
  constructor(readonly code: string, message: string) {
    super(message);
  }
}

function recoveryEqual(actual: unknown, expected: unknown, code: string, message: string) {
  try {
    assert.deepEqual(actual, expected, message);
  } catch (error) {
    if (error instanceof assert.AssertionError) throw new RecoveryFailure(code, message);
    throw error;
  }
}

async function paths() {
  assert.notEqual(process.env.NODE_ENV, "production", "Production runtime forbidden");
  assert.ok(!process.env.REPLIT_DEPLOYMENT, "Deployment runtime forbidden");
  const root = process.env.RECOVERY_ROOT ?? "";
  const output = process.env.RECOVERY_OUTPUT ?? "";
  assert.match(root, /^\/tmp\/recovery-[a-zA-Z0-9]+$/, "Owned temporary directory required");
  assert.equal(await realpath(root), root);
  const metadata = await stat(root);
  assert.equal(metadata.uid, process.getuid?.(), "Directory must belong to this operator");
  assert.equal(metadata.mode & 0o777, 0o700, "Private temporary directory required");
  assert.equal(await readFile(path.join(root, "owner-marker"), "utf8"), "synthetic-recovery-v1\n");
  assert.ok(output.startsWith(path.resolve("..", "generated-artifacts/recovery") + "/"), "Ignored evidence directory required");
  // pnpm --filter runs in scripts/, so evidence must resolve under repo root.
  assert.equal(await realpath(output), output);
  return { root, output };
}

async function connect(target: "source" | "restore", root: string) {
  const socket = path.join(root, target, "socket");
  const client = new pg.Client({
    host: socket, port: 25433, user: "recovery_fixture", database: "recovery_fixture_test",
    password: "", ssl: false, connectionTimeoutMillis: 5000,
    options: "-c statement_timeout=10000 -c search_path=public",
  });
  await client.connect();
  try {
    const result = await client.query("SELECT current_database() AS db, current_user AS usr, inet_server_addr() AS addr, current_setting('data_directory') AS directory");
    assert.deepEqual(result.rows[0], { db: "recovery_fixture_test", usr: "recovery_fixture", addr: null, directory: path.join(root, target, "pg") });
    const version = await client.query("SHOW server_version_num");
    assert.equal(Math.floor(Number(version.rows[0].server_version_num) / 10000), 16, "Only PostgreSQL 16 clusters permitted");
    return client;
  } catch (error) {
    await client.end();
    throw error;
  }
}

async function snapshot(client: pg.Client): Promise<Snapshot> {
  const actualTables = await client.query("SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename");
  assert.deepEqual(actualTables.rows.map((row) => row.tablename), [...tables].sort(), "Only the foundation and shared business tables may be present");
  const result: Snapshot = {};
  for (const [index, table] of tables.entries()) {
    // Identifiers are from the hardcoded allowlist; jsonb preserves every field,
    // including identity bindings, audit operator and timestamps.
    const rows = await client.query(`SELECT to_jsonb(t) AS record FROM "${table}" t ORDER BY to_jsonb(t)::text`);
    assert.equal(rows.rowCount, expectedCounts[index], `${table} count`);
    result[table] = rows.rows.map((row) => row.record);
  }
  return result;
}

// Include every non-system schema, not just foundation tables: rollback must
// remove functions, types, indexes, constraints and any newly created schema.
async function emptyTarget(client: pg.Client) {
  const result = await client.query(`
    SELECT n.nspname AS schema,
      (SELECT count(*)::int FROM pg_class WHERE relnamespace = n.oid) AS relations,
      (SELECT count(*)::int FROM pg_proc WHERE pronamespace = n.oid) AS functions,
      (SELECT count(*)::int FROM pg_type WHERE typnamespace = n.oid) AS types,
      (SELECT count(*)::int FROM pg_constraint WHERE connamespace = n.oid) AS constraints
    FROM pg_namespace n
    WHERE n.nspname !~ '^pg_' AND n.nspname <> 'information_schema'
    ORDER BY n.nspname`);
  assert.deepEqual(result.rows, [{
    schema: "public", relations: 0, functions: 0, types: 0, constraints: 0,
  }], "Disposable restore database must contain no user schema objects or records");
  return result.rows;
}

async function prepareRestoreTransaction(client: pg.Client) {
  // Build a valid expression index, then deliberately change its immutable
  // function's semantics without rebuilding it. The archive contains the final
  // constant function and the original index definition: reconstruction fails
  // in post-data, after all table data has been successfully loaded.
  await snapshot(client);
  await client.query(`
    CREATE FUNCTION public.recovery_restore_key(uuid) RETURNS uuid
    LANGUAGE sql IMMUTABLE STRICT AS 'SELECT $1';
    CREATE UNIQUE INDEX recovery_restore_transaction_unique
      ON public.users (public.recovery_restore_key(id));
    CREATE OR REPLACE FUNCTION public.recovery_restore_key(uuid) RETURNS uuid
    LANGUAGE sql IMMUTABLE STRICT
      AS 'SELECT ''00000000-0000-4000-8000-000000000000''::uuid';
  `);
}

async function seed(client: pg.Client) {
  for (const table of tables) {
    const count = await client.query(`SELECT count(*)::int AS n FROM "${table}"`);
    assert.equal(count.rows[0].n, 0, "Source must be empty before synthetic fixtures");
  }
  await client.query("BEGIN");
  try {
    for (const n of [1, 2]) {
      await client.query("INSERT INTO organizations (id, name) VALUES ($1, $2)", [id(n), `Synthetic recovery organization ${n}`]);
    }
    for (const [n, org] of [[11, 1], [12, 1], [13, 2]]) {
      await client.query("INSERT INTO practices (id, organization_id, name, slug) VALUES ($1, $2, $3, $4)", [id(n!), id(org!), `Synthetic practice ${n}`, `synthetic-${n}`]);
    }
    for (let n = 0; n < 8; n++) {
      await client.query("INSERT INTO users (id, status) VALUES ($1, $2)", [id(100 + n), n === 7 ? "disabled" : "active"]);
      await client.query("INSERT INTO identity_links (id, user_id, issuer, subject) VALUES ($1, $2, $3, $4)", [id(200 + n), id(100 + n), issuer, `synthetic-subject-${n}`]);
      if (n < 5 || n > 5) {
        await client.query("INSERT INTO practice_memberships (user_id, practice_id, role, active) VALUES ($1, $2, $3, $4)", [id(100 + n), id(11), roles[n] ?? "team_member", n !== 6]);
      }
    }
    // Fixtures, not a real bootstrap: reserved .invalid issuer, no company IDs.
    await client.query("INSERT INTO global_administrator_grants (user_id, granted_by_operator) VALUES ($1, $2)", [id(105), operator]);
    await client.query("INSERT INTO administrator_bootstrap_audits (administrator_user_id, provider_issuer, provider_subject, created_by_operator) VALUES ($1, $2, $3, $4)", [id(105), issuer, "synthetic-subject-5", operator]);
    await client.query(`INSERT INTO business_records
      (id,organization_id,practice_id,kind,name,client,name_key,client_key,assigned_user_id,due_date,stage,value,probability,version)
      VALUES ($1,$2,$3,'pipeline','Synthetic opportunity','Synthetic client','synthetic opportunity','synthetic client',$4,'2026-10-10','Proposal',100.01,55,2)`,
      [id(400), id(1), id(11), id(102)]);
    await client.query(`INSERT INTO business_records
      (id,organization_id,practice_id,kind,name,client,assigned_user_id,due_date,status,budget,burn)
      VALUES ($1,$2,$3,'delivery','Synthetic assigned project','Synthetic client',$4,'2026-10-10','At risk',500,100)`,
      [id(401), id(1), id(11), id(103)]);
    await client.query(`INSERT INTO business_records
      (id,organization_id,practice_id,kind,name,assigned_user_id,due_date,current,target,unit)
      VALUES ($1,$2,$3,'goal','Synthetic goal',$4,'2026-10-10',2,2,'units')`,
      [id(402), id(1), id(11), id(103)]);
    await client.query(`INSERT INTO business_records
      (id,organization_id,practice_id,kind,name,client,name_key,client_key,assigned_user_id,due_date,stage,value,probability,deleted_at)
      VALUES ($1,$2,$3,'pipeline','Synthetic retained deletion','Synthetic client','synthetic retained deletion','synthetic client',$4,'2026-10-10','Won',42.50,100,now())`,
      [id(403), id(1), id(11), id(102)]);
    await client.query(`INSERT INTO business_audits (id,practice_id,actor_user_id,record_id,action,"before","after")
      SELECT $1,$2,$3,id,'update',to_jsonb(r)||'{"version":1}'::jsonb,to_jsonb(r) FROM business_records r WHERE id=$4`,
      [id(500), id(11), id(101), id(400)]);
    await client.query(`INSERT INTO business_audits (id,practice_id,actor_user_id,action,"after")
      VALUES ($1,$2,$3,'import_confirmation','{"inserted":1,"skipped":0}')`, [id(501), id(11), id(102)]);
    await client.query(`INSERT INTO business_imports (practice_id,actor_user_id,key,payload_hash,result)
      VALUES ($1,$2,$3,$4,'{"inserted":1,"skipped":0}')`, [id(11), id(102), id(700), "a".repeat(64)]);
    // Deliberately expired metadata, not a usable sign-in/session credential.
    await client.query(`INSERT INTO authentication_sessions (id_hash,data,expires_at)
      VALUES ($1,'{"syntheticRecoveryFixture":true}','2000-01-01')`, ["b".repeat(64)]);
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  }
}

// Verify restored relational access semantics; this is not Microsoft sign-in.
// Joins deliberately match the foundation's active identity/membership rules.
async function verifyBoundaries(client: pg.Client) {
  const ownDelivery = await client.query(`SELECT id,budget::text,burn::text FROM business_records
    WHERE practice_id=$1 AND assigned_user_id=$2 AND kind='delivery' AND deleted_at IS NULL`, [id(11), id(103)]);
  recoveryEqual(ownDelivery.rows, [{ id: id(401), budget: "500.00", burn: "100.00" }], "BUSINESS_ASSIGNMENT_BROKEN", "Restored assignment and exact money must match");
  const otherPractice = await client.query("SELECT id FROM business_records WHERE practice_id=$1", [id(13)]);
  recoveryEqual(otherPractice.rows, [], "BUSINESS_SCOPE_BROKEN", "Unrelated practice must not gain business records");
  const live = await client.query("SELECT value::text,version FROM business_records WHERE kind='pipeline' AND deleted_at IS NULL");
  recoveryEqual(live.rows, [{ value: "100.01", version: 2 }], "BUSINESS_HISTORY_BROKEN", "Restored active and deleted versions must remain distinct");
  async function role(subject: string, practice: number, provider = issuer) {
    const result = await client.query(
      `SELECT m.role FROM identity_links l
       JOIN users u ON u.id = l.user_id AND u.status = 'active'
       JOIN practice_memberships m ON m.user_id = u.id AND m.active = true AND m.practice_id = $3
       WHERE l.issuer = $1 AND l.subject = $2`, [provider, subject, id(practice)],
    );
    return result.rows[0]?.role ?? null;
  }
  for (let n = 0; n < 5; n++) {
    assert.equal(await role(`synthetic-subject-${n}`, 11), roles[n], "Assigned role survives");
    assert.equal(await role(`synthetic-subject-${n}`, 12), null, "Same-organization unassigned practice denied");
    assert.equal(await role(`synthetic-subject-${n}`, 13), null, "Other organization denied");
  }
  assert.equal(await role("synthetic-subject-5", 11), null, "Global Administrator is not a practice member");
  recoveryEqual(await role("synthetic-subject-6", 11), null, "INACTIVE_MEMBERSHIP_ALLOWED", "Inactive membership denied");
  assert.equal(await role("synthetic-subject-7", 11), null, "Disabled user denied");
  assert.equal(await role("unknown", 11), null, "Unknown identity denied");
  assert.equal(await role("synthetic-subject-0", 11, "https://wrong-issuer.invalid"), null, "Issuer mismatch denied");
  const grant = await client.query(
    `SELECT l.subject FROM identity_links l JOIN users u ON u.id = l.user_id AND u.status = 'active'
     JOIN global_administrator_grants g ON g.user_id = u.id WHERE l.issuer = $1 ORDER BY l.subject`, [issuer],
  );
  assert.deepEqual(grant.rows, [{ subject: "synthetic-subject-5" }], "Only the synthetic global Administrator has the grant");
  const audit = await client.query(
    `SELECT a.singleton, a.created_by_operator, a.provider_issuer, a.provider_subject
     FROM administrator_bootstrap_audits a
     JOIN global_administrator_grants g ON g.user_id = a.administrator_user_id
     JOIN identity_links l ON l.user_id = a.administrator_user_id
       AND l.issuer = a.provider_issuer AND l.subject = a.provider_subject`,
  );
  recoveryEqual(audit.rows, [{ singleton: 1, created_by_operator: operator, provider_issuer: issuer, provider_subject: "synthetic-subject-5" }], "AUDIT_IDENTITY_BINDING_BROKEN", "Singleton audit remains linked to grant and identity");
  const practices = await client.query("SELECT id, organization_id FROM practices ORDER BY id");
  assert.deepEqual(practices.rows, [11, 12, 13].map((n) => ({ id: id(n), organization_id: id(n === 13 ? 2 : 1) })));
}

async function verifyConstraints(client: pg.Client) {
  const cases: [string, string, unknown[], string][] = [
    ["identity uniqueness", "INSERT INTO identity_links (user_id, issuer, subject) VALUES ($1, $2, $3)", [id(100), issuer, "synthetic-subject-0"], "23505"],
    ["membership uniqueness", "INSERT INTO practice_memberships (user_id, practice_id, role) VALUES ($1, $2, 'manager')", [id(100), id(11)], "23505"],
    ["membership user FK", "INSERT INTO practice_memberships (user_id, practice_id, role) VALUES ($1, $2, 'manager')", [id(999), id(11)], "23503"],
    ["membership practice FK", "INSERT INTO practice_memberships (user_id, practice_id, role) VALUES ($1, $2, 'manager')", [id(100), id(999)], "23503"],
    ["practice organization FK", "INSERT INTO practices (organization_id, name, slug) VALUES ($1, 'Synthetic', 'bad')", [id(999)], "23503"],
    ["identity user FK", "INSERT INTO identity_links (user_id, issuer, subject) VALUES ($1, $2, 'bad')", [id(999), issuer], "23503"],
    ["grant user FK", "INSERT INTO global_administrator_grants (user_id, granted_by_operator) VALUES ($1, $2)", [id(999), operator], "23503"],
    ["audit user FK", "UPDATE administrator_bootstrap_audits SET administrator_user_id = $1", [id(999)], "23503"],
    ["role check", "UPDATE practice_memberships SET role = 'owner' WHERE user_id = $1", [id(100)], "23514"],
    ["status check", "UPDATE users SET status = 'invalid' WHERE id = $1", [id(100)], "23514"],
    ["audit singleton check", "UPDATE administrator_bootstrap_audits SET singleton = 2", [], "23514"],
    ["repeat bootstrap audit", "INSERT INTO administrator_bootstrap_audits (administrator_user_id, provider_issuer, provider_subject, created_by_operator) VALUES ($1, $2, $3, $4)", [id(105), issuer, "synthetic-subject-5", operator], "23505"],
    ["Administrator delete restriction", "DELETE FROM users WHERE id = $1", [id(105)], "23503"],
  ];
  await client.query("BEGIN");
  try {
    for (const [name, sql, params, code] of cases) {
      await client.query("SAVEPOINT constraint_probe");
      let actualCode: string | undefined;
      try { await client.query(sql, params); } catch (error) { actualCode = (error as { code?: string }).code; }
      await client.query("ROLLBACK TO SAVEPOINT constraint_probe");
      assert.equal(actualCode, code, `${name} must remain enforced`);
    }
  } finally {
    await client.query("ROLLBACK");
  }
}

async function main() {
  assert.equal(process.argv.length, 3, "Exactly one rehearsal phase required");
  const mode = process.argv[2];
  assert.ok(["seed", "seal", "preflight", "verify", "fault-membership", "fault-audit",
    "prepare-restore-transaction", "verify-restore-rollback"].includes(mode ?? ""), "Known rehearsal phase required");
  const { root, output } = await paths();
  const archive = path.join(output, "foundation.dump");
  const manifestPath = path.join(output, "manifest.json");
  const hash = async () => createHash("sha256").update(await readFile(archive)).digest("hex");
  if (mode === "seal") {
    const manifest: Manifest = JSON.parse(await readFile(manifestPath, "utf8"));
    manifest.archiveSha256 = await hash();
    await writeFile(manifestPath, JSON.stringify(manifest, null, 2) + "\n", { mode: 0o600 });
    return;
  }
  if (mode === "preflight" || mode === "verify" || mode === "verify-restore-rollback") {
    const manifest: Manifest = JSON.parse(await readFile(manifestPath, "utf8"));
    assert.equal(manifest.format, 1);
    assert.equal(manifest.syntheticOnly, true);
    recoveryEqual(await hash(), manifest.archiveSha256, "ARCHIVE_INTEGRITY_MISMATCH", "Archive integrity must match sealed manifest");
    if (mode === "preflight") {
      const client = await connect("restore", root);
      try {
        await emptyTarget(client);
      } finally { await client.end(); }
      return;
    }
  }
  const client = await connect(mode === "seed" || mode === "prepare-restore-transaction" ? "source" : "restore", root);
  try {
    if (mode === "prepare-restore-transaction") {
      await prepareRestoreTransaction(client);
      return;
    }
    if (mode === "verify-restore-rollback") {
      const log = await readFile(path.join(output, "restore-command.log"), "utf8");
      assert.match(log, /ERROR: {2}could not create unique index "recovery_restore_transaction_unique"/,
        "Restore must fail for the controlled post-data unique index, not an unrelated error");
      assert.match(log, /Key \((?:public\.)?recovery_restore_key\(id\)\)=\(00000000-0000-4000-8000-000000000000\) is duplicated/,
        "Expected synthetic duplicate key must cause the restore error");
      const indexPosition = log.indexOf('creating INDEX "public.recovery_restore_transaction_unique"');
      assert.ok(indexPosition >= 0, "Restore must reach the controlled post-data index");
      for (const table of tables) {
        const dataPosition = log.indexOf(`processing data for table "public.${table}"`);
        assert.ok(dataPosition >= 0 && dataPosition < indexPosition, `${table} data must be restored before the controlled error`);
      }
      const schemas = await emptyTarget(client);
      const manifest: Manifest = JSON.parse(await readFile(manifestPath, "utf8"));
      await writeFile(path.join(output, "rollback-verification.json"), JSON.stringify({
        syntheticOnly: true, sourceStoppedBeforeRestore: true,
        archiveSha256: manifest.archiveSha256, archiveIntegrityVerified: true,
        restoreExitCode: 1, expectedError: "recovery_restore_transaction_unique",
        dataLoadedBeforeError: [...tables], schemaAndDataEmpty: true, schemas,
      }, null, 2) + "\n", { mode: 0o600 });
      process.stdout.write("verify-restore-rollback: controlled post-data error and complete transaction rollback passed.\n");
      return;
    }
    if (mode === "fault-membership") {
      await client.query("UPDATE practice_memberships SET active = true WHERE user_id = $1", [id(106)]);
      return;
    }
    if (mode === "fault-audit") {
      await client.query("UPDATE administrator_bootstrap_audits SET provider_subject = 'synthetic-broken-link'");
      return;
    }
    if (mode === "seed") await seed(client);
    await verifyBoundaries(client);
    await verifyConstraints(client);
    const records = await snapshot(client);
    if (mode === "seed") {
      const version = await client.query("SHOW server_version");
      const manifest: Manifest = { format: 1, syntheticOnly: true, snapshot: records, archiveSha256: "", postgresVersion: version.rows[0].server_version };
      await writeFile(manifestPath, JSON.stringify(manifest, null, 2) + "\n", { mode: 0o600 });
    } else {
      const manifest: Manifest = JSON.parse(await readFile(manifestPath, "utf8"));
      const version = await client.query("SHOW server_version");
      assert.equal(version.rows[0].server_version, manifest.postgresVersion, "Same-version restore required for this rehearsal");
      assert.deepEqual(records, manifest.snapshot, "Every restored value and relationship must match source");
      const evidence = {
        verifiedAt: new Date().toISOString(), syntheticOnly: true, sourceStoppedBeforeRestore: true,
        archiveSha256: manifest.archiveSha256, postgresVersion: manifest.postgresVersion,
        rowCounts: Object.fromEntries(tables.map((table) => [table, records[table]!.length])),
        checks: ["full-row equality including timestamps", "business assignments, exact decimals, versions and retained deletions", "business audits and import receipts", "expired session metadata", "practice organization relationships", "five assigned roles",
          "same-organization and cross-organization denial", "global Administrator separation",
          "inactive membership and disabled user denial", "unknown identity and wrong issuer denial",
          "grant/audit/identity binding", "13 database constraint probes (rolled back)"],
      };
      await writeFile(path.join(output, "verification.json"), JSON.stringify(evidence, null, 2) + "\n", { mode: 0o600 });
    }
    process.stdout.write(`${mode}: foundation and shared business relationships, access boundaries and constraints passed.\n`);
  } finally {
    await client.end();
  }
}

main().catch(async (error: unknown) => {
  if (error instanceof RecoveryFailure) {
    // Recheck ownership before writing structured evidence. Generic errors never
    // receive an expected-fault code and therefore cannot pass the CI gate.
    const { output } = await paths();
    await writeFile(path.join(output, "failure.json"), JSON.stringify({
      syntheticOnly: true, phase: process.argv[2], code: error.code,
    }) + "\n", { mode: 0o600 });
  }
  // Assertion messages are synthetic-only; never dump PG config or raw errors.
  process.stderr.write(error instanceof assert.AssertionError || error instanceof RecoveryFailure ? `${error.message}\n` : "Recovery phase failed; check private rehearsal logs and prerequisites.\n");
  process.exitCode = 1;
});

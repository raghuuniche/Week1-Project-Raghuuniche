import assert from "node:assert/strict";
import type { Browser, Page } from "playwright";
import { absent, disposable, role, start, state, visibleIds, type RecordRow } from "./poc-browser-harness";

// Independent expectations: do not reuse application filtering or metric helpers.
const stages = ["Qualification", "Discovery", "Proposal", "Negotiation", "Won", "Lost"];
const statuses = ["On track", "At risk", "Off track", "Complete"];
const money = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);
const value = (rows: RecordRow[]) => rows.reduce((n, r) => n + r.value!, 0);
const weighted = (rows: RecordRow[]) => Math.round(rows.reduce((n, r) => n + r.value! * r.probability! / 100, 0));

export async function reportMatches(page: Page, opps: RecordRow[], projects: RecordRow[]) {
  await page.getByTestId("report-total-count-value").waitFor();
  const open = opps.filter((o) => o.stage !== "Won" && o.stage !== "Lost");
  assert.equal(await page.getByTestId("report-total-count-value").innerText(), String(opps.length));
  assert.equal(await page.getByTestId("report-open-value-value").innerText(), money(value(open)));
  assert.equal(await page.getByTestId("report-weighted-value").innerText(), money(weighted(open)));
  assert.equal(await page.getByTestId("report-won-value").innerText(), ["Won", "Lost"].map((stage) => money(value(opps.filter((o) => o.stage === stage)))).join(" / "));
  if (opps.length) {
    await absent(page, "empty-report");
    await visibleIds(page, "row-report-stage-", stages.map((s) => s.toLowerCase()));
    for (const stage of stages) {
      const rows = opps.filter((o) => o.stage === stage);
      const cells = page.getByTestId(`row-report-stage-${stage.toLowerCase()}`).locator("td");
      assert.deepEqual(await cells.allInnerTexts(), [stage, String(rows.length), money(value(rows)), money(weighted(rows))]);
    }
    assert.deepEqual(await page.getByTestId("row-report-total").locator("td").allInnerTexts(), [
      "Total", String(opps.length), money(value(opps)), money(weighted(opps)),
    ]);
  } else {
    await page.getByTestId("empty-report").waitFor();
    await absent(page, "table-report-stage", "row-report-total");
    await visibleIds(page, "row-report-stage-", []);
  }
  // Stage filters must not accidentally filter delivery; practice filters must.
  await visibleIds(page, "row-report-status-", statuses.map((s) => s.toLowerCase().replace(" ", "-")));
  for (const status of statuses) {
    const rows = projects.filter((p) => p.status === status);
    assert.deepEqual(await page.getByTestId(`row-report-status-${status.toLowerCase().replace(" ", "-")}`).locator("td").allInnerTexts(), [
      status, String(rows.length), money(rows.reduce((n, p) => n + p.budget!, 0)),
    ]);
  }
}

async function pipelineMatches(page: Page, rows: RecordRow[]) {
  await visibleIds(page, "row-opportunity-", rows.map((r) => r.id));
  assert.equal(await page.getByTestId("text-pipeline-count").innerText(), `${rows.length} opportunities, ${money(value(rows))} total value`);
  if (rows.length) await absent(page, "empty-pipeline");
  else {
    await page.getByTestId("empty-pipeline").waitFor();
    await absent(page, "table-pipeline");
    assert.match(await page.getByTestId("empty-pipeline").innerText(), /No opportunities match/);
  }
}

export async function filterChecks(browser: Browser) {
  for (const name of ["executive", "practice_director", "manager"]) {
    await disposable(browser, async (page) => {
      await start(page);
      await role(page, name);
      const seed = await state(page);
      // Exercise the executive's local practice filters and the director's scope
      // selector separately. Managers must stay in their assigned practice.
      for (const practice of name === "manager" ? ["p1"] : ["all", "p2", "p1"]) {
        if (name === "practice_director" && practice === "all") continue;
        if (name === "practice_director") await page.getByTestId("select-practice").selectOption(practice);
        const opps = seed.opps.filter((o) => practice === "all" || o.practiceId === practice);
        const projects = seed.projects.filter((p) => practice === "all" || p.practiceId === practice);
        await page.goto("/poc/pipeline");
        if (name === "executive") await page.getByTestId("select-filter-practice").selectOption(practice);
        else await absent(page, "select-filter-practice");
        for (const stage of ["all", ...stages, "all"]) {
          await page.getByTestId("select-filter-stage").selectOption(stage);
          const staged = opps.filter((o) => stage === "all" || o.stage === stage);
          await pipelineMatches(page, staged);
          // Case-insensitive, trimmed matching of every searchable field,
          // plus an impossible query under each stage/practice combination.
          const sample = staged[0] as (RecordRow & { client: string; owner: string }) | undefined;
          for (const query of [...(sample ? [sample.name!, sample.client, sample.owner].map((q) => `  ${q.toUpperCase()}  `) : []), "synthetic-no-matching-opportunity"]) {
            await page.getByTestId("input-search-pipeline").fill(query);
            const term = query.trim().toLowerCase();
            const expected = staged.filter((o) => {
              const r = o as RecordRow & { client: string; owner: string };
              return `${r.name} ${r.client} ${r.owner}`.toLowerCase().includes(term);
            });
            await pipelineMatches(page, expected);
          }
          await page.getByTestId("input-search-pipeline").fill("");
          await pipelineMatches(page, staged);
        }
        if (name !== "manager") {
          const next = practice === "p2" ? "p1" : "p2";
          const selector = name === "executive" ? "select-filter-practice" : "select-practice";
          await page.getByTestId(selector).selectOption(next);
          await pipelineMatches(page, seed.opps.filter((o) => o.practiceId === next));
          await page.getByTestId(selector).selectOption(practice);
          await pipelineMatches(page, opps);
        }
        await page.goto("/poc/reports");
        if (name === "executive") await page.getByTestId("select-report-practice").selectOption(practice);
        else await absent(page, "select-report-practice");
        for (const stage of ["all", ...stages, "all"]) {
          await page.getByTestId("select-report-stage").selectOption(stage);
          await reportMatches(page, opps.filter((o) => stage === "all" || o.stage === stage), projects);
        }
        if (name !== "manager") {
          const next = practice === "p2" ? "p1" : "p2";
          const selector = name === "executive" ? "select-report-practice" : "select-practice";
          await page.getByTestId(selector).selectOption(next);
          await reportMatches(page, seed.opps.filter((o) => o.practiceId === next), seed.projects.filter((p) => p.practiceId === next));
          await page.getByTestId(selector).selectOption(practice);
          await reportMatches(page, opps, projects);
        }
        assert.deepEqual((await state(page)).opps, seed.opps, "Filters do not mutate opportunities");
        assert.deepEqual((await state(page)).projects, seed.projects, "Filters do not mutate projects");
        assert.deepEqual((await state(page)).goals, seed.goals, "Filters do not mutate goals");
      }
    });
    console.log(`PASS: ${name} pipeline search/stage/practice rows and totals; report stage/practice aggregates, empty results and filter clearing`);
  }
}

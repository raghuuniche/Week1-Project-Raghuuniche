// Read-only synthetic ledger rehearsal, NOT a parser, ingestion tool or approval system.
// No filesystem, database, network, environment or production-target inputs.
export type Stage = "Qualification" | "Discovery" | "Proposal" | "Negotiation" | "Won" | "Lost";
export type Row = {
  ref: string; practice: string; owner: string; name: string; client: string;
  stage: Stage; value: string; currency: string; date: string; probability: number;
};
export type Mapping = {
  synthetic: true; revision: string;
  practices: Record<string, { organization: string; id: string; currency: string; timeZone: string; approved: boolean }>;
  staff: Record<string, { id: string; verified: boolean; active: boolean; practices: string[] }>;
};
const units = (value: string) => {
  if (!/^(?:0|[1-9]\d{0,13})(?:\.\d{1,2})?$/.test(value)) throw new Error("unreconciled_money");
  const [whole, fraction = ""] = value.split(".");
  return BigInt(whole) * 100n + BigInt(fraction.padEnd(2, "0"));
};
const text = (value: bigint) => `${value / 100n}.${String(value % 100n).padStart(2, "0")}`;
const key = (value: string) => value.normalize("NFKC").trim().replace(/\s+/g, " ").toLowerCase();
const validDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value) &&
  Number.isFinite(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
const stages: Stage[] = ["Qualification", "Discovery", "Proposal", "Negotiation", "Won", "Lost"];

export function reconcile(mapping: Mapping, rows: Row[], existing: Row[] = []) {
  if (mapping.synthetic !== true || !mapping.revision) throw new Error("synthetic_revision_required");
  if (!rows.length || rows.length > 1000) throw new Error("row_limit");
  if (new Set(rows.map((r) => r.ref)).size !== rows.length) throw new Error("source_reference_collision");
  const duplicateKey = (r: Row) => JSON.stringify([mapping.practices[r.practice]?.id, key(r.name), key(r.client)]);
  const signature = (r: Row) => JSON.stringify([
    mapping.staff[r.owner]?.id, r.stage, text(units(r.value)), r.date, r.probability, r.currency,
  ]);
  const seen = new Map(existing.map((r) => [duplicateKey(r), r]));
  const ledger = rows.map((row) => {
    units(row.value); // Malformed amounts cannot quietly disappear from the source bridge.
    const practice = mapping.practices[row.practice], staff = mapping.staff[row.owner];
    const errors: string[] = [];
    if (!practice?.approved) errors.push("unapproved_practice");
    if (!staff?.verified || !staff.active || !practice || !staff.practices.includes(practice.id)) errors.push("unverified_or_out_of_scope_owner");
    if (row.currency !== practice?.currency) errors.push("currency_mismatch");
    if (!validDate(row.date)) errors.push("invalid_date");
    if (!row.name.trim() || !row.client.trim() || !stages.includes(row.stage) ||
        !Number.isInteger(row.probability) || row.probability < 0 || row.probability > 100) errors.push("invalid_pipeline_fields");
    if (errors.length) return { row, disposition: "rejected" as const, errors, duplicateOf: null };
    const previous = seen.get(duplicateKey(row));
    if (previous) return {
      row, disposition: "duplicate" as const,
      errors: signature(row) === signature(previous) ? [] : ["conflicting_duplicate"],
      duplicateOf: previous.ref,
    };
    seen.set(duplicateKey(row), row);
    return { row, disposition: "accepted" as const, errors: [], duplicateOf: null };
  });
  // The source bridge remains separated by source practice/currency/stage, including
  // rejected rows. Never sum mixed currencies, or silently remap rejected source totals.
  const buckets: Record<string, { source: bigint; accepted: bigint; rejected: bigint; duplicate: bigint }> = {};
  for (const entry of ledger) {
    const scope = JSON.stringify([entry.row.practice, entry.row.currency, entry.row.stage]);
    const bucket = buckets[scope] ??= { source: 0n, accepted: 0n, rejected: 0n, duplicate: 0n };
    bucket.source += units(entry.row.value);
    bucket[entry.disposition] += units(entry.row.value);
  }
  const counts = {
    source: rows.length,
    accepted: ledger.filter((r) => r.disposition === "accepted").length,
    rejected: ledger.filter((r) => r.disposition === "rejected").length,
    duplicate: ledger.filter((r) => r.disposition === "duplicate").length,
  };
  const blocked = ledger.some((r) => r.errors.length > 0);
  return { revision: mapping.revision, ledger, buckets, counts, blocked,
    // Accepted is preview eligibility, NOT inserted. An error blocks the entire batch.
    committable: blocked ? 0 : counts.accepted };
}

export function scopedTotals(mapping: Mapping, rows: Row[], practiceId: string, from: string, to: string) {
  if (!validDate(from) || !validDate(to) || from > to) throw new Error("invalid_period");
  const practice = Object.values(mapping.practices).find((p) => p.id === practiceId && p.approved);
  if (!practice) throw new Error("unapproved_scope");
  const selected = rows.filter((r) => mapping.practices[r.practice]?.id === practiceId && r.date >= from && r.date <= to);
  if (selected.some((r) => r.currency !== practice.currency)) throw new Error("mixed_currency");
  const open = selected.filter((r) => r.stage !== "Won" && r.stage !== "Lost");
  const sum = (rs: Row[]) => text(rs.reduce((n, r) => n + units(r.value), 0n));
  return { currency: practice.currency, timeZone: practice.timeZone, count: selected.length,
    openCount: open.length, openValue: sum(open),
    weightedValue: text((open.reduce((n, r) => n + units(r.value) * BigInt(r.probability), 0n) + 50n) / 100n),
    wonValue: sum(selected.filter((r) => r.stage === "Won")),
    lostValue: sum(selected.filter((r) => r.stage === "Lost")) };
}

export type Review = {
  revision: string; role: "director" | "manager"; reviewer: string;
  practices: string[]; decision: "approve" | "correct"; discrepancies: number;
};
export function reviewAllowsRelease(result: ReturnType<typeof reconcile>, mapping: Mapping, review: Review) {
  const scopes = result.ledger.map((r) => mapping.practices[r.row.practice]?.id);
  return !result.blocked && result.committable > 0 && result.revision === mapping.revision &&
    review.revision === result.revision && ["director", "manager"].includes(review.role) &&
    Boolean(review.reviewer.trim()) && review.decision === "approve" && review.discrepancies === 0 &&
    scopes.every((id) => id !== undefined && review.practices.includes(id));
}

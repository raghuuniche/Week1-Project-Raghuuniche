import assert from "node:assert/strict";
import test from "node:test";
import { validateResult } from "./recovery-ci.js";

const normal = {
  exit: 0, signal: null, status: "PASS\n", cleanup: "PASS\n",
  verification: { syntheticOnly: true, sourceStoppedBeforeRestore: true },
};
const faults = [
  ["archive", "preflight", "ARCHIVE_INTEGRITY_MISMATCH"],
  ["membership", "verify", "INACTIVE_MEMBERSHIP_ALLOWED"],
  ["audit", "verify", "AUDIT_IDENTITY_BINDING_BROKEN"],
] as const;

test("normal requires successful restoration and cleanup", () => {
  validateResult("normal", normal);
  for (const change of [
    { exit: 1 }, { signal: "SIGTERM" }, { cleanup: "FAIL\n" },
    { status: "FAIL (exit 1)\n" }, { verification: undefined },
    { failure: { syntheticOnly: true } },
  ]) assert.throws(() => validateResult("normal", { ...normal, ...change }));
});

for (const [name, phase, code] of faults) {
  test(`${name} requires the exact fault code, phase, nonzero exit and cleanup`, () => {
    const fault = {
      exit: 1, signal: null, status: "FAIL (exit 1)\n", cleanup: "PASS\n",
      failure: { syntheticOnly: true, phase, code },
    };
    validateResult(name, fault);
    for (const change of [
      { exit: 0 }, { exit: 2 }, { exit: null }, { signal: "SIGTERM" },
      { cleanup: "FAIL\n" }, { status: "PASS\n" }, { failure: undefined },
      { failure: { ...fault.failure, code: "UNRELATED_ERROR" } },
      { failure: { ...fault.failure, phase: "seed" } },
      { failure: { ...fault.failure, syntheticOnly: false } },
      { verification: normal.verification },
    ]) assert.throws(() => validateResult(name, { ...fault, ...change }));
  });
}

test("restore-transaction requires sealed archive, controlled error, empty target and cleanup", () => {
  const rollback = {
    syntheticOnly: true, sourceStoppedBeforeRestore: true,
    archiveIntegrityVerified: true, restoreExitCode: 1,
    expectedError: "recovery_restore_transaction_unique", schemaAndDataEmpty: true,
  };
  const result = { ...normal, verification: undefined, rollback };
  validateResult("restore-transaction", result);
  for (const change of [
    { exit: 1 }, { exit: null }, { signal: "SIGTERM" }, { cleanup: "FAIL\n" },
    { status: "FAIL (exit 1)\n" }, { rollback: undefined },
    { failure: { syntheticOnly: true } }, { verification: normal.verification },
    ...Object.keys(rollback).map((key) => ({ rollback: { ...rollback, [key]: undefined } })),
    { rollback: { ...rollback, restoreExitCode: 0 } },
    { rollback: { ...rollback, expectedError: "UNRELATED_ERROR" } },
    { rollback: { ...rollback, schemaAndDataEmpty: false } },
  ]) assert.throws(() => validateResult("restore-transaction", { ...result, ...change }));
});

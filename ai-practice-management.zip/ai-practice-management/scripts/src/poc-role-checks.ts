import assert from "node:assert/strict";
import type { Browser } from "playwright";
import { absent, disposable, role, start, state, storageKey, visibleIds } from "./poc-browser-harness";
import { filterChecks } from "./poc-filter-checks";

// Independent expected contract: don't import canView/caps and repeat their mistakes.
const roles = {
  executive: ["dashboard", "pipeline", "delivery", "goals", "reports", "access"],
  practice_director: ["dashboard", "pipeline", "delivery", "goals", "reports", "access"],
  manager: ["dashboard", "pipeline", "delivery", "goals", "reports", "access"],
  team_member: ["dashboard", "delivery", "goals", "access"],
  administrator: ["access"],
};
const paths = { dashboard: "/poc", pipeline: "/poc/pipeline", delivery: "/poc/delivery", goals: "/poc/goals", reports: "/poc/reports", access: "/poc/access" };
const money = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

export async function roleChecks(browser: Browser) {
  for (const [name, allowed] of Object.entries(roles)) {
    await disposable(browser, async (page) => {
      await start(page);
      await role(page, name);
      const seed = await state(page);
      for (const [area, path] of Object.entries(paths)) {
        assert.equal(await page.getByTestId(`link-nav-poc-${area}`).count(), allowed.includes(area) ? 1 : 0, `${name} navigation ${area}`);
        await page.goto(path); // Deliberately bypass navigation for every route.
        if (!allowed.includes(area)) {
          await page.getByTestId("panel-poc-denied").waitFor();
          await absent(page, "table-pipeline", "table-delivery", "table-goals", "table-report-stage", "button-new-opportunity", "button-new-project", "button-new-goal", "stat-open-pipeline", "stat-projects", "stat-goal-progress");
          continue;
        }
        await page.getByTestId("poc-notice").waitFor();
        await absent(page, "panel-poc-denied");
        const inScope = <T extends { practiceId: string }>(rows: T[]) => rows.filter((r) => name === "executive" || r.practiceId === "p1");
        if (area === "dashboard") {
          const projects = inScope(seed.projects).filter((p) => name !== "team_member" || p.assigneeId === "s4");
          const goals = inScope(seed.goals).filter((g) => name !== "team_member" || g.ownerId === "s4");
          assert.equal(await page.getByTestId("stat-projects-value").innerText(), String(projects.length));
          await visibleIds(page, "dash-goal-", goals.slice(0, 5).map((g) => g.id));
          if (name === "team_member") await absent(page, "stat-open-pipeline", "stat-weighted", "stat-won", "panel-practice-compare");
          else {
            const opps = inScope(seed.opps);
            const open = opps.filter((o) => o.stage !== "Won" && o.stage !== "Lost");
            assert.equal(await page.getByTestId("stat-open-pipeline-value").innerText(), money(open.reduce((n, o) => n + o.value!, 0)));
            assert.equal(await page.getByTestId("stat-weighted-value").innerText(), money(Math.round(open.reduce((n, o) => n + o.value! * o.probability! / 100, 0))));
            assert.equal(await page.getByTestId("stat-won-value").innerText(), money(opps.filter((o) => o.stage === "Won").reduce((n, o) => n + o.value!, 0)));
            assert.equal(await page.getByTestId("panel-practice-compare").count(), name === "executive" ? 1 : 0);
          }
        }
        if (area === "pipeline") {
          await visibleIds(page, "row-opportunity-", inScope(seed.opps).map((r) => r.id));
          if (name === "executive") await absent(page, "button-new-opportunity", "button-import-pipeline", "button-edit-opportunity-o1", "button-delete-opportunity-o1");
          else await page.getByTestId("button-import-pipeline").waitFor();
        }
        if (area === "delivery") {
          await visibleIds(page, "row-project-", inScope(seed.projects).filter((r) => name !== "team_member" || r.assigneeId === "s4").map((r) => r.id));
          if (name === "executive" || name === "team_member") await absent(page, "button-new-project", "button-edit-project-j1", "button-delete-project-j1");
          if (name === "team_member") {
            assert.equal(await page.getByTestId("table-delivery").getByRole("columnheader", { name: "Budget", exact: true }).count(), 0);
            await page.getByTestId("select-status-j1").selectOption("Complete");
            await page.waitForFunction((key) => JSON.parse(sessionStorage.getItem(key)!).projects.find((r: { id: string }) => r.id === "j1").status === "Complete", storageKey);
            const after = await state(page);
            assert.deepEqual(after.projects.filter((r) => r.id !== "j1"), seed.projects.filter((r) => r.id !== "j1"), "Own status change cannot alter others");
          }
        }
        if (area === "goals") {
          await visibleIds(page, "row-goal-", inScope(seed.goals).filter((r) => name !== "team_member" || r.ownerId === "s4").map((r) => r.id));
          if (name !== "practice_director") await absent(page, "button-new-goal", "button-edit-goal-g1", "button-delete-goal-g1");
        }
        if (area === "reports") {
          assert.equal(await page.getByTestId("report-total-count-value").innerText(), String(inScope(seed.opps).length));
        }
      }
      if (name === "practice_director") {
        for (const [path, prefix, records] of [
          ["/poc/pipeline", "row-opportunity-", seed.opps],
          ["/poc/delivery", "row-project-", seed.projects],
          ["/poc/goals", "row-goal-", seed.goals],
        ] as const) {
          await page.goto(path);
          await page.getByTestId("select-practice").selectOption("p2");
          await visibleIds(page, prefix, records.filter((r) => r.practiceId === "p2").map((r) => r.id));
          await page.getByTestId("select-practice").selectOption("p1");
        }
        await page.goto("/poc/reports");
        await page.getByTestId("select-practice").selectOption("p2");
        await page.waitForFunction(() => document.querySelector('[data-testid="report-total-count-value"]')?.textContent === "5");
        await page.goto("/poc");
        assert.equal(await page.getByTestId("stat-projects-value").innerText(), "3");
        await visibleIds(page, "dash-goal-", seed.goals.filter((g) => g.practiceId === "p2").map((g) => g.id));
        await role(page, "manager");
        await page.goto("/poc/pipeline");
        await visibleIds(page, "row-opportunity-", seed.opps.filter((o) => o.practiceId === "p1").map((o) => o.id));
        await absent(page, "select-practice");
      }
      if (name === "manager" || name === "team_member") await absent(page, "select-practice");
    });
    console.log(`PASS: ${name} routes, navigation, scoping and write controls`);
  }
  await disposable(browser, async (page) => {
    await start(page);
    await page.goto("/poc/pipeline");
    await role(page, "team_member");
    await page.waitForURL("**/poc");
    await page.goto("/poc/delivery");
    await role(page, "administrator");
    await page.waitForURL("**/poc/access");
    await absent(page, "table-delivery", "table-pipeline");
  });
  await filterChecks(browser);
}

export async function gatingChecks(browser: Browser) {
  for (const options of [{}, { active: true, mode: "entra" }, { active: true, synthetic: false }, { active: true, production: true }]) {
    await disposable(browser, async (page) => {
      await page.goto("/");
      await page.evaluate((key) => sessionStorage.setItem(key, JSON.stringify({ role: "practice_director", practiceId: "p1", opps: [], projects: [], goals: [] })), storageKey);
      for (const path of Object.values(paths)) {
        await page.goto(path);
        if (!options.active && !options.production) await page.getByTestId("button-start-demo").waitFor();
        else await page.getByTestId("panel-poc-denied").waitFor();
        await absent(page, "select-preview-role", "nav-poc", "table-pipeline", "table-delivery", "table-goals", "report-total-count");
        await page.waitForFunction((key) => sessionStorage.getItem(key) === null, storageKey);
      }
    }, options);
  }
  console.log("PASS: signed-out, non-demo, non-synthetic and actual production-build gates");
}

import assert from "node:assert/strict";
import type { Browser, Page } from "playwright";
import { absent, disposable, fill, role, start, state, storageKey } from "./poc-browser-harness";
import { resetChecks } from "./poc-reset-checks";
import { reportMatches } from "./poc-filter-checks";

async function reports(page: Page) {
  const s = await state(page);
  await page.goto("/poc/reports");
  await reportMatches(page, s.opps.filter((o) => o.practiceId === s.practiceId), s.projects.filter((p) => p.practiceId === s.practiceId));
}

export async function mutationChecks(browser: Browser) {
  await disposable(browser, async (page, context) => {
    await start(page);
    await role(page, "practice_director");
    await page.getByTestId("select-practice").selectOption("p2");
    const original = await state(page);
    await reports(page);
    await page.goto("/poc/pipeline");
    await page.getByTestId("button-new-opportunity").click();
    await fill(page, {
      "input-opp-name": "Synthetic gate opportunity", "input-opp-client": "Synthetic gate client",
      "input-opp-owner": "Synthetic alias", "input-opp-value": "12000",
      "input-opp-close": "2026-12-15", "input-opp-probability": "50",
    });
    await page.getByTestId("select-opp-stage").selectOption("Discovery");
    await page.getByTestId("button-save-opportunity").click();
    await page.getByTestId("dialog-opportunity").waitFor({ state: "hidden" });
    const created = (await state(page)).opps.find((r) => r.name === "Synthetic gate opportunity")!;
    assert.ok(created);
    assert.equal(created.practiceId, "p2");
    await reports(page);
    await page.goto("/poc/pipeline");
    await page.getByTestId(`button-edit-opportunity-${created.id}`).click();
    await fill(page, { "input-opp-value": "24000", "input-opp-probability": "100" });
    await page.getByTestId("select-opp-stage").selectOption("Won");
    await page.getByTestId("button-save-opportunity").click();
    await page.getByTestId("dialog-opportunity").waitFor({ state: "hidden" });
    await reports(page);
    await page.reload();
    await page.getByTestId("report-total-count-value").waitFor();
    const reloaded = await state(page);
    assert.equal(reloaded.role, "practice_director");
    assert.equal(reloaded.practiceId, "p2");
    assert.equal(reloaded.opps.find((o) => o.id === created.id)?.value, 24000);
    await page.goto("/poc/pipeline");
    await page.getByTestId(`button-delete-opportunity-${created.id}`).click();
    await page.getByTestId("dialog-delete-opportunity-cancel").click();
    assert.ok((await state(page)).opps.some((o) => o.id === created.id));
    await page.getByTestId(`button-delete-opportunity-${created.id}`).click();
    await page.getByTestId("dialog-delete-opportunity-confirm").click();
    await page.getByTestId(`row-opportunity-${created.id}`).waitFor({ state: "hidden" });
    await reports(page);
    assert.deepEqual((await state(page)).opps, original.opps);

    await page.goto("/poc/delivery");
    await page.getByTestId("button-new-project").click();
    await fill(page, {
      "input-project-name": "Synthetic gate project", "input-project-client": "Synthetic client",
      "input-project-budget": "4500", "input-project-burn": "10", "input-project-end": "2026-12-15",
    });
    await page.getByTestId("select-project-lead").selectOption("s7");
    await page.getByTestId("button-save-project").click();
    await page.getByTestId("dialog-project").waitFor({ state: "hidden" });
    const project = (await state(page)).projects.find((r) => r.name === "Synthetic gate project")!;
    assert.equal(project.practiceId, "p2");
    await reports(page);
    await page.goto("/poc/delivery");
    await page.getByTestId(`button-edit-project-${project.id}`).click();
    await fill(page, { "input-project-budget": "9000" });
    await page.getByTestId("select-project-status").selectOption("Complete");
    await page.getByTestId("button-save-project").click();
    await page.getByTestId("dialog-project").waitFor({ state: "hidden" });
    await reports(page);
    await page.goto("/poc/delivery");
    await page.getByTestId(`button-delete-project-${project.id}`).click();
    await page.getByTestId("dialog-delete-project-confirm").click();
    await page.getByTestId(`row-project-${project.id}`).waitFor({ state: "hidden" });
    await reports(page);
    assert.deepEqual((await state(page)).projects, original.projects);

    await page.goto("/poc/goals");
    await page.getByTestId("button-new-goal").click();
    await fill(page, { "input-goal-title": "Synthetic gate goal", "input-goal-current": "1", "input-goal-target": "4", "input-goal-unit": "checks", "input-goal-due": "2026-12-15" });
    await page.getByTestId("select-goal-owner").selectOption("s7");
    await page.getByTestId("button-save-goal").click();
    await page.getByTestId("dialog-goal").waitFor({ state: "hidden" });
    const goal = (await state(page)).goals.find((g) => g.title === "Synthetic gate goal")!;
    assert.equal(goal.practiceId, "p2");
    assert.match(await page.getByTestId(`text-goal-progress-${goal.id}`).innerText(), /25%/);
    await page.getByTestId(`button-edit-goal-${goal.id}`).click();
    await fill(page, { "input-goal-current": "3" });
    await page.getByTestId("button-save-goal").click();
    await page.getByTestId("dialog-goal").waitFor({ state: "hidden" });
    assert.match(await page.getByTestId(`text-goal-progress-${goal.id}`).innerText(), /75%/);
    await page.getByTestId(`button-delete-goal-${goal.id}`).click();
    await page.getByTestId("dialog-delete-goal-confirm").click();
    await page.getByTestId(`row-goal-${goal.id}`).waitFor({ state: "hidden" });
    assert.deepEqual((await state(page)).goals, original.goals);

    // Manager writes always use the assigned practice, even after director chose p2.
    await role(page, "manager");
    await page.goto("/poc/pipeline");
    await page.getByTestId("button-new-opportunity").click();
    await fill(page, { "input-opp-name": "Synthetic manager opportunity", "input-opp-client": "Synthetic client", "input-opp-owner": "Synthetic manager", "input-opp-value": "777", "input-opp-close": "2026-12-15" });
    await page.getByTestId("button-save-opportunity").click();
    await page.getByTestId("dialog-opportunity").waitFor({ state: "hidden" });
    assert.equal((await state(page)).opps.find((o) => o.name === "Synthetic manager opportunity")?.practiceId, "p1");
    const persisted = await state(page);
    await page.reload();
    await page.getByTestId("table-pipeline").waitFor();
    assert.deepEqual(await state(page), persisted);
    const freshTab = await context.newPage();
    await freshTab.goto("/poc");
    await freshTab.getByTestId("select-preview-role").waitFor();
    assert.equal((await state(freshTab)).opps.some((o) => o.name === "Synthetic manager opportunity"), false);
    await freshTab.close();
    await page.getByTestId("button-logout").click();
    await page.getByTestId("button-start-demo").waitFor();
    await page.waitForFunction((key) => sessionStorage.getItem(key) === null, storageKey);
    await absent(page, "select-preview-role", "table-pipeline", "nav-poc");
    await page.reload();
    await page.getByTestId("button-start-demo").waitFor();
    assert.equal(await page.evaluate((key) => sessionStorage.getItem(key), storageKey), null);
    await page.getByTestId("button-start-demo").click();
    await page.getByTestId("select-preview-role").waitFor();
    assert.deepEqual((await state(page)).opps, original.opps, "Restart restores seeds, not old mutations");
  });
  console.log("PASS: opportunity/project/goal create-edit-delete, recalculated reports, assigned writes, reload, tab isolation and End demo cleanup");
  await resetChecks(browser);
}

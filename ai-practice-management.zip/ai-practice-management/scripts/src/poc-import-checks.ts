import assert from "node:assert/strict";
import writeXlsxFile, { type SheetData } from "write-excel-file/node";
import type { Browser, Page } from "playwright";
import { absent, disposable, role, start, state } from "./poc-browser-harness";

const header = "name,client,owner,stage,value,closeDate,probability";
const row = (name: string, client = "Synthetic import client") => `${name},${client},Synthetic alias,Discovery,5000,2026-12-15,40`;
const csv = (name: string, content: string) => ({ name, mimeType: "text/csv", buffer: Buffer.from(content) });
async function choose(page: Page, file: { name: string; mimeType: string; buffer: Buffer }) {
  await page.getByTestId("input-pipeline-file").setInputFiles(file);
  await page.getByTestId("import-review").waitFor();
}
async function open(page: Page) {
  await page.getByTestId("button-import-pipeline").click();
  await page.getByTestId("dialog-import").waitFor();
}
async function cancel(page: Page) {
  await page.getByTestId("button-cancel-import").click();
  await page.getByTestId("dialog-import").waitFor({ state: "hidden" });
}
async function commit(page: Page) {
  assert.equal(await page.getByTestId("button-commit-import").isDisabled(), true, "Synthetic acknowledgement required");
  await page.getByTestId("checkbox-import-synthetic").check();
  assert.equal(await page.getByTestId("button-commit-import").isEnabled(), true);
  await page.getByTestId("button-commit-import").click();
  await page.getByTestId("dialog-import").waitFor({ state: "hidden" });
}
export async function importChecks(browser: Browser) {
  await disposable(browser, async (page) => {
    await start(page);
    await role(page, "practice_director");
    await page.goto("/poc/pipeline");
    await page.getByTestId("select-practice").selectOption("p2");
    const original = await state(page);
    // Generate a real zipped OOXML workbook. A deliberately invalid second
    // sheet catches default-reader shape regressions and wrong sheet selection.
    const sheet: SheetData = [
      header.split(",").map((value) => ({ value, type: String })),
      [
        ...["Synthetic XLSX first sheet", "Synthetic import client", "Synthetic alias", "Discovery"].map((value) => ({ value, type: String })),
        { value: 5000, type: Number },
        { value: new Date("2026-12-15T00:00:00Z"), type: Date, format: "yyyy-mm-dd" },
        { value: 40, type: Number },
      ],
    ];
    const workbook = await writeXlsxFile([
      { data: sheet, sheet: "First" },
      { data: [[{ value: "IGNORE SECOND SHEET", type: String }]], sheet: "Wrong sheet" },
    ]);
    const buffer = await workbook.toBuffer();
    assert.equal(buffer.subarray(0, 2).toString(), "PK", "Real XLSX ZIP bytes");
    await open(page);
    await choose(page, { name: "synthetic.xlsx", mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", buffer });
    await absent(page, "list-import-errors");
    assert.match(await page.getByTestId("text-import-summary").innerText(), /1 valid row\(s\) read; 1 new/);
    assert.match(await page.getByTestId("table-import-preview").innerText(), /Synthetic XLSX first sheet/);
    await commit(page);
    const imported = (await state(page)).opps.find((o) => o.name === "Synthetic XLSX first sheet")!;
    assert.equal(imported.practiceId, "p2");
    assert.equal(imported.value, 5000);
    assert.equal((await state(page)).opps.length, original.opps.length + 1);

    // Existing and same-file duplicates, whitespace and case normalization.
    await open(page);
    await choose(page, csv("duplicates.csv", `${header}\n${row(" synthetic xlsx FIRST sheet ", " SYNTHETIC IMPORT CLIENT ")}\n${row("Synthetic unique CSV")}\n${row("SYNTHETIC UNIQUE CSV")}`));
    assert.equal(await page.getByTestId("text-import-skipped").innerText(), "2");
    assert.match(await page.getByTestId("text-import-summary").innerText(), /3 valid row\(s\) read; 1 new/);
    await commit(page);
    const snapshot = await state(page);
    assert.equal(snapshot.opps.length, original.opps.length + 2);
    await page.reload();
    await page.getByTestId("table-pipeline").waitFor();
    assert.deepEqual(await state(page), snapshot, "Imports survive reload");
    await page.goto("/poc/reports");
    assert.equal(await page.getByTestId("report-total-count-value").innerText(), "7");
    await page.goto("/poc/pipeline");
    for (const content of [
      `${header}\n${row("Valid must not commit")}\nBroken,Synthetic client,Alias,Discovery,nope,2026-02-30,101`,
      'name,client\n"unterminated',
      `${header},practiceId\n${row("Wrong scope")},p1`,
    ]) {
      await open(page);
      await choose(page, csv("invalid.csv", content));
      await page.getByTestId("list-import-errors").waitFor();
      await page.getByTestId("checkbox-import-synthetic").check();
      assert.equal(await page.getByTestId("button-commit-import").isDisabled(), true);
      assert.deepEqual(await state(page), snapshot, "Any error blocks the whole import, including valid rows");
      await cancel(page);
    }
    await open(page);
    await choose(page, csv("all-duplicates.csv", `${header}\n${row("Synthetic unique CSV")}`));
    await page.getByTestId("checkbox-import-synthetic").check();
    assert.equal(await page.getByTestId("button-commit-import").isDisabled(), true);
    await cancel(page);
    assert.deepEqual(await state(page), snapshot);

    // Control File.text promises, rather than racing arbitrary sleep durations.
    await page.evaluate(`
      window.__reads = {};
      const original = File.prototype.text;
      File.prototype.text = function() {
        if (this.name.startsWith("stale")) {
          return new Promise((resolve, reject) => { window.__reads[this.name] = { resolve, reject }; });
        }
        return original.call(this);
      };
    `);
    await open(page);
    await page.getByTestId("input-pipeline-file").setInputFiles(csv("stale-replace.csv", "ignored"));
    await page.getByTestId("status-import-parsing").waitFor();
    await choose(page, csv("current.csv", `${header}\n${row("Synthetic current review")}`));
    await page.evaluate(`window.__reads["stale-replace.csv"].resolve(${JSON.stringify(`${header}\n${row("STALE MUST NOT APPEAR")}`)})`);
    await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
    assert.match(await page.getByTestId("table-import-preview").innerText(), /Synthetic current review/);
    assert.doesNotMatch(await page.getByTestId("dialog-import").innerText(), /STALE MUST NOT APPEAR/);
    await cancel(page);
    for (const rejection of [false, true]) {
      await open(page);
      const filename = rejection ? "stale-close-error.csv" : "stale-close-success.csv";
      await page.getByTestId("input-pipeline-file").setInputFiles(csv(filename, "ignored"));
      await page.getByTestId("status-import-parsing").waitFor();
      await cancel(page);
      await open(page);
      await page.evaluate(`window.__reads[${JSON.stringify(filename)}].${rejection ? 'reject(new Error("synthetic delayed read failure"))' : `resolve(${JSON.stringify(`${header}\n${row("STALE CLOSED REVIEW")}`)})`}`);
      await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
      await absent(page, "import-review", "list-import-errors", "status-import-parsing");
      assert.equal(await page.getByTestId("checkbox-import-synthetic").isChecked(), false);
      assert.equal(await page.getByTestId("button-commit-import").isDisabled(), true);
      await cancel(page);
    }
    assert.deepEqual(await state(page), snapshot, "Stale and cancelled reads never commit");
    await role(page, "manager");
    await open(page);
    await choose(page, csv("manager.csv", `${header}\n${row("Synthetic assigned-practice import")}`));
    await commit(page);
    assert.equal((await state(page)).opps.find((o) => o.name === "Synthetic assigned-practice import")?.practiceId, "p1");
  });
  console.log("PASS: real XLSX first sheet, CSV atomic errors, duplicate skipping, acknowledgement, scoped imports and controlled stale async reads");
}

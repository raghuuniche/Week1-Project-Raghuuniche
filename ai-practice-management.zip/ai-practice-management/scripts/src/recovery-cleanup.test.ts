import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import {
  chmodSync, copyFileSync, existsSync, mkdirSync, mkdtempSync,
  readFileSync, rmSync, writeFileSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const pgTools = ["initdb", "pg_ctl", "createdb", "pg_dump", "pg_restore"];
type Call = { tool: string; args: string[] };

// Run the actual script, not an extracted/reimplemented cleanup function.
// PATH contains only spies; no database client or package runner can escape to
// the operator's tools. Filesystem spies are confined to this test's sandbox.
function harness(retainEvidence = false) {
  const evidenceRoot = path.join(repo, "generated-artifacts/recovery");
  if (retainEvidence) mkdirSync(evidenceRoot, { recursive: true, mode: 0o700 });
  const root = mkdtempSync(retainEvidence
    ? path.join(evidenceRoot, "backup-command-test-")
    : "/tmp/recovery-cleanup-test-");
  const bin = path.join(root, "bin");
  const temporary = path.join(root, "owned");
  const log = path.join(root, "calls.jsonl");
  mkdirSync(bin);
  mkdirSync(path.join(root, "scripts"));
  copyFileSync(path.join(repo, "scripts/rehearse-recovery.sh"),
    path.join(root, "scripts/rehearse-recovery.sh"));
  for (const tool of [...pgTools, "pnpm", "node", "truncate", "mkdir", "mktemp", "date", "rm", "dirname"]) {
    const stub = path.join(bin, tool);
    writeFileSync(stub, `#!${process.execPath}
const fs = require("node:fs");
const path = require("node:path");
const tool = ${JSON.stringify(tool)};
const args = process.argv.slice(2);
const root = process.env.HARNESS_ROOT;
const owned = path.join(root, "owned");
const safe = (p) => {
  const resolved = path.resolve(p);
  if (!resolved.startsWith(root + "/")) throw new Error("Outside sandbox: " + resolved);
  return resolved;
};
fs.appendFileSync(process.env.HARNESS_LOG, JSON.stringify({tool, args}) + "\\n", {mode:0o600});
if (${JSON.stringify(pgTools)}.includes(tool) && args[0] === "--version") {
  console.log(tool + " (PostgreSQL) 16.6");
} else if (tool === "dirname") {
  console.log(path.dirname(args[0]));
} else if (tool === "date") {
  console.log("20000101T000000Z");
} else if (tool === "mkdir") {
  for (const p of args.filter(a => !a.startsWith("-"))) fs.mkdirSync(safe(p), {recursive:true});
} else if (tool === "mktemp") {
  if (args[1] === "/tmp/recovery-XXXXXX") {
    fs.mkdirSync(owned, {mode:0o700});
    console.log(owned);
  } else {
    console.log(fs.mkdtempSync(safe(args[1].replace(/X+$/, ""))));
  }
} else if (tool === "rm") {
  for (const p of args.filter(a => !a.startsWith("-"))) fs.rmSync(safe(p), {recursive:true, force:true});
} else if (tool === "initdb") {
  fs.mkdirSync(safe(args[args.indexOf("-D") + 1]), {recursive:true});
} else if (tool === "pg_ctl") {
  const dir = safe(args[args.indexOf("-D") + 1]);
  const marker = path.join(dir, "postmaster.pid");
  const target = path.basename(path.dirname(dir));
  if (args.at(-1) === "start") {
    fs.writeFileSync(marker, "inert-postmaster-marker\\n");
  } else if (args.at(-1) === "stop") {
    if ((process.env.HARNESS_FAIL_STOP || "").split(",").includes(target)) {
      console.error("INERT_STOP_FAILURE " + target);
      process.exit(73);
    }
    if (process.env.HARNESS_KEEP_MARKER !== target) fs.rmSync(marker, {force:true});
  } else {
    throw new Error("Unexpected pg_ctl operation");
  }
} else if (tool === "pnpm" && args.includes("push-force")) {
  const mode = process.env.HARNESS_MODE;
  if (mode === "INT" || mode === "TERM") process.kill(process.ppid, "SIG" + mode);
  else if (mode === "EXIT") process.exit(42);
} else if (tool === "pnpm" && args.includes("recovery:fixtures") && args.at(-1) === "seal") {
  if (process.env.HARNESS_SEAL_EXIT) {
    console.error("INERT_ARCHIVE_SEAL_FAILURE");
    process.exit(Number(process.env.HARNESS_SEAL_EXIT));
  }
} else if (tool === "pg_dump") {
  const file = args.find(a => a.startsWith("--file="));
  if (!file) throw new Error("Expected explicit archive output");
  fs.writeFileSync(safe(file.slice("--file=".length)),
    process.env.HARNESS_DUMP_EXIT ? "INERT_PARTIAL_ARCHIVE\\n" : "INERT_COMPLETE_ARCHIVE\\n", {mode:0o600});
  if (process.env.HARNESS_DUMP_EXIT) {
    console.error("INERT_BACKUP_COMMAND_FAILURE");
    process.exit(Number(process.env.HARNESS_DUMP_EXIT));
  }
} else if (tool === "pg_restore" && process.env.HARNESS_RESTORE_EXIT) {
  if (fs.existsSync(path.join(owned, "source/pg/postmaster.pid")) ||
      !fs.existsSync(path.join(owned, "restore/pg/postmaster.pid"))) {
    throw new Error("Restore failure requires stopped source and running restore markers");
  }
  console.error("INERT_UNEXPECTED_RESTORE_FAILURE");
  process.exit(Number(process.env.HARNESS_RESTORE_EXIT));
} else if (!["pnpm", "createdb", "pg_dump", "pg_restore", "truncate"].includes(tool)) {
  throw new Error("Unexpected command: " + tool);
}
`);
    chmodSync(stub, 0o700);
  }
  return {
    root, temporary, log,
    run(extra: NodeJS.ProcessEnv = {}) {
      // Never spread process.env: inherited credentials and Node preload hooks
      // do not belong in an isolated cleanup rehearsal.
      const result = spawnSync("/bin/bash", [path.join(root, "scripts/rehearse-recovery.sh")], {
        cwd: root,
        env: {
          PATH: bin, NODE_ENV: "test", HARNESS_ROOT: root, HARNESS_LOG: log,
          ...extra,
        },
        encoding: "utf8", timeout: 15_000, maxBuffer: 1_000_000,
      });
      if (retainEvidence) {
        writeFileSync(path.join(root, "stdout.log"), result.stdout ?? "", { mode: 0o600 });
        writeFileSync(path.join(root, "stderr.log"), result.stderr ?? "", { mode: 0o600 });
      }
      assert.equal(result.error, undefined, "Rehearsal must finish without timeout");
      assert.equal(result.signal, null, "Signals must be handled by the script's traps");
      const match = result.stdout.match(/^RECOVERY_EVIDENCE=(.+)$/m);
      assert.ok(match, "Script must report its evidence directory");
      const output = match[1];
      assert.ok(output.startsWith(root + "/"), "Evidence must remain in the sandbox");
      const calls: Call[] = readFileSync(log, "utf8").trim().split("\n").map(line => JSON.parse(line));
      return { ...result, output, calls };
    },
    dispose() {
      if (retainEvidence) {
        // Retain partial archive, status and call evidence, but not command spies.
        rmSync(bin, { recursive: true, force: true });
        rmSync(path.join(root, "scripts"), { recursive: true, force: true });
      } else {
        rmSync(root, { recursive: true, force: true });
      }
    },
  };
}

function stops(calls: Call[], temporary: string, mode: "immediate" | "fast") {
  return calls.filter(call => call.tool === "pg_ctl" &&
    call.args.includes(mode) && call.args.at(-1) === "stop").map(call => {
    const dir = call.args[call.args.indexOf("-D") + 1];
    const target = path.basename(path.dirname(dir));
    assert.equal(dir, path.join(temporary, target, "pg"));
    assert.deepEqual(call.args, ["-D", dir, "-m", mode, "-w", "stop"]);
    return target;
  });
}

for (const code of [1, 74]) {
  test(`partial pg_dump failure (exit ${code}) cannot become usable recovery evidence`, (t) => {
    const h = harness(true);
    t.after(() => h.dispose());
    console.log(`Synthetic backup-command evidence: ${h.root}`);
    const result = h.run({ HARNESS_DUMP_EXIT: String(code) });
    assert.equal(result.status, code, "Preserve synchronous backup failure, not a signal exit");
    assert.match(result.stderr, /INERT_BACKUP_COMMAND_FAILURE/);
    assert.match(result.stderr, /Recovery rehearsal failed/);
    assert.equal(path.dirname(result.output), path.join(h.root, "generated-artifacts/recovery"));
    assert.equal(readFileSync(path.join(result.output, "foundation.dump"), "utf8"),
      "INERT_PARTIAL_ARCHIVE\n", "Failure must occur after writing a nonempty partial archive");
    const commands = result.calls.filter(call => !call.args.includes("--version"));
    assert.deepEqual(commands.filter(call => call.tool === "pnpm").map(call => call.args), [
      ["--filter", "@workspace/db", "run", "push-force"],
      ["--filter", "@workspace/scripts", "run", "recovery:fixtures", "seed"],
    ], "Seed must finish, but sealing, preflight and verification must never run");
    assert.deepEqual(commands.filter(call => call.tool === "pg_dump").map(call => call.args), [[
      "-h", path.join(h.temporary, "source/socket"), "-p", "25433",
      "-U", "recovery_fixture", "-d", "recovery_fixture_test",
      "--format=custom", "--no-owner", "--no-privileges",
      `--file=${path.join(result.output, "foundation.dump")}`,
    ]], "Backup must target only the owned synthetic source");
    assert.ok(!commands.some(call => call.tool === "pg_restore"), "Restore must never run");
    assert.ok(!commands.some(call => call.tool === "truncate"), "This is not archive-corruption coverage");
    for (const file of ["verification.json", "rollback-verification.json", "timing.json", "restore-command.log"]) {
      assert.ok(!existsSync(path.join(result.output, file)), `Failed backup must not produce ${file}`);
    }
    assert.equal(readFileSync(path.join(result.output, "status"), "utf8"), `FAIL (exit ${code})\n`);
    assert.equal(readFileSync(path.join(result.output, "cleanup-status"), "utf8"), "PASS\n");
    assert.deepEqual(commands.filter(call => call.tool === "pg_ctl" && call.args.at(-1) === "start")
      .map(call => call.args[call.args.indexOf("-D") + 1]),
    ["source", "restore"].map(target => path.join(h.temporary, target, "pg")),
    "Both synthetic clusters must have started before backup fails");
    assert.deepEqual(stops(result.calls, h.temporary, "immediate"), ["source", "restore"]);
    assert.deepEqual(stops(result.calls, h.temporary, "fast"), [],
      "Failure must stop before the normal post-seal source shutdown");
    assert.deepEqual(commands.filter(call => call.tool === "rm").map(call => call.args),
      [["-rf", h.temporary]], "Delete only this run's owned directory after stopping both clusters");
    assert.ok(!existsSync(h.temporary), "Owned-cluster cleanup must remove the disposable data");
  });
}

test("archive sealing failure after successful pg_dump cannot authorize recovery", (t) => {
  const h = harness(true);
  t.after(() => h.dispose());
  console.log(`Synthetic archive-sealing evidence: ${h.root}`);
  const code = 75;
  const result = h.run({ HARNESS_SEAL_EXIT: String(code) });
  assert.equal(result.status, code, "Preserve synchronous sealing failure, not a signal exit");
  assert.match(result.stderr, /INERT_ARCHIVE_SEAL_FAILURE/);
  assert.doesNotMatch(result.stderr, /INERT_BACKUP_COMMAND_FAILURE/);
  assert.match(result.stderr, /Recovery rehearsal failed/);
  assert.doesNotMatch(result.stdout, /Recovery rehearsal passed/);
  assert.equal(path.dirname(result.output), path.join(h.root, "generated-artifacts/recovery"));
  assert.equal(readFileSync(path.join(result.output, "foundation.dump"), "utf8"),
    "INERT_COMPLETE_ARCHIVE\n", "Sealing must fail after the dump spy successfully creates an archive");
  const commands = result.calls.filter(call => !call.args.includes("--version"));
  assert.deepEqual(commands.filter(call => call.tool === "pnpm").map(call => call.args), [
    ["--filter", "@workspace/db", "run", "push-force"],
    ["--filter", "@workspace/scripts", "run", "recovery:fixtures", "seed"],
    ["--filter", "@workspace/scripts", "run", "recovery:fixtures", "seal"],
  ], "Sealing must run, but preflight and all verification must never run");
  assert.deepEqual(commands.filter(call => call.tool === "pg_dump").map(call => call.args), [[
    "-h", path.join(h.temporary, "source/socket"), "-p", "25433",
    "-U", "recovery_fixture", "-d", "recovery_fixture_test",
    "--format=custom", "--no-owner", "--no-privileges",
    `--file=${path.join(result.output, "foundation.dump")}`,
  ]], "Successful backup must target only the owned synthetic source");
  assert.ok(commands.findIndex(call => call.tool === "pg_dump") <
    commands.findIndex(call => call.tool === "pnpm" && call.args.at(-1) === "seal"),
  "Dump must finish before sealing is attempted");
  assert.ok(!commands.some(call => call.tool === "pg_restore"), "Restore must never run");
  assert.ok(!commands.some(call => call.tool === "truncate"), "This is not archive-corruption coverage");
  for (const file of ["verification.json", "rollback-verification.json", "timing.json", "restore-command.log"]) {
    assert.ok(!existsSync(path.join(result.output, file)), `Failed sealing must not produce ${file}`);
  }
  assert.equal(readFileSync(path.join(result.output, "status"), "utf8"), `FAIL (exit ${code})\n`);
  assert.equal(readFileSync(path.join(result.output, "cleanup-status"), "utf8"), "PASS\n");
  assert.deepEqual(commands.filter(call => call.tool === "pg_ctl" && call.args.at(-1) === "start")
    .map(call => call.args[call.args.indexOf("-D") + 1]),
  ["source", "restore"].map(target => path.join(h.temporary, target, "pg")),
  "Both synthetic clusters must have started before sealing fails");
  assert.deepEqual(stops(result.calls, h.temporary, "immediate"), ["source", "restore"]);
  assert.deepEqual(stops(result.calls, h.temporary, "fast"), [],
    "Failed sealing must stop before the normal source shutdown");
  assert.deepEqual(commands.filter(call => call.tool === "rm").map(call => call.args),
    [["-rf", h.temporary]], "Delete only the owned directory after stopping both clusters");
  assert.ok(!existsSync(h.temporary), "Cleanup must remove the stopped clusters' disposable data");
});

for (const code of [1, 76]) {
  test(`unexpected pg_restore failure (exit ${code}) cannot report recovery success`, (t) => {
    const h = harness(true);
    t.after(() => h.dispose());
    console.log(`Synthetic restore-command evidence: ${h.root}`);
    const result = h.run({ HARNESS_RESTORE_EXIT: String(code) });
    assert.equal(result.status, code, "Preserve synchronous restore failure, not a signal exit");
    assert.match(result.stderr, /Recovery rehearsal failed/);
    assert.doesNotMatch(result.stdout, /Recovery rehearsal passed|Controlled restore error/);
    assert.doesNotMatch(result.stderr, /INERT_BACKUP_COMMAND_FAILURE|INERT_ARCHIVE_SEAL_FAILURE/);
    assert.equal(path.dirname(result.output), path.join(h.root, "generated-artifacts/recovery"));
    assert.equal(readFileSync(path.join(result.output, "foundation.dump"), "utf8"),
      "INERT_COMPLETE_ARCHIVE\n", "Restore failure must follow a successful inert backup");
    assert.equal(readFileSync(path.join(result.output, "restore-command.log"), "utf8"),
      "INERT_UNEXPECTED_RESTORE_FAILURE\n", "Retain the unexpected restore diagnostic");
    const commands = result.calls.filter(call => !call.args.includes("--version"));
    assert.deepEqual(commands.filter(call => call.tool === "pnpm").map(call => call.args), [
      ["--filter", "@workspace/db", "run", "push-force"],
      ["--filter", "@workspace/scripts", "run", "recovery:fixtures", "seed"],
      ["--filter", "@workspace/scripts", "run", "recovery:fixtures", "seal"],
      ["--filter", "@workspace/scripts", "run", "recovery:fixtures", "preflight"],
    ], "Seed, seal and preflight must finish; neither normal nor rollback verification may run");
    assert.deepEqual(commands.filter(call => call.tool === "pg_dump").map(call => call.args), [[
      "-h", path.join(h.temporary, "source/socket"), "-p", "25433",
      "-U", "recovery_fixture", "-d", "recovery_fixture_test",
      "--format=custom", "--no-owner", "--no-privileges",
      `--file=${path.join(result.output, "foundation.dump")}`,
    ]], "Backup must target only the owned synthetic source");
    assert.deepEqual(commands.filter(call => call.tool === "pg_restore").map(call => call.args), [[
      "-h", path.join(h.temporary, "restore/socket"), "-p", "25433",
      "-U", "recovery_fixture", "-d", "recovery_fixture_test",
      "--verbose", "--exit-on-error", "--single-transaction", "--no-owner", "--no-privileges",
      path.join(result.output, "foundation.dump"),
    ]], "The normal restore command must run exactly once against the separate owned target");
    assert.deepEqual(commands.filter(call => call.tool === "pg_ctl" && call.args.at(-1) === "start")
      .map(call => call.args[call.args.indexOf("-D") + 1]),
    ["source", "restore"].map(target => path.join(h.temporary, target, "pg")),
    "Both inert clusters must start before restore is attempted");
    assert.deepEqual(commands.filter(call =>
      ["pg_dump", "pg_restore", "rm"].includes(call.tool) ||
      (call.tool === "pnpm" && call.args.includes("recovery:fixtures")) ||
      (call.tool === "pg_ctl" && call.args.at(-1) === "stop"))
      .map(call => call.tool === "pnpm" ? call.args.at(-1) :
        call.tool === "pg_ctl" ? `stop-${call.args[call.args.indexOf("-m") + 1]}` : call.tool),
    ["seed", "pg_dump", "seal", "stop-fast", "preflight", "pg_restore", "stop-immediate", "rm"],
    "Only after successful preparation and source shutdown may restore fail and cleanup run");
    assert.ok(!commands.some(call => call.tool === "truncate"),
      "Unexpected normal restore errors must not use the controlled archive-corruption path");
    for (const file of ["verification.json", "rollback-verification.json", "timing.json"]) {
      assert.ok(!existsSync(path.join(result.output, file)), `Failed restore must not produce ${file}`);
    }
    assert.equal(readFileSync(path.join(result.output, "status"), "utf8"), `FAIL (exit ${code})\n`);
    assert.equal(readFileSync(path.join(result.output, "cleanup-status"), "utf8"), "PASS\n");
    assert.deepEqual(stops(result.calls, h.temporary, "fast"), ["source"]);
    assert.deepEqual(stops(result.calls, h.temporary, "immediate"), ["restore"],
      "Cleanup must stop the remaining cluster without re-stopping the already-stopped source");
    assert.deepEqual(commands.filter(call => call.tool === "rm").map(call => call.args),
      [["-rf", h.temporary]], "Delete only the owned disposable directory after shutdown");
    assert.ok(!existsSync(h.temporary), "Successful shutdown must clean up both disposable clusters");
  });
}

for (const mode of ["EXIT", "INT", "TERM"]) {
  test(`${mode} attempts immediate shutdown of both owned clusters`, (t) => {
    const h = harness();
    t.after(() => h.dispose());
    const result = h.run({ HARNESS_MODE: mode });
    const code = mode === "EXIT" ? 42 : 130;
    assert.equal(result.status, code);
    assert.deepEqual(stops(result.calls, h.temporary, "immediate"), ["source", "restore"]);
    assert.deepEqual(stops(result.calls, h.temporary, "fast"), []);
    assert.equal(readFileSync(path.join(result.output, "status"), "utf8"), `FAIL (exit ${code})\n`);
    assert.equal(readFileSync(path.join(result.output, "cleanup-status"), "utf8"), "PASS\n");
    assert.ok(!existsSync(h.temporary), "Successfully stopped clusters may be deleted");
    assert.match(result.stderr, /Recovery rehearsal failed/);
    assert.ok(!result.calls.some(call => call.tool === "pg_dump" && !call.args.includes("--version")),
      "Interruption occurs before backup");
  });
}

for (const mode of ["EXIT", "INT", "TERM"]) {
  for (const failed of ["source", "restore", "source,restore"]) {
    test(`${mode} preserves owned directories when ${failed} shutdown fails`, (t) => {
      const h = harness();
      t.after(() => h.dispose());
      const result = h.run({ HARNESS_MODE: mode, HARNESS_FAIL_STOP: failed });
      assert.equal(result.status, 1);
      assert.deepEqual(stops(result.calls, h.temporary, "immediate"), ["source", "restore"],
        "A failed first stop must not prevent the second stop");
      assert.equal(readFileSync(path.join(result.output, "status"), "utf8"), "FAIL (exit 1)\n");
      assert.equal(readFileSync(path.join(result.output, "cleanup-status"), "utf8"), "FAIL\n");
      assert.equal(readFileSync(path.join(h.temporary, "owner-marker"), "utf8"), "synthetic-recovery-v1\n");
      assert.ok(!result.calls.some(call => call.tool === "rm" && call.args.includes(h.temporary)),
        "Never even attempt to remove a directory containing a running marker");
      for (const target of ["source", "restore"]) {
        assert.equal(existsSync(path.join(h.temporary, target, "pg/postmaster.pid")),
          failed.split(",").includes(target));
        if (failed.split(",").includes(target)) {
          assert.match(readFileSync(path.join(result.output, `${target}.log`), "utf8"), /INERT_STOP_FAILURE/);
          assert.ok(result.stderr.includes(`Could not stop owned ${target} cluster`));
        }
      }
    });
  }
}

test("successful EXIT stops the remaining cluster and records successful cleanup", (t) => {
  const h = harness();
  t.after(() => h.dispose());
  const result = h.run();
  assert.equal(result.status, 0);
  assert.deepEqual(result.calls.filter(call => call.tool === "pnpm" && call.args.includes("recovery:fixtures"))
    .map(call => call.args.at(-1)), ["seed", "seal", "preflight", "verify"],
    "Positive control must reach the phases forbidden after a failed backup");
  assert.equal(result.calls.filter(call => call.tool === "pg_restore" && !call.args.includes("--version")).length, 1);
  assert.deepEqual(stops(result.calls, h.temporary, "fast"), ["source"]);
  assert.deepEqual(stops(result.calls, h.temporary, "immediate"), ["restore"]);
  assert.equal(readFileSync(path.join(result.output, "status"), "utf8"), "PASS\n");
  assert.equal(readFileSync(path.join(result.output, "cleanup-status"), "utf8"), "PASS\n");
  assert.ok(!existsSync(h.temporary));
});

test("shutdown failure changes an otherwise successful EXIT into failed evidence", (t) => {
  const h = harness();
  t.after(() => h.dispose());
  const result = h.run({ HARNESS_FAIL_STOP: "restore" });
  assert.equal(result.status, 1);
  assert.deepEqual(stops(result.calls, h.temporary, "immediate"), ["restore"]);
  assert.equal(readFileSync(path.join(result.output, "status"), "utf8"), "FAIL (exit 1)\n");
  assert.equal(readFileSync(path.join(result.output, "cleanup-status"), "utf8"), "FAIL\n");
  assert.ok(existsSync(path.join(h.temporary, "restore/pg/postmaster.pid")));
  assert.ok(!result.calls.some(call => call.tool === "rm" && call.args.includes(h.temporary)));
});

test("a successful stop command cannot authorize deletion while a postmaster marker remains", (t) => {
  const h = harness();
  t.after(() => h.dispose());
  const result = h.run({ HARNESS_KEEP_MARKER: "restore" });
  assert.equal(result.status, 1);
  assert.equal(readFileSync(path.join(result.output, "status"), "utf8"), "FAIL (exit 1)\n");
  assert.equal(readFileSync(path.join(result.output, "cleanup-status"), "utf8"), "FAIL\n");
  assert.ok(existsSync(path.join(h.temporary, "restore/pg/postmaster.pid")));
  assert.ok(!result.calls.some(call => call.tool === "rm" && call.args.includes(h.temporary)));
});

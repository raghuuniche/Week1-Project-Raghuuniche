/// <reference lib="dom" />
/// <reference lib="dom.iterable" />
import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
import type { Browser, BrowserContext, Page } from "playwright";

export const storageKey = "northstar.poc.session.v1";
export const developmentURL = "http://127.0.0.1:25101";
export const productionURL = "http://127.0.0.1:25102";
export type RecordRow = { id: string; practiceId: string; name?: string; title?: string; assigneeId?: string; ownerId?: string; value?: number; probability?: number; stage?: string; status?: string; budget?: number };
export type State = { role: string; practiceId: string; opps: RecordRow[]; projects: RecordRow[]; goals: RecordRow[] };
export const state = (page: Page) => page.evaluate((key) => JSON.parse(sessionStorage.getItem(key)!) as State, storageKey);

type StorageFaults = {
  blockWrites: boolean;
  blockRemoval: boolean;
  failedWrites: number;
  failedRemovals: number;
};
declare global {
  interface Window { __pocStorageFaults: StorageFaults }
}

/** Installed before application code; scoped to this tab's demo key, including reloads. */
export async function storageFaults(context: BrowserContext, options: { blockWrites?: boolean; blockRemoval?: boolean } = {}) {
  await context.addInitScript(({ key, options }) => {
    const faults = window.__pocStorageFaults = {
      blockWrites: options.blockWrites ?? false,
      blockRemoval: options.blockRemoval ?? false,
      failedWrites: 0,
      failedRemovals: 0,
    };
    const setItem = Storage.prototype.setItem;
    const removeItem = Storage.prototype.removeItem;
    Storage.prototype.setItem = function (name, value) {
      if (this === sessionStorage && name === key && faults.blockWrites) {
        faults.failedWrites++;
        throw new DOMException("Synthetic demo write blocked", "QuotaExceededError");
      }
      return setItem.call(this, name, value);
    };
    Storage.prototype.removeItem = function (name) {
      if (this === sessionStorage && name === key && faults.blockRemoval) {
        faults.failedRemovals++;
        throw new DOMException("Synthetic demo removal blocked", "SecurityError");
      }
      return removeItem.call(this, name);
    };
  }, { key: storageKey, options });
}

/** Only these synthetic endpoints are allowed; every other API request fails the gate. */
export async function disposable(browser: Browser, run: (page: Page, context: BrowserContext) => Promise<void>, options: { production?: boolean; active?: boolean; mode?: string; synthetic?: boolean } = {}) {
  const baseURL = options.production ? productionURL : developmentURL;
  const context = await browser.newContext({ baseURL, viewport: { width: 1440, height: 1000 }, serviceWorkers: "block" });
  context.setDefaultTimeout(10_000);
  let active = options.active ?? false;
  const errors: string[] = [];
  const unexpected: string[] = [];
  const auth = () => ({
    mode: options.mode ?? "demo", demoAvailable: (options.mode ?? "demo") === "demo",
    configurationReason: null, sessionActive: active, csrfToken: "synthetic-test-token",
    displayName: active ? "Synthetic Tester" : null, role: active ? "practice_director" : null,
    practiceId: active ? "synthetic" : null, administrator: false, synthetic: active && (options.synthetic ?? true),
  });
  await context.route("**/*", async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    if (url.origin !== baseURL) { await route.abort(); return; }
    if (!url.pathname.startsWith("/api/")) { await route.continue(); return; }
    let body: unknown;
    let status = 200;
    const endpoint = `${request.method()} ${url.pathname}`;
    switch (endpoint) {
      case "GET /api/auth/status": body = auth(); break;
      case "POST /api/auth/demo":
        assert.equal(request.headers()["x-csrf-token"], "synthetic-test-token");
        active = true; body = auth(); break;
      case "POST /api/auth/logout":
        assert.equal(request.headers()["x-csrf-token"], "synthetic-test-token");
        active = false; status = 204; break;
      case "GET /api/foundation":
        status = active ? 200 : 401;
        body = active ? { practiceName: "Synthetic test practice", scope: "Synthetic demo only", identityVerified: false, realDataAccess: false, businessModulesEnabled: false, administratorAccess: false, entraImplemented: false } : { error: "Session required" };
        break;
      default:
        unexpected.push(endpoint); status = 500; body = { error: "Unexpected API call in frontend-only gate" };
    }
    await route.fulfill({ status, contentType: "application/json", body: status === 204 ? undefined : JSON.stringify(body) });
  });
  const page = await context.newPage();
  page.on("pageerror", (error) => errors.push(error.message));
  try {
    await run(page, context);
    assert.deepEqual(unexpected, [], "No business API requests or database writes are allowed");
    assert.deepEqual(errors, [], "No browser runtime errors");
  } catch (error) {
    const output = new URL("../../generated-artifacts/poc-gate/", import.meta.url).pathname;
    await mkdir(output, { recursive: true });
    await page.screenshot({ path: `${output}/failure.jpg`, fullPage: true }).catch(() => {});
    await writeFile(`${output}/failure.html`, await page.content()).catch(() => {});
    console.error(`PoC browser failure at ${page.url()}; synthetic diagnostics saved in ${output}`);
    throw error;
  } finally { await context.close(); }
}

export async function start(page: Page) {
  await page.goto("/poc");
  await page.getByTestId("button-start-demo").click();
  await page.getByTestId("select-preview-role").waitFor();
}
export async function role(page: Page, value: string) {
  await page.getByTestId("select-preview-role").selectOption(value);
  await page.waitForFunction(({ key, value }) => JSON.parse(sessionStorage.getItem(key)!).role === value, { key: storageKey, value });
}
export async function visibleIds(page: Page, prefix: string, expected: string[]) {
  const locator = page.locator(`[data-testid^="${prefix}"]`);
  await page.waitForFunction(({ prefix, expected }) => {
    const ids = [...document.querySelectorAll(`[data-testid^="${prefix}"]`)].map((el) => el.getAttribute("data-testid")!.slice(prefix.length)).sort();
    return JSON.stringify(ids) === JSON.stringify([...expected].sort());
  }, { prefix, expected });
  assert.deepEqual((await locator.evaluateAll((els) => els.map((el) => el.getAttribute("data-testid")!))).map((id) => id.slice(prefix.length)).sort(), [...expected].sort());
}
export async function absent(page: Page, ...ids: string[]) {
  for (const id of ids) assert.equal(await page.getByTestId(id).count(), 0, `${id} must not exist`);
}
export async function fill(page: Page, fields: Record<string, string>) {
  for (const [id, value] of Object.entries(fields)) await page.getByTestId(id).fill(value);
}

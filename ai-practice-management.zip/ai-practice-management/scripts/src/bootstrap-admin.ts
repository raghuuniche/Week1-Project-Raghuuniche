import pg from "pg";
import { bootstrapFirstAdministrator, validateBootstrapInput } from "@workspace/db/bootstrap";

async function main() {
  const input = {
    tenantId: process.env.BOOTSTRAP_ENTRA_TENANT_ID ?? "",
    objectId: process.env.BOOTSTRAP_ADMIN_OBJECT_ID ?? "",
    operator: process.env.BOOTSTRAP_OPERATOR ?? "",
    confirmed: process.argv.includes("--confirm-first-administrator"),
  };
  validateBootstrapInput(input);
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required.");
  const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
  try {
    await bootstrapFirstAdministrator(pool, input);
    process.stdout.write("Initial Administrator grant and audit recorded. No practice access was granted.\n");
  } finally {
    await pool.end();
  }
}
main().catch((error: unknown) => {
  // Never log the environment, DB connection string, or provider identity.
  const message = error instanceof Error && !("code" in error) ? error.message : "Bootstrap failed; check the schema and database connectivity.";
  process.stderr.write(`${message}\n`);
  process.exitCode = 1;
});

import assert from "node:assert/strict";
import test from "node:test";
import { reconcile, scopedTotals, reviewAllowsRelease, type Mapping, type Row, type Review } from "./onboarding-reconciliation";

// Invented aliases only. These fixtures confer no identities, memberships or approvals.
const mapping: Mapping = {
  synthetic: true, revision: "synthetic-v1",
  practices: {
    A: { organization: "synthetic-org", id: "synthetic-a", currency: "USD", timeZone: "America/New_York", approved: true },
    B: { organization: "synthetic-org", id: "synthetic-b", currency: "GBP", timeZone: "Europe/London", approved: true },
    C: { organization: "synthetic-org", id: "synthetic-c", currency: "GBP", timeZone: "Europe/London", approved: false },
  },
  staff: {
    S1: { id: "synthetic-staff-1", verified: true, active: true, practices: ["synthetic-a"] },
    S2: { id: "synthetic-staff-2", verified: true, active: true, practices: ["synthetic-b", "synthetic-c"] },
  },
};
const row = (ref: string, overrides: Partial<Row> = {}): Row => ({
  ref, practice: "A", owner: "S1", name: `Synthetic ${ref}`, client: "Synthetic client",
  stage: "Discovery", value: "100.01", currency: "USD", date: "2026-10-15", probability: 33, ...overrides,
});
const existing = [row("baseline", { name: "Synthetic existing", stage: "Proposal", value: "30.00", probability: 50 })];
const source = [
  row("r1"),
  row("r2", { stage: "Won", value: "200.00", probability: 100 }),
  row("r3", { stage: "Lost", value: "50.00", probability: 0 }),
  row("r4", { practice: "B", owner: "S2", currency: "GBP", value: "10.01", probability: 50 }),
  row("r5", { name: "  ＳＹＮＴＨＥＴＩＣ   R1  ", client: " SYNTHETIC CLIENT " }),
  { ...existing[0], ref: "r6" },
  row("r7", { owner: "unknown", value: "40.00", probability: 50 }),
  row("r8", { currency: "EUR", value: "60.00", probability: 50 }),
  row("r9", { date: "2026-02-30", value: "70.00", probability: 50 }),
  row("r10", { practice: "C", owner: "S2", currency: "GBP", value: "80.00", probability: 50 }),
];
const correctedMapping = { ...mapping, revision: "synthetic-v2" };
const corrected = source.map((r) => ({
  ...r,
  ...(r.ref === "r7" ? { owner: "S1" } : {}),
  ...(r.ref === "r8" ? { currency: "USD" } : {}),
  ...(r.ref === "r9" ? { date: "2026-10-15" } : {}),
  ...(r.ref === "r10" ? { practice: "B" } : {}),
}));
const review: Review = {
  revision: "synthetic-v2", role: "director", reviewer: "synthetic-reviewer",
  practices: ["synthetic-a", "synthetic-b"], decision: "approve", discrepancies: 0,
};
function conservation(result: ReturnType<typeof reconcile>) {
  const { source, accepted, rejected, duplicate } = result.counts;
  assert.equal(source, accepted + rejected + duplicate);
  for (const bucket of Object.values(result.buckets)) {
    assert.equal(bucket.source, bucket.accepted + bucket.rejected + bucket.duplicate);
  }
}
test("source ledger accounts for every row; any rejection blocks even eligible rows", () => {
  const result = reconcile(mapping, source, existing);
  assert.deepEqual(result.counts, { source: 10, accepted: 4, rejected: 4, duplicate: 2 });
  assert.equal(result.committable, 0);
  assert.equal(result.blocked, true);
  assert.equal(result.ledger[4].duplicateOf, "r1");
  assert.equal(result.ledger[5].duplicateOf, "baseline");
  assert.deepEqual(result.ledger.slice(6).map((r) => r.errors), [
    ["unverified_or_out_of_scope_owner"], ["currency_mismatch"], ["invalid_date"], ["unapproved_practice"],
  ]);
  assert.equal(result.buckets['["A","EUR","Discovery"]'].rejected, 6000n);
  conservation(result);
  assert.equal(reviewAllowsRelease(result, mapping, { ...review, revision: mapping.revision }), false);
});
test("corrections create a new revision, preserving old evidence and requiring new review", () => {
  const result = reconcile(correctedMapping, corrected, existing);
  assert.deepEqual(result.counts, { source: 10, accepted: 8, rejected: 0, duplicate: 2 });
  assert.equal(result.committable, 8);
  conservation(result);
  assert.equal(source[6].owner, "unknown");
  assert.equal(reviewAllowsRelease(result, correctedMapping, review), true);
  for (const change of [
    { revision: "synthetic-v1" }, { decision: "correct" as const },
    { reviewer: "" }, { discrepancies: 1 }, { practices: ["synthetic-a"] },
  ]) assert.equal(reviewAllowsRelease(result, correctedMapping, { ...review, ...change }), false);
  assert.equal(reviewAllowsRelease(result, correctedMapping, { ...review, role: "manager" }), true);
});
test("scoped stage totals match independently specified source amounts, not a mixed-currency grand total", () => {
  const result = reconcile(correctedMapping, corrected, existing);
  const accepted = result.ledger.filter((r) => r.disposition === "accepted").map((r) => r.row);
  assert.deepEqual(scopedTotals(correctedMapping, accepted, "synthetic-a", "2026-10-01", "2026-10-31"), {
    currency: "USD", timeZone: "America/New_York", count: 6, openCount: 4,
    openValue: "270.01", weightedValue: "118.00", wonValue: "200.00", lostValue: "50.00",
  });
  assert.deepEqual(scopedTotals(correctedMapping, accepted, "synthetic-b", "2026-10-01", "2026-10-31"), {
    currency: "GBP", timeZone: "Europe/London", count: 2, openCount: 2,
    openValue: "90.01", weightedValue: "45.01", wonValue: "0.00", lostValue: "0.00",
  });
  const a = scopedTotals(correctedMapping, [...existing, ...accepted], "synthetic-a", "2026-10-01", "2026-10-31");
  assert.equal(a.count, 7);
  assert.equal(a.openValue, "300.01");
  assert.equal(a.weightedValue, "133.00");
  assert.equal(result.buckets['["A","USD","Discovery"]'].source, 37002n);
  assert.equal(result.buckets['["A","USD","Discovery"]'].duplicate, 10001n);
  assert.deepEqual(result.buckets['["A","USD","Won"]'], { source: 20000n, accepted: 20000n, rejected: 0n, duplicate: 0n });
  assert.deepEqual(result.buckets['["A","USD","Lost"]'], { source: 5000n, accepted: 5000n, rejected: 0n, duplicate: 0n });
  assert.deepEqual(result.buckets['["A","USD","Proposal"]'], { source: 3000n, accepted: 0n, rejected: 0n, duplicate: 3000n });
  assert.deepEqual(result.buckets['["B","GBP","Discovery"]'], { source: 9001n, accepted: 9001n, rejected: 0n, duplicate: 0n });
  assert.deepEqual(accepted.reduce<Record<string, number>>((counts, r) => {
    const assignment = `${correctedMapping.practices[r.practice].id}/${correctedMapping.staff[r.owner].id}`;
    counts[assignment] = (counts[assignment] ?? 0) + 1;
    return counts;
  }, {}), { "synthetic-a/synthetic-staff-1": 6, "synthetic-b/synthetic-staff-2": 2 });
});
test("conflicting duplicates cannot be waved through; exact retry is entirely skipped", () => {
  const changed = corrected.map((r) => r.ref === "r5" ? { ...r, value: "999.00" } : r);
  const conflict = reconcile(correctedMapping, changed, existing);
  assert.deepEqual(conflict.ledger[4].errors, ["conflicting_duplicate"]);
  assert.equal(conflict.committable, 0);
  const first = reconcile(correctedMapping, corrected, existing);
  const accepted = first.ledger.filter((r) => r.disposition === "accepted").map((r) => r.row);
  const retry = reconcile(correctedMapping, corrected, [...existing, ...accepted]);
  assert.deepEqual(retry.counts, { source: 10, accepted: 0, rejected: 0, duplicate: 10 });
  assert.equal(reviewAllowsRelease(retry, correctedMapping, review), false);
  conservation(retry);
});
test("identity and monetary exceptions cannot be silently assigned or rounded away", () => {
  for (const owner of ["S2", "unknown"]) {
    assert.equal(reconcile(mapping, [row("scope", { owner })]).blocked, true);
  }
  for (const changes of [{ verified: false }, { active: false }]) {
    assert.equal(reconcile({ ...mapping, staff: { ...mapping.staff, S1: { ...mapping.staff.S1, ...changes } } }, [row("disabled")]).blocked, true);
  }
  for (const value of ["1.234", "-1", "$100", "NaN"]) {
    assert.throws(() => reconcile(mapping, [row("money", { value })]), /unreconciled_money/);
  }
  assert.throws(() => reconcile(mapping, [row("same"), row("same")]), /source_reference_collision/);
  assert.throws(() => reconcile(mapping, Array.from({ length: 1001 }, (_, i) => row(`limit-${i}`))), /row_limit/);
  assert.equal(reconcile(mapping, Array.from({ length: 1000 }, (_, i) => row(`limit-${i}`))).counts.accepted, 1000);
});

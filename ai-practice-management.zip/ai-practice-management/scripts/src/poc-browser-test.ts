import { existsSync } from "node:fs";
import { chromium } from "playwright";
import { gatingChecks, roleChecks } from "./poc-role-checks";
import { mutationChecks } from "./poc-mutation-checks";
import { importChecks } from "./poc-import-checks";
import { storageChecks } from "./poc-storage-checks";

const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH ?? (existsSync("/repl/tools/bin/chromium") ? "/repl/tools/bin/chromium" : undefined),
  args: ["--no-sandbox"],
});
try {
  const selected = process.argv[2];
  if (selected && !["roles", "mutations", "imports", "gating", "storage"].includes(selected)) throw new Error(`Unknown PoC check: ${selected}`);
  if (!selected || selected === "roles") await roleChecks(browser);
  if (!selected || selected === "mutations") await mutationChecks(browser);
  if (!selected || selected === "imports") await importChecks(browser);
  if (!selected || selected === "storage") await storageChecks(browser);
  if (!selected || selected === "gating") await gatingChecks(browser);
} finally { await browser.close(); }

import assert from "node:assert/strict";
import type { Browser } from "playwright";
import { disposable, role, start, state, storageKey, visibleIds, absent } from "./poc-browser-harness";
import { reportMatches } from "./poc-filter-checks";

export async function resetChecks(browser: Browser) {
  for (const name of ["executive", "practice_director", "manager", "team_member", "administrator"]) {
    await disposable(browser, async (page) => {
      await start(page);
      await role(page, name);
      const original = await state(page);
      // CRUD is covered elsewhere. Seed a deliberately changed disposable tab:
      // one edit, deletion and addition in every collection across both practices.
      await page.evaluate((key) => {
        const saved = JSON.parse(sessionStorage.getItem(key)!);
        saved.practiceId = "p2";
        for (const collection of ["opps", "projects", "goals"]) {
          const rows = saved[collection];
          const extra = { ...rows[0], id: `synthetic-reset-${collection}`, practiceId: "p2" };
          rows[0] = { ...rows[0], name: "Synthetic reset edit", title: "Synthetic reset edit", value: 12345, budget: 54321, current: 999 };
          rows.splice(1, 1);
          rows.push(extra);
        }
        sessionStorage.setItem(key, JSON.stringify(saved));
      }, storageKey);
      await page.reload();
      await page.getByTestId("button-reset-demo").waitFor();
      const changed = await state(page);
      for (const collection of ["opps", "projects", "goals"] as const) assert.notDeepEqual(changed[collection], original[collection]);
      await page.getByTestId("button-reset-demo").click();
      await page.getByTestId("dialog-reset").waitFor();
      assert.deepEqual(await state(page), changed, "Opening reset must not change data");
      await page.getByTestId("dialog-reset-cancel").click();
      await page.getByTestId("dialog-reset").waitFor({ state: "hidden" });
      assert.deepEqual(await state(page), changed, "Cancel preserves every record, practice and role");
      await page.reload();
      await page.getByTestId("button-reset-demo").waitFor();
      assert.deepEqual(await state(page), changed, "Cancelled reset stays cancelled after reload");
      await page.getByTestId("button-reset-demo").click();
      await page.getByTestId("dialog-reset-confirm").click();
      await page.getByTestId("dialog-reset").waitFor({ state: "hidden" });
      await page.waitForFunction(({ key, original }) => sessionStorage.getItem(key) === JSON.stringify(original), { key: storageKey, original });
      assert.deepEqual(await state(page), original, "Confirmed reset restores full seed records and default practice, preserving preview role");
      assert.equal(await page.getByTestId("select-preview-role").inputValue(), name);
      await page.reload();
      await page.getByTestId("button-reset-demo").waitFor();
      assert.deepEqual(await state(page), original, "Reset seeds and preview role survive reload");

      if (name === "administrator") {
        await absent(page, "table-pipeline", "table-delivery", "table-goals");
      } else {
        const scoped = <T extends { practiceId: string }>(rows: T[]) => rows.filter((r) => name === "executive" || r.practiceId === "p1");
        if (name !== "team_member") {
          await page.goto("/poc/pipeline");
          await visibleIds(page, "row-opportunity-", scoped(original.opps).map((r) => r.id));
          await page.goto("/poc/reports");
          await reportMatches(page, scoped(original.opps), scoped(original.projects));
        }
        await page.goto("/poc/delivery");
        await visibleIds(page, "row-project-", scoped(original.projects).filter((r) => name !== "team_member" || r.assigneeId === "s4").map((r) => r.id));
        await page.goto("/poc/goals");
        await visibleIds(page, "row-goal-", scoped(original.goals).filter((r) => name !== "team_member" || r.ownerId === "s4").map((r) => r.id));
      }
    });
    console.log(`PASS: ${name} reset open/cancel/confirm, full seed restoration, preview role, reload and scoped views`);
  }
}

# Northstar — AI Practice Management foundation

Internal AI Practice Management application for an IT consulting and services
company. This release implements **the application foundation only**: responsive
navigation, consistent UI components, server-owned pilot sessions, explicit access
boundaries, and a secure first-Administrator bootstrap command.

Goals, project delivery, pipeline, skills/certifications, library, meetings/actions,
AI partner/capability records, business dashboards and reports are **not built or
enabled** in the active application. The earlier browser-local business demo is
preserved in `.migration-backup/`, not served by this foundation.

## Stack and modules

- React + TypeScript + Vite: `artifacts/practice-management/`.
- Express modular monolith: `artifacts/api-server/`; no microservices.
- PostgreSQL + Drizzle: `lib/db/`.
- Contract-first OpenAPI and generated clients/validators: `lib/api-spec/`,
  `lib/api-client-react/`, `lib/api-zod/`.
- Operator commands and browser verification: `scripts/`.

The API separates authentication configuration/identity, session protection,
practice authorization, and foundation routes. Business modules can be added
later without changing the identity/access boundary.

## Setup and running

Use Node.js 24 and pnpm. Install the committed dependencies:

```sh
pnpm install --frozen-lockfile
pnpm --filter @workspace/api-spec run codegen
```

`DATABASE_URL` is supplied by the managed PostgreSQL environment. Set
`SESSION_SECRET` through the workspace's secure Secrets tooling, with at least
32 characters. Never commit it or copy its value into documentation.

The development schema is explicitly applied using:

```sh
pnpm --filter @workspace/db run push
```

Do not run DDL during application startup or in a production build hook. Managed
production schema changes go through the publishing flow; this task does not
publish or provision a production Administrator.

Start these existing managed workflows:

- `artifacts/api-server: API Server` — routes `/api`.
- `artifacts/practice-management: web` — routes `/`.

They supply the service `PORT` and frontend `BASE_PATH`. There is no root
`pnpm dev`. The mockup sandbox is not the product application.

## Pilot mode switch — authentication is deliberately deferred

Set the **non-secret** variable `AUTH_MODE=demo` in the **development environment
only** for demonstrations. Development is explicitly configured this way in the
workspace. It is never a shared or production setting.

| Setting | Result |
| --- | --- |
| Unset, or `AUTH_MODE=disabled` | Configuration-required screen; no demo entry or authenticated data access. |
| `AUTH_MODE=demo` with `NODE_ENV=development` | Explicit “Start demo” action creates a synthetic pilot session. |
| `AUTH_MODE=entra` | Entra-not-implemented state; no sign-in, no fallback to demo. |
| Demo in production/deployment, or invalid mode | Startup is rejected. |

To disable demonstration access, set `AUTH_MODE=disabled` in development and
restart the API workflow. Existing demo identities are invalidated. Use the
production start command rather than the development command in any future
deployment; demo sessions are never suitable for real company data.

Microsoft Entra ID is **not implemented or verified**. There is no fake SSO
button. Company SSO will be connected after the initial demonstration.

## Session protection and data isolation

Pilot entry is never automatic. It uses one fixed server-owned synthetic
Practice Director persona and only the `demo-practice` scope. No role picker,
browser identity header, local-storage role, or query parameter grants access.

Demo cookies are signed, HTTP-only, SameSite=Lax, scoped to `/api`, and expire
after one hour. Entry rotates the session ID and CSRF token. Session mutations
require both a matching request origin and a session-bound CSRF header; entry is
rate limited. Logout destroys the session, and the UI clears protected cached
data. The API returns no-store headers for authentication/foundation responses.

Demo sessions use a **development-only in-memory session store**, intentionally
not the real identity or practice database. Restarting the API ends them. Demo
requests never query or mutate real users, memberships, practices, Administrator
grants, or audits. They cannot use administrative routes.

The future real-identity adapter needs a persistent production session store and
verified Microsoft OIDC tokens. It must validate issuer, tenant, audience,
signature, expiry, state, nonce and PKCE before creating a provider identity.
Demo and real sessions must never share an authentication fallback.

## Authorization and relational foundation

Authentication identifies a user; authorization separately resolves an **active
database membership for the exact practice**. A signed-in user with no membership
has no practice access. A global Administrator grant also does **not** grant
practice access, and executive access must be assigned explicitly.

The schema supports multiple practices from the outset:

- Organizations and practices.
- Users and unique provider-issuer/subject identity links.
- Memberships keyed by user and practice, with active state and five roles:
  Vice President/Executive (`executive`), Practice Director
  (`practice_director`), Manager (`manager`), Team Member (`team_member`),
  Administrator (`administrator`).
- Separate global Administrator grants.
- A durable, singleton first-Administrator bootstrap audit.

There are no business tables, seed identities, or live practice memberships.
Membership management UI and business-action permissions remain later work.

## First Administrator bootstrap

Only a trusted operator with database/environment access can run this command.
There is **no public bootstrap endpoint, default password, reusable bootstrap
token, or first-signup-wins rule**.

Prerequisites:

1. Apply the development schema, or ensure the approved production schema is
   already present.
2. Independently verify the intended company's Entra tenant UUID and the intended
   Administrator's immutable Entra object UUID. Do not use an email address or
   a demo identity.
3. Supply `BOOTSTRAP_ENTRA_TENANT_ID`, `BOOTSTRAP_ADMIN_OBJECT_ID`, and
   `BOOTSTRAP_OPERATOR` as operator configuration in the target environment.
   Verify the database target before running; do not paste credentials into chat.

```sh
pnpm --filter @workspace/scripts run admin:bootstrap --confirm-first-administrator
```

The command takes a PostgreSQL advisory **transaction** lock, rejects a previous
grant or audit, and atomically creates the identity link, global grant and audit.
A database singleton constraint prevents repeat initialization even if the grant
is later revoked. Failures roll back all changes; concurrent attempts produce
only one grant. Disabled users cannot be promoted.

The identity is bound to the tenant-qualified issuer
`https://login.microsoftonline.com/<tenant UUID>/v2.0` and that tenant's immutable
object ID (`oid`). The future adapter must use this same validated identity,
not an email, unverified claim, or app-specific `sub`. Bootstrap grants **no
practice membership**.

Do not run bootstrap against real company identities until the operator has
verified them and the target environment is approved. A grant provisioned ahead
of SSO remains unusable for sign-in while Entra is deferred. This foundation does
not automatically create a real Administrator.

## Verification

### Database recovery readiness

Run the synthetic-only, isolated backup/restore rehearsal:

```sh
pnpm run rehearse:recovery
```

It creates two disposable private PostgreSQL clusters, backs up the foundation
fixtures, stops the source, restores into the empty second cluster and verifies
every row, relationship, access boundary and database constraint. It never uses
workspace/production credentials, real identities or an account-bootstrap
command. Startup and post-merge setup remain unchanged.

See the [verified operator runbook](docs/recovery-runbook.md) for prerequisites,
evidence, failure-injection commands, cleanup and limitations. This proves the
synthetic recovery mechanism, not a production backup policy or recovery SLA.

The [production backup policy](docs/production-recovery-policy.md) records
operator-approved daily backups, 7-day retention, a 24-hour record-loss target
and a 4-hour recovery target, not verified guarantees. **Practice Director or
Manager** is the accountable owner and primary operator role, with another
authorized Director/Manager providing alternate cover. The primary checks
backup freshness daily; contact provider support promptly if recovery is blocked
or the 4-hour target is at risk. Provider-only backups are approved, with no
independent copy; provider/account loss may prevent recovery.

Approved storage is the production provider's managed backup storage in a
provider-supported region subject to legal suitability, with provider-managed
encryption at rest, protected transport and provider-managed keys. Backup
administration/restores are restricted to authorized Directors/Managers. Seven-day
backup retention is not business-record retention; applicable legal retention,
deletion/hold and location obligations must be confirmed before launch.

Approval remains **policy only**. Actual operator assignments, production
database/backup locations, security/access and retention evidence, separately
authorized configuration and measured recovery remain outstanding, so real-data
launch remains blocked. No publishing, configuration changes, exports, restores,
deletion or costs are authorized by this policy discussion.

### Required pre-merge foundation gate

```sh
pnpm run check:foundation
```

This is the same command used by `.github/workflows/foundation.yml` on every
pull request and on pushes to `main`/`master`. It runs the full workspace
typecheck, applies the committed Drizzle schema to a **brand-new local test
cluster**, runs every API/database test, builds both services, then runs the
desktop (1440px) and mobile (390px) browser checks. No checks are optional.

Prerequisites: Node.js 24, pnpm 10.26.1, PostgreSQL 16 binaries (`initdb`,
`pg_ctl`, `createdb`) on PATH, curl, Linux `setsid`, and Chromium. CI installs
these explicitly. Outside Replit, install the browser with:

```sh
pnpm --filter @workspace/scripts exec playwright install --with-deps chromium
```

`CHROMIUM_PATH` may point to an installed executable; Replit's bundled Chromium
is detected automatically. Missing tools, browser, API, database, schema or web
server fail the command rather than skip tests.

The gate discards inherited database configuration and application session
secrets. It initializes PostgreSQL in a private temporary directory on loopback
port 25432, with a test-only role/database, and deletes the cluster on exit.
The API suite additionally keeps its disposable-schema bootstrap tests.
No workspace/production database, company identity, or Administrator is touched.
Test API/web/router processes use ports 25001/25002/25000 and stop on exit.
Ports must be free; the gate never reuses an existing database service.
The same-origin router is test-only, not a replacement for managed artifact
routing. No production schema push or startup DDL is added.

Browser checks exercise explicit entry, anonymous denial, protected API access,
cross-practice/admin denial, desktop/mobile navigation, reload persistence,
access-denied/not-found pages, and logout denial immediately and after reload.
Logs and screenshots live in ignored `generated-artifacts/foundation-gate/`;
GitHub uploads diagnostics for seven days even on failure.

To make this a merge blocker, configure the repository's protected branch/ruleset
to **require the `Foundation gate` status check**. A workflow alone reports
failure but cannot change repository branch protection. Require this check
without path filters so security changes always trigger it. The workflow needs
no production/workspace secrets and runs with read-only repository permission.

The gate was verified against a deliberately broken logout: temporarily replacing
`req.session.destroy` with `req.session.save` left the signed session alive.
The gate exited 1 at the old-cookie replay assertion (`401` expected, `200`
received). The correct code was restored; the complete gate then passed with
nine API/database tests, zero skips, and both desktop/mobile browser flows.
Missing dedicated test database configuration and an unavailable API were also
verified to exit nonzero. To repeat the mutation check locally, make only that
temporary logout change, run the gate expecting failure, restore it, and rerun
expecting success. Never commit the mutation.

### Individual checks

```sh
pnpm run typecheck
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/scripts run test:browser
```

For individual API/database tests, explicitly provide
`FOUNDATION_TEST_DATABASE_URL` pointing to a separately provisioned **loopback**
PostgreSQL database named `foundation_test_*` on a non-5432 port, with the schema
already applied. `pnpm --filter @workspace/api-server run test` validates this
target and its schema before starting; it never falls back to `DATABASE_URL`.
Prefer the complete gate above, which provisions and removes everything itself.

For a direct frontend production compilation in this workspace:

```sh
BASE_PATH=/ PORT=22116 pnpm --filter @workspace/practice-management run build
```

The API suite verifies demo isolation, CSRF, session rotation/logout,
no-identity/no-membership/cross-practice denial, Administrator separation,
disabled/Entra fail-closed modes, production rejection, and concurrent/repeated
bootstrap protection. PostgreSQL integration-test writes live only in a temporary
test schema that is removed afterward; they never create a real Administrator.

Browser checks require Chromium (`CHROMIUM_PATH` can override the workspace
executable) and running workflows. They exercise demo entry, reload persistence,
desktop/mobile navigation, access-denied and not-found screens, and logout.
Screenshots are generated under ignored `generated-artifacts/`. Real signed-in
Microsoft identity UI cannot be verified until Entra is implemented.

## UI design system

Shared theme tokens and components provide consistent typography, spacing,
panels, buttons, status labels, errors and loading states. Navigation adapts to
phones; future modules are visibly unavailable. See
[`artifacts/practice-management/DESIGN.md`](artifacts/practice-management/DESIGN.md)
for the palette, fonts, spacing and radius tokens.

## Post-merge setup

`scripts/post-merge.sh` installs locked dependencies only. It does not migrate
schemas, seed data, configure authentication, or bootstrap an Administrator.
Workflow reconciliation runs afterward.

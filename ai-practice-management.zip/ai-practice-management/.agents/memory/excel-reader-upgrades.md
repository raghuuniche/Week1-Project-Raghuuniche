---
name: Excel reader upgrades
description: Avoid assuming an Excel reader's default return value is a row matrix.
---

Check installed Excel-reader declarations and exercise a real XLSX file after
upgrades; never cast away a workbook-versus-row-matrix mismatch.

**Why:** The default reader in the installed package returned workbook sheets,
not the row matrix expected from older examples. CSV-only checks could not detect
the resulting Excel import failure.

**How to apply:** Preserve the intended worksheet-selection contract explicitly
when changing import dependencies, and include a successful XLSX import in
verification rather than relying only on CSV or invalid-workbook tests.

---
name: Vite build and test environment boundary
description: An inherited test environment can keep Vite development flags enabled during a build.
---
Do not rely on the `vite build` command alone to disable demo code when a parent
test runner supplies `NODE_ENV=test`. Vite can still expose `import.meta.env.DEV`
as true in that configuration.

**Why:** The synthetic foundation runner deliberately sets a test environment;
its build initially retained demo chunks despite the production alias boundary.

**How to apply:** Keep build/serve compile-time boundaries explicit and retain
the production asset exclusion check. Development demo browser verification
must use a development frontend, not a production build with demo enabled.

---
name: Application spending limit
description: User's spending constraint for building this application.
---

The user does not want to spend any money building the application beyond the credit limit of their Pro plan.

**Why:** The user explicitly stated this constraint.

**How to apply:** Keep application-building work within included credits. Do not authorize additional paid services or overage spending; do not treat implementation approval as spending authorization.

---
name: Embedded demo access
description: Confirmed workaround for the user's embedded Preview session failure.
---

The user confirmed that Start demo session works in a separate browser tab, while embedded Preview reports a session-cookie/security-token error.

**Why:** Separate-tab access let the user enter the demo without changing browser settings. Automated top-level and simulated embedded checks did not reproduce the user's failure, so the exact browser-specific cause is unverified.

**How to apply:** Recommend the separate-tab demo for review if this embedded error recurs. Do not weaken session or CSRF protections, claim a proven cookie-blocking cause, or treat successful demo access as owner acceptance of the demo or release scope.

---
name: Modal regression sequencing
description: Separate asynchronous file-read races from modal close transitions in synthetic browser checks.
---

Control asynchronous file-read promises explicitly, and wait for a modal to finish closing before changing role or opening another modal.

**Why:** Dialog closing transitions can still restore focus and handle outside interactions after a Cancel click completes. Sequencing the next interaction too early produced a false import failure, unrelated to file parsing or role permissions.

**How to apply:** Browser regression checks for stale reads should release deliberately deferred promises, rather than depend on sleep durations; synchronize modal lifecycle separately from the read being tested.

---
name: Demo approval and development scope
description: Owner acceptance commissions first-release development, not launch, spending or real-data actions.
---
The owner said “lets approve the demo version and move forward” after confirming
the separate-tab demo works. Treat the demonstrated pipeline, delivery, goals
and scoped dashboard/report behavior as accepted development scope.

**Why:** The user explicitly approved the demo, while separately forbidding
additional spending. This is not a grant for publishing, production databases,
real-data migration, external sign-in/provider configuration or launch.

**How to apply:** Do not ask for demo acceptance again. Require separate
target-specific authorization for operational actions and keep launch blocked
until provider recovery, identity/membership and pilot legal obligations are met.

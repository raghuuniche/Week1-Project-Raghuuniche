---
name: Deferred Entra identity binding
description: Why the future SSO adapter must preserve tenant-qualified Administrator identity.
---

Operator-provisioned Administrator access must remain bound to a verified Entra
tenant and immutable object identity when company SSO is enabled later.

**Why:** SSO was intentionally deferred until after demonstration, but the first
Administrator bootstrap is implemented ahead of it. Entra's application-specific
`sub` and email addresses are not interchangeable with tenant-stable `oid`;
changing the identity basis later could strand a grant or associate it incorrectly.

**How to apply:** Validate the token and approved tenant before mapping the
tenant-qualified issuer and object identity. Do not link accounts or repair grants
based on email, unverified claims, or identities from another tenant.

---
name: Recovery cleanup safety
description: Conservative shutdown evidence for disposable recovery rehearsals.
---

Treat a remaining postmaster marker as uncertain shutdown, even when the stop command reports success. Retain the disposable directory and report failed cleanup rather than claiming the database stopped.

**Why:** A successful command exit alone is insufficient evidence to authorize destructive cleanup. A stale marker may be harmless, but automatic deletion is not worth risking a still-running server's data.

**How to apply:** Preserve this fail-closed policy when changing rehearsal cleanup or its tests. Lifecycle regression tests should use inert command spies and synthetic markers, not actual database processes or inherited operator credentials.

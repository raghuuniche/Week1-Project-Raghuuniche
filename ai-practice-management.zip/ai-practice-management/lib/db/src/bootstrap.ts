import type { Pool } from "pg";

export type BootstrapInput = { tenantId: string; objectId: string; operator: string; confirmed: boolean };
export function validateBootstrapInput(input: BootstrapInput) {
  if (!input.confirmed) throw new Error("Explicit --confirm-first-administrator confirmation is required.");
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuid.test(input.tenantId) || !uuid.test(input.objectId)) {
    throw new Error("Supply independently verified Entra tenant and object UUIDs; demo identities are forbidden.");
  }
  if (!input.operator.trim() || input.operator.trim().length > 200) throw new Error("An operator identity of 1–200 characters is required.");
  return {
    issuer: `https://login.microsoftonline.com/${input.tenantId.toLowerCase()}/v2.0`,
    subject: input.objectId.toLowerCase(),
    operator: input.operator.trim(),
  };
}

// Trusted CLI only. There is no HTTP route calling this function.
export async function bootstrapFirstAdministrator(pool: Pool, input: BootstrapInput): Promise<void> {
  const { issuer, subject, operator } = validateBootstrapInput(input);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(741903, 1)");
    const existing = await client.query(
      "SELECT 1 FROM administrator_bootstrap_audits UNION ALL SELECT 1 FROM global_administrator_grants LIMIT 1",
    );
    if (existing.rowCount) throw new Error("Initial Administrator bootstrap was already completed.");
    const linked = await client.query<{ user_id: string; status: string }>(
      "SELECT l.user_id, u.status FROM identity_links l JOIN users u ON u.id = l.user_id WHERE l.issuer = $1 AND l.subject = $2",
      [issuer, subject],
    );
    let userId = linked.rows[0]?.user_id;
    if (userId && linked.rows[0]?.status !== "active") throw new Error("Cannot grant Administrator access to a disabled user.");
    if (!userId) {
      const user = await client.query<{ id: string }>("INSERT INTO users (status) VALUES ('active') RETURNING id");
      userId = user.rows[0]!.id;
      await client.query("INSERT INTO identity_links (user_id, issuer, subject) VALUES ($1, $2, $3)", [userId, issuer, subject]);
    }
    await client.query(
      "INSERT INTO global_administrator_grants (user_id, granted_by_operator) VALUES ($1, $2)",
      [userId, operator],
    );
    await client.query(
      "INSERT INTO administrator_bootstrap_audits (singleton, administrator_user_id, provider_issuer, provider_subject, created_by_operator) VALUES (1, $1, $2, $3, $4)",
      [userId, issuer, subject, operator],
    );
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

import { sql } from "drizzle-orm";
import { check, date, foreignKey, index, integer, jsonb, numeric, pgTable, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { practices } from "./organizations";
import { users } from "./identities";
import { practiceMemberships } from "./access";

export const businessRecords = pgTable("business_records", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull(),
  practiceId: uuid("practice_id").notNull(),
  kind: text("kind", { enum: ["pipeline", "delivery", "goal"] }).notNull(),
  name: text("name").notNull(),
  client: text("client"),
  nameKey: text("name_key"),
  clientKey: text("client_key"),
  assignedUserId: uuid("assigned_user_id").notNull().references(() => users.id, { onDelete: "restrict" }),
  dueDate: date("due_date", { mode: "string" }).notNull(),
  stage: text("stage"),
  value: numeric("value", { precision: 16, scale: 2 }),
  probability: integer("probability"),
  status: text("status"),
  budget: numeric("budget", { precision: 16, scale: 2 }),
  burn: numeric("burn", { precision: 16, scale: 2 }),
  current: numeric("current", { precision: 16, scale: 2 }),
  target: numeric("target", { precision: 16, scale: 2 }),
  unit: text("unit"),
  version: integer("version").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}, (t) => [
  foreignKey({ columns: [t.practiceId, t.organizationId], foreignColumns: [practices.id, practices.organizationId] }).onDelete("restrict"),
  foreignKey({ columns: [t.assignedUserId, t.practiceId], foreignColumns: [practiceMemberships.userId, practiceMemberships.practiceId] }).onDelete("restrict"),
  index("business_records_scope_idx").on(t.practiceId, t.kind, t.assignedUserId),
  uniqueIndex("business_pipeline_duplicate_unique").on(t.practiceId, t.nameKey, t.clientKey).where(sql`${t.kind} = 'pipeline' AND ${t.deletedAt} IS NULL`),
  check("business_record_version_check", sql`${t.version} > 0`),
  check("business_record_name_check", sql`length(trim(${t.name})) BETWEEN 1 AND 200`),
  check("business_record_shape_check", sql`
    (${t.kind} = 'pipeline' AND ${t.client} IS NOT NULL AND ${t.nameKey} IS NOT NULL AND ${t.clientKey} IS NOT NULL
      AND ${t.stage} IS NOT NULL AND ${t.stage} IN ('Qualification','Discovery','Proposal','Negotiation','Won','Lost')
      AND ${t.value} IS NOT NULL AND ${t.value} >= 0 AND ${t.probability} IS NOT NULL AND ${t.probability} BETWEEN 0 AND 100
      AND ${t.status} IS NULL AND ${t.budget} IS NULL AND ${t.burn} IS NULL AND ${t.current} IS NULL AND ${t.target} IS NULL AND ${t.unit} IS NULL)
    OR (${t.kind} = 'delivery' AND ${t.client} IS NOT NULL
      AND ${t.status} IS NOT NULL AND ${t.status} IN ('On track','At risk','Off track','Complete')
      AND ${t.budget} IS NOT NULL AND ${t.budget} >= 0 AND ${t.burn} IS NOT NULL AND ${t.burn} >= 0
      AND ${t.stage} IS NULL AND ${t.value} IS NULL AND ${t.probability} IS NULL AND ${t.current} IS NULL AND ${t.target} IS NULL AND ${t.unit} IS NULL)
    OR (${t.kind} = 'goal' AND ${t.current} IS NOT NULL AND ${t.current} >= 0 AND ${t.target} IS NOT NULL AND ${t.target} > 0 AND ${t.unit} IS NOT NULL
      AND ${t.stage} IS NULL AND ${t.value} IS NULL AND ${t.probability} IS NULL AND ${t.status} IS NULL AND ${t.budget} IS NULL AND ${t.burn} IS NULL AND ${t.client} IS NULL)
  `),
]);
export const businessAudits = pgTable("business_audits", {
  id: uuid("id").primaryKey().defaultRandom(),
  practiceId: uuid("practice_id").notNull().references(() => practices.id, { onDelete: "restrict" }),
  actorUserId: uuid("actor_user_id").notNull().references(() => users.id, { onDelete: "restrict" }),
  recordId: uuid("record_id").references(() => businessRecords.id, { onDelete: "restrict" }),
  action: text("action").notNull(),
  before: jsonb("before"),
  after: jsonb("after"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export const businessImports = pgTable("business_imports", {
  practiceId: uuid("practice_id").notNull().references(() => practices.id, { onDelete: "restrict" }),
  actorUserId: uuid("actor_user_id").notNull().references(() => users.id, { onDelete: "restrict" }),
  key: uuid("key").notNull(),
  payloadHash: text("payload_hash").notNull(),
  result: jsonb("result").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("business_import_retry_unique").on(t.practiceId, t.actorUserId, t.key)]);
export const insertBusinessRecordSchema = createInsertSchema(businessRecords).omit({ id: true, createdAt: true, updatedAt: true, deletedAt: true, version: true });
export const insertBusinessAuditSchema = createInsertSchema(businessAudits).omit({ id: true, createdAt: true });
export const insertBusinessImportSchema = createInsertSchema(businessImports).omit({ createdAt: true });
export type BusinessRecord = typeof businessRecords.$inferSelect;

import { sql } from "drizzle-orm";
import { check, index, pgTable, text, timestamp, unique, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [check("users_status_check", sql`${t.status} IN ('active', 'disabled')`)]);
export const identityLinks = pgTable("identity_links", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  issuer: text("issuer").notNull(),
  subject: text("subject").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("identity_links_issuer_subject_unique").on(t.issuer, t.subject),
  index("identity_links_user_idx").on(t.userId),
]);
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertIdentityLinkSchema = createInsertSchema(identityLinks).omit({ id: true, createdAt: true });
export type User = typeof users.$inferSelect;
export type IdentityLink = typeof identityLinks.$inferSelect;

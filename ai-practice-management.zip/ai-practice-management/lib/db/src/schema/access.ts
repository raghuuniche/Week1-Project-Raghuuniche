import { sql } from "drizzle-orm";
import { boolean, check, index, pgTable, primaryKey, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { users } from "./identities";
import { practices } from "./organizations";

export const PRACTICE_ROLES = ["executive", "practice_director", "manager", "team_member", "administrator"] as const;
export type PracticeRole = typeof PRACTICE_ROLES[number];
export const practiceMemberships = pgTable("practice_memberships", {
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  practiceId: uuid("practice_id").notNull().references(() => practices.id, { onDelete: "restrict" }),
  role: text("role", { enum: PRACTICE_ROLES }).notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  primaryKey({ columns: [t.userId, t.practiceId] }),
  index("practice_memberships_practice_idx").on(t.practiceId),
  check("practice_memberships_role_check", sql`${t.role} IN ('executive', 'practice_director', 'manager', 'team_member', 'administrator')`),
]);
export const insertPracticeMembershipSchema = createInsertSchema(practiceMemberships).omit({ createdAt: true });
export type PracticeMembership = typeof practiceMemberships.$inferSelect;

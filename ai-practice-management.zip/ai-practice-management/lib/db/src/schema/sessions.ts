import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const authenticationSessions = pgTable("authentication_sessions", {
  idHash: text("id_hash").primaryKey(),
  data: jsonb("data").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});
export const insertAuthenticationSessionSchema = createInsertSchema(authenticationSessions);
export type AuthenticationSession = typeof authenticationSessions.$inferSelect;

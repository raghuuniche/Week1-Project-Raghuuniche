import { sql } from "drizzle-orm";
import { check, integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { users } from "./identities";

export const globalAdministratorGrants = pgTable("global_administrator_grants", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "restrict" }),
  grantedAt: timestamp("granted_at", { withTimezone: true }).notNull().defaultNow(),
  grantedByOperator: text("granted_by_operator").notNull(),
});
// A durable singleton prevents a second bootstrap, even if a grant is revoked.
export const administratorBootstrapAudits = pgTable("administrator_bootstrap_audits", {
  singleton: integer("singleton").primaryKey().default(1),
  administratorUserId: uuid("administrator_user_id").notNull().references(() => users.id, { onDelete: "restrict" }),
  providerIssuer: text("provider_issuer").notNull(),
  providerSubject: text("provider_subject").notNull(),
  createdByOperator: text("created_by_operator").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [check("administrator_bootstrap_singleton_check", sql`${t.singleton} = 1`)]);
export const insertAdministratorGrantSchema = createInsertSchema(globalAdministratorGrants).omit({ grantedAt: true });
export const insertAdministratorBootstrapAuditSchema = createInsertSchema(administratorBootstrapAudits).omit({ singleton: true, createdAt: true });
export type AdministratorGrant = typeof globalAdministratorGrants.$inferSelect;
export type AdministratorBootstrapAudit = typeof administratorBootstrapAudits.$inferSelect;

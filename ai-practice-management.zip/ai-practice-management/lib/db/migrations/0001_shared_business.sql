-- Apply ONLY to a separately authorized foundation target. No app startup,
-- build, or post-merge script executes this migration.
BEGIN;
CREATE TABLE IF NOT EXISTS application_schema_versions (version integer PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE practices ADD COLUMN currency text NOT NULL DEFAULT 'USD';
ALTER TABLE practices ADD COLUMN reporting_time_zone text NOT NULL DEFAULT 'UTC';
ALTER TABLE practices ADD CONSTRAINT practices_id_organization_unique UNIQUE(id, organization_id);
CREATE TABLE business_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL, practice_id uuid NOT NULL,
  kind text NOT NULL, name text NOT NULL, client text, name_key text, client_key text,
  assigned_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT, due_date date NOT NULL,
  stage text, value numeric(16,2), probability integer, status text, budget numeric(16,2), burn numeric(16,2),
  current numeric(16,2), target numeric(16,2), unit text,
  version integer NOT NULL DEFAULT 1, created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(), deleted_at timestamptz,
  FOREIGN KEY(practice_id, organization_id) REFERENCES practices(id, organization_id) ON DELETE RESTRICT,
  FOREIGN KEY(assigned_user_id, practice_id) REFERENCES practice_memberships(user_id, practice_id) ON DELETE RESTRICT,
  CONSTRAINT business_record_version_check CHECK(version > 0),
  CONSTRAINT business_record_name_check CHECK(length(trim(name)) BETWEEN 1 AND 200),
  CONSTRAINT business_record_shape_check CHECK(
    (kind = 'pipeline' AND client IS NOT NULL AND name_key IS NOT NULL AND client_key IS NOT NULL
      AND stage IS NOT NULL AND stage IN ('Qualification','Discovery','Proposal','Negotiation','Won','Lost')
      AND value IS NOT NULL AND value >= 0 AND probability IS NOT NULL AND probability BETWEEN 0 AND 100
      AND status IS NULL AND budget IS NULL AND burn IS NULL AND current IS NULL AND target IS NULL AND unit IS NULL)
    OR (kind = 'delivery' AND client IS NOT NULL AND status IS NOT NULL AND status IN ('On track','At risk','Off track','Complete')
      AND budget IS NOT NULL AND budget >= 0 AND burn IS NOT NULL AND burn >= 0
      AND stage IS NULL AND value IS NULL AND probability IS NULL AND current IS NULL AND target IS NULL AND unit IS NULL)
    OR (kind = 'goal' AND current IS NOT NULL AND current >= 0 AND target IS NOT NULL AND target > 0 AND unit IS NOT NULL
      AND stage IS NULL AND value IS NULL AND probability IS NULL AND status IS NULL AND budget IS NULL AND burn IS NULL AND client IS NULL)
  )
);
CREATE INDEX business_records_scope_idx ON business_records(practice_id, kind, assigned_user_id);
CREATE UNIQUE INDEX business_pipeline_duplicate_unique ON business_records(practice_id, name_key, client_key) WHERE kind = 'pipeline' AND deleted_at IS NULL;
CREATE TABLE business_audits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), practice_id uuid NOT NULL REFERENCES practices(id) ON DELETE RESTRICT,
  actor_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT, record_id uuid REFERENCES business_records(id) ON DELETE RESTRICT,
  action text NOT NULL, before jsonb, after jsonb, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE business_imports (
  practice_id uuid NOT NULL REFERENCES practices(id) ON DELETE RESTRICT,
  actor_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT, key uuid NOT NULL,
  payload_hash text NOT NULL, result jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX business_import_retry_unique ON business_imports(practice_id, actor_user_id, key);
CREATE TABLE authentication_sessions (id_hash text PRIMARY KEY, data jsonb NOT NULL, expires_at timestamptz NOT NULL);
INSERT INTO application_schema_versions(version) VALUES(1);
COMMIT;

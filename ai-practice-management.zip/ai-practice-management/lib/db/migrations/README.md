# Shared-record schema release

These are reviewed-source migrations, **not an instruction to run them on a
workspace or production database**. They require separate named-target
authorization. No startup/build/post-merge DDL is installed.

- Empty disposable/new target: baseline `0000_foundation.sql`, then
  `0001_shared_business.sql`, each with SQL stop-on-error.
- Existing foundation: compare deployed columns, keys and constraints with the
  baseline and obtain target-specific migration approval; apply only `0001`.
  Do not run baseline CREATE statements against existing tables. Do not use
  `push-force` to reconcile a production target.
- Each migration commits atomically and records a schema version. A failure
  rolls back its transaction; do not continue with partially applied statements.
- The shared API requires the new columns/tables. Deploy the additive schema
  before enabling verified sign-in/business traffic. Older foundation code can
  run with the additive schema. Do not drop business tables to roll back code:
  preserve committed records and sessions. Verify code/schema compatibility in
  a separately authorized recovery drill before launch.
- `USD`/`UTC` defaults are development configuration, not approval of pilot
  accounting/location rules. Confirm each practice's currency/time zone and
  signed-off report examples before pilot use; calendar dates do not shift
  across time zones and ranges are inclusive. Money is numeric(16,2); weighted
  totals round half-up once to hundredths. No mixed-currency sum is produced.
- Deletions mark records inactive and retain attributed before/after history.
  No automatic record/history purge exists. Legal holds, retention, audit access
  and disposal require owner/Director decisions before real data.
- `pnpm run check:business` applies both files to a fresh loopback-only cluster
  after removing inherited target credentials. It never touches a workspace or
  production database.

Microsoft sign-in remains the existing identity task: its verified adapter must
rotate the signed session ID and establish only tenant-qualified
`{kind:"provider", issuer, subject}` in the shared database session store.
Authentication is not inferred from email, headers or a practice selector.
Administrator membership work owns grant/revoke operations in the existing
membership tables; business access rechecks active memberships on every request.

Recovery remains **unverified** and real-data launch remains **blocked**.

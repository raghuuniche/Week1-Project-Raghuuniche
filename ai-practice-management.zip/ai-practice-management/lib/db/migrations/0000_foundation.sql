-- Baseline for NEW empty targets only. Existing foundation installations must
-- reconcile this baseline before applying 0001; never recreate live tables.
BEGIN;
CREATE TABLE organizations (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE practices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  name text NOT NULL, slug text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT practices_organization_slug_unique UNIQUE(organization_id, slug)
);
CREATE TABLE users (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), status text NOT NULL DEFAULT 'active', created_at timestamptz NOT NULL DEFAULT now(), CONSTRAINT users_status_check CHECK(status IN ('active','disabled')));
CREATE TABLE identity_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  issuer text NOT NULL, subject text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT identity_links_issuer_subject_unique UNIQUE(issuer, subject)
);
CREATE INDEX identity_links_user_idx ON identity_links(user_id);
CREATE TABLE practice_memberships (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, practice_id uuid NOT NULL REFERENCES practices(id) ON DELETE RESTRICT,
  role text NOT NULL, active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(user_id, practice_id),
  CONSTRAINT practice_memberships_role_check CHECK(role IN ('executive','practice_director','manager','team_member','administrator'))
);
CREATE INDEX practice_memberships_practice_idx ON practice_memberships(practice_id);
CREATE TABLE global_administrator_grants (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE RESTRICT, granted_at timestamptz NOT NULL DEFAULT now(), granted_by_operator text NOT NULL
);
CREATE TABLE administrator_bootstrap_audits (
  singleton integer PRIMARY KEY DEFAULT 1, administrator_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  provider_issuer text NOT NULL, provider_subject text NOT NULL, created_by_operator text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT administrator_bootstrap_singleton_check CHECK(singleton = 1)
);
CREATE TABLE application_schema_versions (version integer PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());
INSERT INTO application_schema_versions(version) VALUES(0);
COMMIT;

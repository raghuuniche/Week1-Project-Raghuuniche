export type GoalStatus = "On track" | "At risk" | "Complete";
export type ProjectStatus = "Planning" | "In progress" | "On hold" | "Complete";
export type ProjectHealth = "Healthy" | "Watch" | "Needs attention";
export type OpportunityStage =
  | "Qualification"
  | "Discovery"
  | "Proposal"
  | "Negotiation"
  | "Won"
  | "Lost";
export type Role = "Practice Lead" | "Delivery Lead" | "Consultant";

export interface Goal {
  id: string;
  title: string;
  owner: string;
  dueDate: string;
  status: GoalStatus;
  progress: number;
  category: string;
}

export interface Project {
  id: string;
  name: string;
  client: string;
  owner: string;
  status: ProjectStatus;
  health: ProjectHealth;
  dueDate: string;
  budget: number;
}

export interface Opportunity {
  id: string;
  name: string;
  client: string;
  owner: string;
  stage: OpportunityStage;
  value: number;
  closeDate: string;
  probability: number;
}

export interface PracticeRecords {
  goals: Goal[];
  projects: Project[];
  opportunities: Opportunity[];
}

import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  Activity, ArrowDownRight, ArrowRight, BarChart3, BriefcaseBusiness, CalendarDays,
  Check, CircleHelp, ClipboardCheck, FileText, Flag,
  Gauge, LayoutDashboard, ListFilter, LockKeyhole, Pencil, Plus, RotateCcw,
  Search, Settings2, ShieldAlert, Target, Trash2, TrendingUp, X, LogOut,
} from "lucide-react";
import { resetDemoData, usePracticeRecords } from "./lib/practice-store";
import type {
  Goal, GoalStatus, Opportunity, OpportunityStage, Project, ProjectHealth,
  ProjectStatus, Role,
} from "./types";

type Section = "dashboard" | "goals" | "projects" | "pipeline" | "reports" | "acceptance";
type RecordType = "goal" | "project" | "opportunity";
type ReportPeriod = "week" | "month" | "quarter" | "year";
type AnyRecord = Goal | Project | Opportunity;
type ModalState =
  | { mode: "edit"; kind: RecordType; record?: AnyRecord }
  | { mode: "delete"; kind: RecordType; record: AnyRecord }
  | null;

const paths: Record<Section, string> = {
  dashboard: "/dashboard", goals: "/goals", projects: "/projects",
  pipeline: "/pipeline", reports: "/reports", acceptance: "/acceptance",
};
const menu: { id: Section; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Overview", icon: LayoutDashboard },
  { id: "goals", label: "Practice goals", icon: Target },
  { id: "projects", label: "Delivery", icon: BriefcaseBusiness },
  { id: "pipeline", label: "Pipeline", icon: TrendingUp },
  { id: "reports", label: "Reports", icon: BarChart3 },
  { id: "acceptance", label: "Pilot checklist", icon: ClipboardCheck },
];
const goalStatuses: GoalStatus[] = ["On track", "At risk", "Complete"];
const projectStatuses: ProjectStatus[] = ["Planning", "In progress", "On hold", "Complete"];
const projectHealth: ProjectHealth[] = ["Healthy", "Watch", "Needs attention"];
const stages: OpportunityStage[] = ["Qualification", "Discovery", "Proposal", "Negotiation", "Won", "Lost"];
const roleCanEdit: Record<Role, RecordType[]> = {
  "Practice Lead": ["goal", "project", "opportunity"],
  "Delivery Lead": ["goal", "project"],
  Consultant: [],
};

const money = (amount: number) => new Intl.NumberFormat("en-US", {
  style: "currency", currency: "USD", maximumFractionDigits: 0,
}).format(amount);
const shortDate = (value: string) => {
  if (!value) return "—";
  const date = new Date(`${value}T12:00:00`);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat("en-US", {
    month: "short", day: "numeric", year: "numeric",
  }).format(date);
};
const titleCase = (value: string) => value.charAt(0).toUpperCase() + value.slice(1);
const statusClass = (value: string) => {
  if (["Complete", "On track", "Healthy", "Won"].includes(value)) return "good";
  if (["At risk", "Watch", "Proposal", "Negotiation"].includes(value)) return "watch";
  if (["Needs attention", "On hold", "Lost"].includes(value)) return "risk";
  return "neutral";
};
const localToday = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};
const dateFieldValue = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;

function Badge({ children }: { children: string }) {
  return <span className={`badge ${statusClass(children)}`}>{children}</span>;
}

type AuthStatus = {
  mode: "disabled" | "demo" | "entra";
  authenticated: boolean;
  identity: { kind: "demo" | "provider"; displayName?: string; role?: string } | null;
  demoAvailable: boolean;
  reason?: string;
};

function App() {
  const [auth, setAuth] = useState<AuthStatus | null>(null);
  const [authError, setAuthError] = useState("");
  const [authBusy, setAuthBusy] = useState(false);

  async function refreshAuth() {
    const response = await fetch("/api/auth/status", { credentials: "same-origin" });
    if (!response.ok) throw new Error("Could not check your sign-in status.");
    setAuth(await response.json() as AuthStatus);
  }

  useEffect(() => {
    void refreshAuth().catch((error: unknown) => {
      setAuthError(error instanceof Error ? error.message : "Could not connect to the application.");
    });
  }, []);

  async function signInToDemo() {
    setAuthBusy(true);
    setAuthError("");
    try {
      const csrfResponse = await fetch("/api/auth/csrf", { credentials: "same-origin" });
      if (!csrfResponse.ok) throw new Error("Could not start a secure sign-in session.");
      const { token } = await csrfResponse.json() as { token: string };
      const response = await fetch("/api/auth/demo-session", {
        method: "POST",
        credentials: "same-origin",
        headers: { "x-csrf-token": token },
      });
      if (!response.ok) throw new Error("Pilot demo access is unavailable. Check the server configuration.");
      await refreshAuth();
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : "Sign-in failed.");
    } finally {
      setAuthBusy(false);
    }
  }

  async function signOut() {
    const csrfResponse = await fetch("/api/auth/csrf", { credentials: "same-origin" });
    const { token } = await csrfResponse.json() as { token: string };
    const response = await fetch("/api/auth/logout", {
      method: "POST",
      credentials: "same-origin",
      headers: { "x-csrf-token": token },
    });
    if (!response.ok) {
      setAuthError("Could not end the session. Please refresh and try again.");
      return;
    }
    await refreshAuth();
  }

  if (!auth) {
    return <AuthGate title="Checking access" detail={authError || "Connecting securely to Northstar…"} busy={!authError} onRetry={() => { setAuthError(""); void refreshAuth().catch(() => setAuthError("Could not connect to the application.")); }} />;
  }
  if (!auth.authenticated) {
    const detail = auth.mode === "demo"
      ? "This development session uses a fixed synthetic identity and synthetic browser-local records. It cannot access real practice memberships or data."
      : auth.reason === "ENTRA_NOT_IMPLEMENTED"
        ? "Microsoft Entra ID is the planned sign-in provider, but it has not been connected yet. Pilot access is not enabled in this environment."
        : "Sign-in is disabled until an approved identity provider is configured.";
    return <AuthGate
      title={auth.mode === "demo" ? "Northstar pilot access" : "Sign-in is not configured"}
      detail={detail}
      error={authError}
      busy={authBusy}
      action={auth.demoAvailable ? <button className="button button-primary" onClick={() => void signInToDemo()} disabled={authBusy}>Enter pilot demo</button> : undefined}
      onRetry={() => { setAuthError(""); void refreshAuth().catch(() => setAuthError("Could not connect to the application.")); }}
    />;
  }

  const role = auth.identity?.role === "practice_lead"
    ? "Practice Lead"
    : auth.identity?.role === "delivery_lead" ? "Delivery Lead" : "Consultant";
  return <Workspace role={role} identityName={auth.identity?.displayName ?? "Signed-in user"} onLogout={() => void signOut()} />;
}

function AuthGate({ title, detail, error, busy, action, onRetry }: {
  title: string;
  detail: string;
  error?: string;
  busy?: boolean;
  action?: ReactNode;
  onRetry: () => void;
}) {
  return <main className="auth-gate">
    <section className="auth-card">
      <div className="brand-mark">N</div>
      <div className="eyebrow">Northstar · secure access</div>
      <h1>{title}</h1>
      <p>{detail}</p>
      {error && <div className="auth-error" role="alert">{error}</div>}
      {action}
      {busy && <span className="auth-loading" role="status">Please wait…</span>}
      {!action && <button className="button button-secondary" onClick={onRetry}>Check again</button>}
      <div className="auth-note">The demo sign-in is not Microsoft Entra ID and is not suitable for real practice data.</div>
    </section>
  </main>;
}

function Workspace({ role, identityName, onLogout }: { role: Role; identityName: string; onLogout: () => void }) {
  const records = usePracticeRecords();
  const [section, setSection] = useState<Section>(() => sectionForPath(window.location.pathname));
  const [modal, setModal] = useState<ModalState>(null);
  const [toast, setToast] = useState("");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [period, setPeriod] = useState<ReportPeriod>("month");
  const [anchorDate, setAnchorDate] = useState(localToday());
  const [resetOpen, setResetOpen] = useState(false);

  useEffect(() => {
    const onPop = () => setSection(sectionForPath(window.location.pathname));
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  function go(next: Section) {
    window.history.pushState({}, "", paths[next]);
    setSection(next);
    setSearch("");
    setFilter("All");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function saveRecord(kind: RecordType, form: FormData, existing?: AnyRecord) {
    const value = Object.fromEntries(form.entries());
    if (kind === "goal") {
      const data = {
        title: String(value.title), owner: String(value.owner), dueDate: String(value.dueDate),
        status: String(value.status) as GoalStatus, progress: Number(value.progress),
        category: String(value.category),
      };
      if (existing) records.updateGoal(existing.id, data); else records.addGoal(data);
    } else if (kind === "project") {
      const data = {
        name: String(value.name), client: String(value.client), owner: String(value.owner),
        status: String(value.status) as ProjectStatus, health: String(value.health) as ProjectHealth,
        dueDate: String(value.dueDate), budget: Number(value.budget),
      };
      if (existing) records.updateProject(existing.id, data); else records.addProject(data);
    } else {
      const data = {
        name: String(value.name), client: String(value.client), owner: String(value.owner),
        stage: String(value.stage) as OpportunityStage, value: Number(value.value),
        closeDate: String(value.closeDate), probability: Number(value.probability),
      };
      if (existing) records.updateOpportunity(existing.id, data); else records.addOpportunity(data);
    }
    setModal(null);
    setToast(`${existing ? "Changes saved to" : "Added to"} ${kind === "goal" ? "goals" : kind === "project" ? "delivery" : "pipeline"}`);
  }
  function deleteRecord(kind: RecordType, record: AnyRecord) {
    if (kind === "goal") records.deleteGoal(record.id);
    else if (kind === "project") records.deleteProject(record.id);
    else records.deleteOpportunity(record.id);
    setModal(null);
    setToast("Record deleted");
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark">N</div><div><div className="brand-name">northstar</div><div className="brand-caption">Practice operations</div></div></div>
        <div className="nav-label">Workspace</div>
        <nav className="nav-list" aria-label="Main navigation">
          {menu.map(({ id, label, icon: Icon }) => (
            <a key={id} href={paths[id]} className={`nav-link ${section === id ? "active" : ""}`} onClick={(event) => { event.preventDefault(); go(id); }}>
              <Icon size={17} strokeWidth={1.8} />{label}
            </a>
          ))}
        </nav>
        <div className="sidebar-spacer" />
        <div className="storage-note"><strong><span className="storage-dot" />Synthetic demo workspace</strong>Records shown here are synthetic and saved in this browser only.</div>
        <div className="sidebar-foot">NORTHSTAR · FIRST PRACTICE PILOT</div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <div className="mobile-brand"><div className="brand-mark">N</div>northstar</div>
          <div className="crumb">First practice <span> / </span><strong>{menu.find((item) => item.id === section)?.label}</strong></div>
          <div className="top-actions">
            <span className="signed-in-label">Pilot session · {identityName}</span>
            <button className="button button-secondary logout-button" onClick={onLogout}><LogOut size={14} />Sign out</button>
          </div>
        </header>
        <main className="content">
          <DemoBanner role={role} />
          {section === "dashboard" && <Dashboard records={records} role={role} go={go} />}
          {section === "goals" && <RecordTable kind="goal" title="Practice goals" subtitle="Keep the commitments that move the practice forward in view." rows={records.goals} search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} role={role} onAdd={() => setModal({ mode: "edit", kind: "goal" })} onEdit={(item) => setModal({ mode: "edit", kind: "goal", record: item })} onDelete={(item) => setModal({ mode: "delete", kind: "goal", record: item })} />}
          {section === "projects" && <RecordTable kind="project" title="Delivery tracking" subtitle="A practical view of active work, ownership, health, and budget." rows={records.projects} search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} role={role} onAdd={() => setModal({ mode: "edit", kind: "project" })} onEdit={(item) => setModal({ mode: "edit", kind: "project", record: item })} onDelete={(item) => setModal({ mode: "delete", kind: "project", record: item })} />}
          {section === "pipeline" && <RecordTable kind="opportunity" title="Sales pipeline" subtitle="See potential work, who owns the next move, and what may close." rows={records.opportunities} search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} role={role} onAdd={() => setModal({ mode: "edit", kind: "opportunity" })} onEdit={(item) => setModal({ mode: "edit", kind: "opportunity", record: item })} onDelete={(item) => setModal({ mode: "delete", kind: "opportunity", record: item })} />}
          {section === "reports" && <Reports records={records} period={period} setPeriod={setPeriod} anchorDate={anchorDate} setAnchorDate={setAnchorDate} />}
          {section === "acceptance" && <Acceptance onReset={() => setResetOpen(true)} />}
          <div className="footer-note">Northstar pilot · Synthetic demo records only · Browser-local data</div>
        </main>
      </div>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {menu.map(({ id, label, icon: Icon }) => <a key={id} href={paths[id]} aria-label={label} className={section === id ? "active" : ""} onClick={(event) => { event.preventDefault(); go(id); }}><Icon size={18} strokeWidth={1.8} /><span>{id === "dashboard" ? "Home" : id === "acceptance" ? "Pilot" : id === "projects" ? "Delivery" : titleCase(id)}</span></a>)}
      </nav>
      {modal?.mode === "edit" && <RecordForm kind={modal.kind} record={modal.record} onClose={() => setModal(null)} onSave={(data) => saveRecord(modal.kind, data, modal.record)} />}
      {modal?.mode === "delete" && <ConfirmModal title="Delete this record?" copy={deleteCopy(modal.kind, modal.record)} confirmLabel="Delete record" onCancel={() => setModal(null)} onConfirm={() => deleteRecord(modal.kind, modal.record)} />}
      {resetOpen && <ConfirmModal title="Reset the pilot workspace?" copy="This removes all browser-local edits and restores the original first-practice demo records. This cannot be undone." confirmLabel="Reset demo data" onCancel={() => setResetOpen(false)} onConfirm={() => { resetDemoData(); setResetOpen(false); setToast("Demo records restored"); }} />}
      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}

function sectionForPath(path: string): Section {
  const entry = Object.entries(paths).find(([, value]) => value === path);
  return (entry?.[0] as Section) ?? "dashboard";
}

function DemoBanner({ role }: { role: Role }) {
  return <div className="demo-banner"><ShieldAlert size={15} /><div><strong>Authenticated pilot demo · {role}.</strong> This synthetic session is limited to the demo practice. Microsoft Entra ID is not connected; do not enter real client, employee, or personal information.</div></div>;
}

function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p className="page-subtitle">{subtitle}</p></div>{action}</div>;
}

function Dashboard({ records, role, go }: { records: ReturnType<typeof usePracticeRecords>; role: Role; go: (section: Section) => void }) {
  const atRisk = records.goals.filter((item) => item.status === "At risk").length;
  const watchProjects = records.projects.filter((item) => item.health !== "Healthy" && item.status !== "Complete").length;
  const activeProjects = records.projects.filter((item) => item.status === "In progress").length;
  const openPipeline = records.opportunities.filter((item) => !["Won", "Lost"].includes(item.stage));
  const pipelineValue = openPipeline.reduce((sum, item) => sum + item.value, 0);
  const weighted = openPipeline.reduce((sum, item) => sum + item.value * item.probability / 100, 0);
  const completedGoals = records.goals.filter((item) => item.status === "Complete").length;
  const focus = role === "Practice Lead"
    ? { headline: "Keep the whole practice legible.", body: "Balance commitments, delivery health, and the next wave of work.", figure: money(weighted), label: "weighted open pipeline" }
    : role === "Delivery Lead"
      ? { headline: "Protect delivery confidence.", body: "Start with project health and the practice commitments behind the work.", figure: `${watchProjects}`, label: "projects to review" }
      : { headline: "Your practice, at a glance.", body: "Use this read-only view to find commitments, delivery signals, and upcoming work.", figure: `${activeProjects}`, label: "active projects" };
  return <>
    <PageHeading eyebrow="Operations snapshot" title="Good work, in view." subtitle="A shared read on commitments, delivery, and the work ahead." />
    <div className="role-focus"><div><div className="eyebrow">{role} focus</div><h2>{focus.headline}</h2><p>{focus.body}</p></div><div className="row-aside"><div className="focus-number">{focus.figure}</div><div className="row-meta" style={{ color: "#b9ccbf" }}>{focus.label}</div></div></div>
    <div className="stat-grid">
      <StatCard label="Practice goals" value={`${completedGoals}/${records.goals.length}`} foot={`${atRisk} at risk · ${records.goals.length - completedGoals - atRisk} on track`} />
      <StatCard label="Active delivery" value={activeProjects} foot={`${watchProjects} health signal${watchProjects === 1 ? "" : "s"} to review`} />
      <StatCard label="Open pipeline" value={money(pipelineValue)} foot={`${openPipeline.length} opportunities in play`} />
      <StatCard label="Weighted pipeline" value={money(weighted)} foot="Value adjusted by probability" />
    </div>
    <div className="dashboard-grid">
      <section className="panel">
        <div className="panel-head"><div><div className="panel-title">Commitments in motion</div><div className="panel-caption">Practice goals · progress and next due dates</div></div><a className="text-link" href="/goals" onClick={(event) => { event.preventDefault(); go("goals"); }}>All goals <ArrowRight size={12} /></a></div>
        <div className="panel-body">{records.goals.length ? records.goals.slice(0, 4).map((goal) => <div className="compact-row" key={goal.id}><div className="row-main"><div className="row-name">{goal.title}</div><div className="row-meta">{goal.owner} · due {shortDate(goal.dueDate)}</div><div className="progress-track"><div className="progress-fill" style={{ width: `${Math.max(0, Math.min(100, goal.progress))}%` }} /></div></div><div className="row-aside"><Badge>{goal.status}</Badge><div className="row-meta">{goal.progress}%</div></div></div>) : <EmptyState title="No practice goals yet" detail="Add a goal to make the next commitment visible." />}</div>
      </section>
      <section className="panel">
        <div className="panel-head"><div><div className="panel-title">Delivery signals</div><div className="panel-caption">Health worth a second look</div></div><a className="text-link" href="/projects" onClick={(event) => { event.preventDefault(); go("projects"); }}>Open delivery <ArrowRight size={12} /></a></div>
        <div className="panel-body">{records.projects.filter((item) => item.status !== "Complete").slice(0, 4).length ? records.projects.filter((item) => item.status !== "Complete").slice(0, 4).map((project) => <div className="compact-row" key={project.id}><div className="row-main"><div className="row-name">{project.name}</div><div className="row-meta">{project.client} · {project.owner}</div></div><div className="row-aside"><Badge>{project.health}</Badge><div className="row-meta">due {shortDate(project.dueDate)}</div></div></div>) : <EmptyState title="No active delivery records" detail="Projects will appear here as the practice takes on work." />}</div>
      </section>
    </div>
    <div className="dashboard-grid" style={{ marginTop: 16 }}>
      <section className="panel">
        <div className="panel-head"><div><div className="panel-title">Pipeline moves</div><div className="panel-caption">Open opportunities · stage and likely value</div></div><a className="text-link" href="/pipeline" onClick={(event) => { event.preventDefault(); go("pipeline"); }}>View pipeline <ArrowRight size={12} /></a></div>
        <div className="panel-body">{openPipeline.length ? openPipeline.slice(0, 4).map((opportunity) => <div className="compact-row" key={opportunity.id}><div className="row-main"><div className="row-name">{opportunity.name}</div><div className="row-meta">{opportunity.client} · {opportunity.owner}</div></div><div className="row-aside"><Badge>{opportunity.stage}</Badge><div className="row-meta">{money(opportunity.value)} · {opportunity.probability}%</div></div></div>) : <EmptyState title="No open opportunities" detail="Pipeline is clear for now." />}</div>
      </section>
      <section className="panel">
        <div className="panel-head"><div><div className="panel-title">A useful next check</div><div className="panel-caption">Signals from your current records</div></div><Activity size={16} color="#6e8d78" /></div>
        <div className="panel-body">
          <div className="compact-row"><div className="row-main"><div className="row-name">{atRisk ? `${atRisk} goal${atRisk === 1 ? "" : "s"} need a reset conversation` : "Goal commitments are steady"}</div><div className="row-meta">Current goal status</div></div><Badge>{atRisk ? "At risk" : "On track"}</Badge></div>
          <div className="compact-row"><div className="row-main"><div className="row-name">{watchProjects ? `${watchProjects} delivery health signal${watchProjects === 1 ? "" : "s"} to discuss` : "No delivery health flags"}</div><div className="row-meta">Current non-complete projects</div></div><Badge>{watchProjects ? "Watch" : "Healthy"}</Badge></div>
          <div className="compact-row"><div className="row-main"><div className="row-name">{openPipeline.length ? `${openPipeline.length} open deals · ${money(pipelineValue)} total` : "Pipeline has no open deals"}</div><div className="row-meta">Opportunity coverage</div></div><ArrowDownRight size={15} color="#78907e" /></div>
        </div>
      </section>
    </div>
  </>;
}

function StatCard({ label, value, foot }: { label: string; value: string | number; foot: string }) {
  return <div className="stat-card"><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-foot">{foot}</div></div>;
}

function EmptyState({ title, detail }: { title: string; detail: string }) {
  return <div className="empty-state"><div className="empty-mark"><CircleHelp size={18} /></div><strong>{title}</strong><p>{detail}</p></div>;
}

function RecordTable({ kind, title, subtitle, rows, search, setSearch, filter, setFilter, role, onAdd, onEdit, onDelete }: {
  kind: RecordType; title: string; subtitle: string; rows: AnyRecord[]; search: string;
  setSearch: (value: string) => void; filter: string; setFilter: (value: string) => void;
  role: Role; onAdd: () => void; onEdit: (record: AnyRecord) => void; onDelete: (record: AnyRecord) => void;
}) {
  const canManage = roleCanEdit[role].includes(kind);
  const filterItems = kind === "goal" ? goalStatuses : kind === "project" ? projectStatuses : stages;
  const searched = useMemo(() => rows.filter((item) => Object.values(item).some((value) => String(value).toLowerCase().includes(search.toLowerCase()))), [rows, search]);
  const filtered = filter === "All" ? searched : searched.filter((item) => kind === "goal" ? (item as Goal).status === filter : kind === "project" ? (item as Project).status === filter : (item as Opportunity).stage === filter);
  const addLabel = kind === "goal" ? "Add goal" : kind === "project" ? "Add project" : "Add opportunity";
  return <>
    <PageHeading eyebrow={kind === "goal" ? "Commitments" : kind === "project" ? "Delivery" : "Growth"} title={title} subtitle={subtitle} action={<button className="button button-primary" onClick={onAdd} disabled={!canManage}><Plus size={15} />{addLabel}</button>} />
    <div className="toolbar">
      <div className="search-wrap"><Search size={15} /><input className="search-input" aria-label={`Search ${title}`} placeholder={`Search ${title.toLowerCase()}…`} value={search} onChange={(event) => setSearch(event.target.value)} /></div>
      <ListFilter size={15} color="#89948c" />
      <select className="filter-select" aria-label={`Filter ${title}`} value={filter} onChange={(event) => setFilter(event.target.value)}><option>All</option>{filterItems.map((item) => <option key={item}>{item}</option>)}</select>
    </div>
    <div className="table-panel">
      {filtered.length ? <><div className="table-scroll"><table>
        {kind === "goal" && <><thead><tr><th>Goal</th><th>Owner</th><th>Category</th><th>Due date</th><th>Status</th><th>Progress</th><th aria-label="Actions" /></tr></thead><tbody>{filtered.map((raw) => { const item = raw as Goal; return <tr key={item.id}><td className="table-title"><strong>{item.title}</strong></td><td>{item.owner}</td><td>{item.category}</td><td>{shortDate(item.dueDate)}</td><td><Badge>{item.status}</Badge></td><td>{item.progress}%</td><ActionCell canManage={canManage} onEdit={() => onEdit(item)} onDelete={() => onDelete(item)} /></tr>; })}</tbody></>}
        {kind === "project" && <><thead><tr><th>Project</th><th>Client</th><th>Owner</th><th>Status</th><th>Health</th><th>Due date</th><th>Budget</th><th aria-label="Actions" /></tr></thead><tbody>{filtered.map((raw) => { const item = raw as Project; return <tr key={item.id}><td className="table-title"><strong>{item.name}</strong></td><td>{item.client}</td><td>{item.owner}</td><td><Badge>{item.status}</Badge></td><td><Badge>{item.health}</Badge></td><td>{shortDate(item.dueDate)}</td><td>{money(item.budget)}</td><ActionCell canManage={canManage} onEdit={() => onEdit(item)} onDelete={() => onDelete(item)} /></tr>; })}</tbody></>}
        {kind === "opportunity" && <><thead><tr><th>Opportunity</th><th>Client</th><th>Owner</th><th>Stage</th><th>Value</th><th>Close date</th><th>Probability</th><th aria-label="Actions" /></tr></thead><tbody>{filtered.map((raw) => { const item = raw as Opportunity; return <tr key={item.id}><td className="table-title"><strong>{item.name}</strong></td><td>{item.client}</td><td>{item.owner}</td><td><Badge>{item.stage}</Badge></td><td>{money(item.value)}</td><td>{shortDate(item.closeDate)}</td><td>{item.probability}%</td><ActionCell canManage={canManage} onEdit={() => onEdit(item)} onDelete={() => onDelete(item)} /></tr>; })}</tbody></>}
      </table></div><div className="record-cards">{filtered.map((item) => <RecordCard key={item.id} kind={kind} record={item} canManage={canManage} onEdit={() => onEdit(item)} onDelete={() => onDelete(item)} />)}</div></> : <EmptyState title={rows.length ? "No matching records" : `No ${title.toLowerCase()} yet`} detail={rows.length ? "Try another search or clear the status filter." : canManage ? `Add a ${kind} to make this workspace yours.` : "Records added by practice staff will appear here."} />}
    </div>
    {!canManage && <div className="footer-note"><LockKeyhole size={12} style={{ verticalAlign: "middle", marginRight: 5 }} />This demo role is view-only for {kind === "goal" ? "goals" : kind === "project" ? "projects" : "opportunities"}. Real practice permissions are checked on the server.</div>}
  </>;
}

function RecordCard({ kind, record, canManage, onEdit, onDelete }: { kind: RecordType; record: AnyRecord; canManage: boolean; onEdit: () => void; onDelete: () => void }) {
  const heading = kind === "goal" ? (record as Goal).title : (record as Project | Opportunity).name;
  const details = kind === "goal"
    ? [
      ["Owner", (record as Goal).owner],
      ["Category", (record as Goal).category],
      ["Due date", shortDate((record as Goal).dueDate)],
      ["Progress", `${(record as Goal).progress}%`],
    ]
    : kind === "project"
      ? [
        ["Client", (record as Project).client],
        ["Owner", (record as Project).owner],
        ["Health", (record as Project).health],
        ["Due date", shortDate((record as Project).dueDate)],
        ["Budget", money((record as Project).budget)],
      ]
      : [
        ["Client", (record as Opportunity).client],
        ["Owner", (record as Opportunity).owner],
        ["Value", money((record as Opportunity).value)],
        ["Close date", shortDate((record as Opportunity).closeDate)],
        ["Probability", `${(record as Opportunity).probability}%`],
      ];
  const status = kind === "goal" ? (record as Goal).status : kind === "project" ? (record as Project).status : (record as Opportunity).stage;
  return <article className="record-card">
    <div className="record-card-head"><strong>{heading}</strong><Badge>{status}</Badge></div>
    <dl className="record-card-details">{details.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>
    {canManage && <div className="record-card-actions"><button className="button button-secondary" onClick={onEdit}><Pencil size={13} />Edit</button><button className="button button-secondary" onClick={onDelete}><Trash2 size={13} />Delete</button></div>}
  </article>;
}

function ActionCell({ canManage, onEdit, onDelete }: { canManage: boolean; onEdit: () => void; onDelete: () => void }) {
  return <td><div className="cell-actions">{canManage && <><button className="icon-button" aria-label="Edit record" title="Edit" onClick={onEdit}><Pencil size={14} /></button><button className="icon-button" aria-label="Delete record" title="Delete" onClick={onDelete}><Trash2 size={14} /></button></>}</div></td>;
}

function RecordForm({ kind, record, onClose, onSave }: { kind: RecordType; record?: AnyRecord; onClose: () => void; onSave: (data: FormData) => void }) {
  const existing = Boolean(record);
  const kindLabel = kind === "goal" ? "goal" : kind === "project" ? "project" : "opportunity";
  const goal = kind === "goal" ? record as Goal | undefined : undefined;
  const project = kind === "project" ? record as Project | undefined : undefined;
  const opportunity = kind === "opportunity" ? record as Opportunity | undefined : undefined;
  const today = localToday();
  function field(label: string, name: string, value: string | number, type = "text", required = true, full = false) {
    return <div className={`field ${full ? "full" : ""}`} key={name}><label htmlFor={`form-${name}`}>{label}</label><input className="field-input" id={`form-${name}`} name={name} type={type} defaultValue={value} required={required} min={type === "number" ? 0 : undefined} max={["progress", "probability"].includes(name) ? 100 : undefined} step={type === "number" ? 1 : undefined} /></div>;
  }
  function selectField(label: string, name: string, options: string[], selected: string, full = false) {
    return <div className={`field ${full ? "full" : ""}`} key={name}><label htmlFor={`form-${name}`}>{label}</label><select className="field-input" id={`form-${name}`} name={name} defaultValue={selected}>{options.map((option) => <option key={option}>{option}</option>)}</select></div>;
  }
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <div className="modal" role="dialog" aria-modal="true" aria-labelledby="form-title">
      <div className="modal-head"><div><h2 id="form-title">{existing ? "Edit" : "Add"} {kindLabel}</h2><p>Keep the record specific and easy to act on.</p></div><button className="icon-button" aria-label="Close" onClick={onClose}><X size={17} /></button></div>
      <form className="modal-body" onSubmit={(event) => { event.preventDefault(); onSave(new FormData(event.currentTarget)); }}>
        <div className="form-grid">
          {kind === "goal" && <>
            {field("Goal title", "title", goal?.title ?? "", "text", true, true)}
            {field("Owner", "owner", goal?.owner ?? "")}
            {field("Category", "category", goal?.category ?? "Delivery")}
            {field("Due date", "dueDate", goal?.dueDate ?? today, "date")}
            {selectField("Status", "status", goalStatuses, goal?.status ?? "On track")}
            {field("Progress", "progress", goal?.progress ?? 0, "number")}
          </>}
          {kind === "project" && <>
            {field("Project name", "name", project?.name ?? "", "text", true, true)}
            {field("Client", "client", project?.client ?? "")}
            {field("Owner", "owner", project?.owner ?? "")}
            {field("Due date", "dueDate", project?.dueDate ?? today, "date")}
            {selectField("Status", "status", projectStatuses, project?.status ?? "Planning")}
            {selectField("Health", "health", projectHealth, project?.health ?? "Healthy")}
            {field("Budget", "budget", project?.budget ?? 0, "number")}
          </>}
          {kind === "opportunity" && <>
            {field("Opportunity name", "name", opportunity?.name ?? "", "text", true, true)}
            {field("Client", "client", opportunity?.client ?? "")}
            {field("Owner", "owner", opportunity?.owner ?? "")}
            {field("Close date", "closeDate", opportunity?.closeDate ?? today, "date")}
            {selectField("Stage", "stage", stages, opportunity?.stage ?? "Qualification")}
            {field("Value", "value", opportunity?.value ?? 0, "number")}
            {field("Probability", "probability", opportunity?.probability ?? 0, "number")}
          </>}
        </div>
        {(kind === "goal" || kind === "opportunity") && <p className="row-meta">{kind === "goal" ? "Progress is a percentage from 0 to 100." : "Probability is a percentage from 0 to 100."}</p>}
        <div className="form-actions"><button type="button" className="button button-secondary" onClick={onClose}>Cancel</button><button type="submit" className="button button-primary"><Check size={14} />{existing ? "Save changes" : `Add ${kindLabel}`}</button></div>
      </form>
    </div>
  </div>;
}

function ConfirmModal({ title, copy, confirmLabel, onCancel, onConfirm }: { title: string; copy: ReactNode; confirmLabel: string; onCancel: () => void; onConfirm: () => void }) {
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onCancel(); }}><div className="modal" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title">
    <div className="modal-head"><div><h2 id="confirm-title">{title}</h2><p>Review before continuing.</p></div><button className="icon-button" aria-label="Close" onClick={onCancel}><X size={17} /></button></div>
    <div className="modal-body"><p className="confirm-copy">{copy}</p><div className="form-actions"><button className="button button-secondary" onClick={onCancel}>Keep record</button><button className="button button-danger" onClick={onConfirm}>{confirmLabel}</button></div></div>
  </div></div>;
}

function deleteCopy(kind: RecordType, record: AnyRecord) {
  const label = kind === "goal" ? (record as Goal).title : kind === "project" ? (record as Project).name : (record as Opportunity).name;
  return <>You're about to permanently remove <strong>{label}</strong> from this browser's practice records.</>;
}

function Reports({ records, period, setPeriod, anchorDate, setAnchorDate }: { records: ReturnType<typeof usePracticeRecords>; period: ReportPeriod; setPeriod: (value: ReportPeriod) => void; anchorDate: string; setAnchorDate: (value: string) => void }) {
  const report = useMemo(() => {
    const selected = new Date(`${anchorDate}T12:00:00`);
    const start = new Date(selected);
    const end = new Date(selected);
    if (period === "week") {
      const weekday = (selected.getDay() + 6) % 7;
      start.setDate(selected.getDate() - weekday);
      end.setTime(start.getTime()); end.setDate(start.getDate() + 6);
    } else if (period === "month") {
      start.setDate(1); end.setMonth(selected.getMonth() + 1, 0);
    } else if (period === "quarter") {
      const quarterMonth = Math.floor(selected.getMonth() / 3) * 3;
      start.setMonth(quarterMonth, 1); end.setMonth(quarterMonth + 3, 0);
    } else {
      start.setMonth(0, 1); end.setMonth(11, 31);
    }
    const inRange = (value: string) => {
      const date = new Date(`${value}T12:00:00`);
      return !Number.isNaN(date.getTime()) && date >= start && date <= end;
    };
    const goals = records.goals.filter((item) => inRange(item.dueDate));
    const projects = records.projects.filter((item) => inRange(item.dueDate));
    const opportunities = records.opportunities.filter((item) => inRange(item.closeDate));
    const openDeals = opportunities.filter((item) => !["Won", "Lost"].includes(item.stage));
    const format = (date: Date) => new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: period === "year" ? "numeric" : undefined }).format(date);
    const periodLabel = period === "week" ? `${format(start)} – ${format(end)}` : period === "month" ? new Intl.DateTimeFormat("en-US", { month: "long", year: "numeric" }).format(selected) : period === "quarter" ? `Q${Math.floor(selected.getMonth() / 3) + 1} ${selected.getFullYear()}` : String(selected.getFullYear());
    const pipelineValue = openDeals.reduce((sum, item) => sum + item.value, 0);
    const weightedValue = openDeals.reduce((sum, item) => sum + item.value * item.probability / 100, 0);
    return { goals, projects, opportunities, openDeals, pipelineValue, weightedValue, periodLabel, start, end };
  }, [records.goals, records.projects, records.opportunities, period, anchorDate]);
  const completedGoals = report.goals.filter((item) => item.status === "Complete").length;
  const projectHealthCount = report.projects.filter((item) => item.health !== "Healthy" && item.status !== "Complete").length;
  const won = report.opportunities.filter((item) => item.stage === "Won");
  const wonValue = won.reduce((sum, item) => sum + item.value, 0);
  return <>
    <PageHeading eyebrow="Period review" title="Reports" subtitle="A current-record summary for the window you choose." />
    <div className="report-controls" style={{ marginBottom: 17 }}>
      <div className="segmented" aria-label="Report period">{(["week", "month", "quarter", "year"] as ReportPeriod[]).map((item) => <button key={item} className={`segment ${period === item ? "selected" : ""}`} onClick={() => setPeriod(item)}>{titleCase(item)}</button>)}</div>
      <label className="row-meta" htmlFor="report-date">Anchor date</label><input id="report-date" className="field-input" type="date" value={anchorDate} onChange={(event) => setAnchorDate(event.target.value)} style={{ width: "auto" }} />
    </div>
    <div className="report-hero"><div><div className="eyebrow">{period} summary · due / close dates in window</div><div className="report-period">{report.periodLabel}</div><div className="report-note">Computed from current browser-local records for {shortDate(dateFieldValue(report.start))} – {shortDate(dateFieldValue(report.end))}</div></div><CalendarDays size={29} color="#d4e58a" /></div>
    <div className="stat-grid">
      <StatCard label="Goals due in period" value={report.goals.length} foot={`${completedGoals} marked complete`} />
      <StatCard label="Projects due in period" value={report.projects.length} foot={`${projectHealthCount} health signals to review`} />
      <StatCard label="Pipeline closing in period" value={money(report.pipelineValue)} foot={`${report.openDeals.length} open opportunities`} />
      <StatCard label="Weighted pipeline" value={money(report.weightedValue)} foot={`${money(wonValue)} won in period`} />
    </div>
    <div className="report-grid">
      <section className="panel"><div className="panel-head"><div><div className="panel-title">Goal outcomes</div><div className="panel-caption">Goals with due dates in selected window</div></div><Flag size={16} color="#6e8d78" /></div><div className="report-breakdown">
        <Breakdown label="Total commitments" value={report.goals.length} /><Breakdown label="Complete" value={completedGoals} /><Breakdown label="On track" value={report.goals.filter((item) => item.status === "On track").length} /><Breakdown label="At risk" value={report.goals.filter((item) => item.status === "At risk").length} />
      </div></section>
      <section className="panel"><div className="panel-head"><div><div className="panel-title">Delivery portfolio</div><div className="panel-caption">Projects with due dates in selected window</div></div><Gauge size={16} color="#6e8d78" /></div><div className="report-breakdown">
        <Breakdown label="Total projects" value={report.projects.length} /><Breakdown label="Healthy" value={report.projects.filter((item) => item.health === "Healthy").length} /><Breakdown label="Watch / needs attention" value={projectHealthCount} /><Breakdown label="Committed budget" value={money(report.projects.reduce((sum, item) => sum + item.budget, 0))} />
      </div></section>
      <section className="panel"><div className="panel-head"><div><div className="panel-title">Opportunity movement</div><div className="panel-caption">Close dates in selected window</div></div><TrendingUp size={16} color="#6e8d78" /></div><div className="report-breakdown">
        <Breakdown label="Opportunities closing" value={report.opportunities.length} /><Breakdown label="Open value" value={money(report.pipelineValue)} /><Breakdown label="Weighted open value" value={money(report.weightedValue)} /><Breakdown label="Won value" value={money(wonValue)} />
      </div></section>
      <section className="panel"><div className="panel-head"><div><div className="panel-title">What's included</div><div className="panel-caption">Data rules for this report</div></div><FileText size={16} color="#6e8d78" /></div><div className="report-breakdown">
        <div className="breakdown-row"><span>Goals</span><strong>Due date in period</strong></div><div className="breakdown-row"><span>Projects</span><strong>Due date in period</strong></div><div className="breakdown-row"><span>Pipeline</span><strong>Close date in period</strong></div><div className="breakdown-row"><span>Totals</span><strong>Live from stored records</strong></div>
      </div></section>
    </div>
    <p className="footer-note">No canned report totals. Changing the period or anchor date recalculates this summary from the records currently stored in this browser.</p>
  </>;
}

function Breakdown({ label, value }: { label: string; value: string | number }) {
  return <div className="breakdown-row"><span>{label}</span><strong>{value}</strong></div>;
}

function Acceptance({ onReset }: { onReset: () => void }) {
  const [checks, setChecks] = useState<boolean[]>(() => {
    try {
      const parsed = JSON.parse(localStorage.getItem("northstar-pilot-checks") ?? "[]");
      return Array.from({ length: 6 }, (_, index) => parsed[index] === true);
    } catch { return Array(6).fill(false); }
  });
  const items = [
    ["Commitments are legible", "Create and update goals with an owner, category, due date, progress, and status. Filter and search the current goal list."],
    ["Delivery has an honest signal", "Track client, accountable owner, status, health, due date, and budget for each project. Check that health signals are clear."],
    ["Pipeline is actionable", "Track opportunity value, owner, stage, expected close date, and probability. Weighted open pipeline reflects those inputs."],
    ["Reports reflect stored work", "Choose a week, month, quarter, or year and an anchor date. Summaries use only current browser records within the period."],
    ["Roles are understood", "Practice Lead manages all record types; Delivery Lead manages goals and projects; Consultant is view-only. This is only a demo distinction."],
    ["Pilot data boundary is clear", "Demo records stay in this browser. The synthetic pilot session cannot access real practice identities, memberships, or records."],
  ];
  function toggle(index: number) {
    const next = checks.map((value, current) => current === index ? !value : value);
    setChecks(next);
    try { localStorage.setItem("northstar-pilot-checks", JSON.stringify(next)); } catch { /* Checklist remains usable in memory. */ }
  }
  return <>
    <PageHeading eyebrow="Pilot readiness" title="Acceptance checklist" subtitle="Use this walkthrough to assess the first-practice demo with the team." action={<button className="button button-secondary" onClick={onReset}><RotateCcw size={14} />Reset demo records</button>} />
    <div className="acceptance-callout"><strong>First-practice pilot boundary.</strong> This workspace uses a server-owned synthetic demo session. Demo records do not sync between browsers or people. Microsoft Entra ID remains deferred; do not enter sensitive client or personal information.</div>
    <div className="checklist">{items.map(([title, detail], index) => <div className="check-item" key={title}><div className="check-num">{String(index + 1).padStart(2, "0")}</div><div><div className="check-title">{title}</div><div className="check-copy">{detail}</div></div><button className={`check-state ${checks[index] ? "ready" : ""}`} onClick={() => toggle(index)} aria-pressed={checks[index]}>{checks[index] ? "Reviewed" : "Mark reviewed"}</button></div>)}</div>
    <div className="panel" style={{ marginTop: 17 }}><div className="panel-head"><div><div className="panel-title">Before the pilot is shared more broadly</div><div className="panel-caption">Remaining requirements for real company data</div></div><Settings2 size={16} color="#6e8d78" /></div><div className="report-breakdown"><Breakdown label="Microsoft Entra ID" value="Deferred" /><Breakdown label="Multi-practice access foundation" value="Server-enforced" /><Breakdown label="Production data handling" value="Not for this demo" /></div></div>
  </>;
}

export default App;

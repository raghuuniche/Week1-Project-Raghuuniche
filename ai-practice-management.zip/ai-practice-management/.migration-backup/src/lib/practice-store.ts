import { useEffect, useState } from "react";
import type { Goal, Opportunity, PracticeRecords, Project } from "../types";

const STORAGE_KEY = "northstar-practice-records-v1";
const UPDATE_EVENT = "northstar-records-updated";

const initialRecords: PracticeRecords = {
  goals: [
    { id: "g-1", title: "Grow cloud transformation revenue", owner: "Maya Chen", dueDate: "2026-12-31", status: "On track", progress: 68, category: "Growth" },
    { id: "g-2", title: "Improve project gross margin to 34%", owner: "Jordan Lee", dueDate: "2026-12-31", status: "At risk", progress: 52, category: "Delivery" },
    { id: "g-3", title: "Certify 8 consultants in Azure", owner: "Sam Patel", dueDate: "2026-11-30", status: "On track", progress: 75, category: "People" },
    { id: "g-4", title: "Publish the cloud migration playbook", owner: "Maya Chen", dueDate: "2026-10-30", status: "Complete", progress: 100, category: "Enablement" },
  ],
  projects: [
    { id: "p-1", name: "Cloud foundation", client: "Aperture Health", owner: "Jordan Lee", status: "In progress", health: "Healthy", dueDate: "2026-12-15", budget: 280000 },
    { id: "p-2", name: "Data platform modernization", client: "Northwind Energy", owner: "Sam Patel", status: "In progress", health: "Watch", dueDate: "2026-11-20", budget: 195000 },
    { id: "p-3", name: "Application portfolio review", client: "Juniper Financial", owner: "Jordan Lee", status: "Planning", health: "Healthy", dueDate: "2027-01-31", budget: 86000 },
    { id: "p-4", name: "Secure landing zone", client: "Harbor Retail", owner: "Sam Patel", status: "On hold", health: "Needs attention", dueDate: "2026-10-28", budget: 142000 },
  ],
  opportunities: [
    { id: "o-1", name: "Enterprise cloud migration", client: "Vantage Bio", owner: "Maya Chen", stage: "Proposal", value: 420000, closeDate: "2026-11-30", probability: 60 },
    { id: "o-2", name: "FinOps operating model", client: "Northwind Energy", owner: "Jordan Lee", stage: "Negotiation", value: 180000, closeDate: "2026-10-31", probability: 80 },
    { id: "o-3", name: "AI readiness assessment", client: "Aperture Health", owner: "Maya Chen", stage: "Discovery", value: 95000, closeDate: "2026-12-15", probability: 35 },
    { id: "o-4", name: "Data governance program", client: "Juniper Financial", owner: "Sam Patel", stage: "Qualification", value: 260000, closeDate: "2027-01-15", probability: 20 },
  ],
};

function readRecords(): PracticeRecords {
  try {
    const value = localStorage.getItem(STORAGE_KEY);
    if (!value) return initialRecords;
    const parsed = JSON.parse(value) as PracticeRecords;
    if (!Array.isArray(parsed.goals) || !Array.isArray(parsed.projects) || !Array.isArray(parsed.opportunities)) {
      return initialRecords;
    }
    return parsed;
  } catch {
    return initialRecords;
  }
}

function writeRecords(records: PracticeRecords) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  window.dispatchEvent(new Event(UPDATE_EVENT));
}

export function resetDemoData() {
  localStorage.removeItem(STORAGE_KEY);
  window.dispatchEvent(new Event(UPDATE_EVENT));
}

export function usePracticeRecords() {
  const [records, setRecords] = useState<PracticeRecords>(() => readRecords());

  useEffect(() => {
    const refresh = () => setRecords(readRecords());
    window.addEventListener(UPDATE_EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(UPDATE_EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const mutate = (transform: (current: PracticeRecords) => PracticeRecords) => {
    const updated = transform(readRecords());
    writeRecords(updated);
  };

  return {
    ...records,
    addGoal: (value: Omit<Goal, "id">) => mutate((current) => ({ ...current, goals: [{ ...value, id: crypto.randomUUID() }, ...current.goals] })),
    updateGoal: (id: string, value: Partial<Goal>) => mutate((current) => ({ ...current, goals: current.goals.map((item) => item.id === id ? { ...item, ...value } : item) })),
    deleteGoal: (id: string) => mutate((current) => ({ ...current, goals: current.goals.filter((item) => item.id !== id) })),
    addProject: (value: Omit<Project, "id">) => mutate((current) => ({ ...current, projects: [{ ...value, id: crypto.randomUUID() }, ...current.projects] })),
    updateProject: (id: string, value: Partial<Project>) => mutate((current) => ({ ...current, projects: current.projects.map((item) => item.id === id ? { ...item, ...value } : item) })),
    deleteProject: (id: string) => mutate((current) => ({ ...current, projects: current.projects.filter((item) => item.id !== id) })),
    addOpportunity: (value: Omit<Opportunity, "id">) => mutate((current) => ({ ...current, opportunities: [{ ...value, id: crypto.randomUUID() }, ...current.opportunities] })),
    updateOpportunity: (id: string, value: Partial<Opportunity>) => mutate((current) => ({ ...current, opportunities: current.opportunities.map((item) => item.id === id ? { ...item, ...value } : item) })),
    deleteOpportunity: (id: string) => mutate((current) => ({ ...current, opportunities: current.opportunities.filter((item) => item.id !== id) })),
  };
}

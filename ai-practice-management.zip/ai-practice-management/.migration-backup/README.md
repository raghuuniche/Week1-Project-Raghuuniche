# Northstar — practice operations pilot

Northstar is a React and TypeScript web application served by an Express modular monolith. PostgreSQL and Drizzle provide the relational identity, organization, practice, membership, and audit foundation. It is hosted on Replit for the pilot.

## Run locally

Install dependencies and configure `SESSION_SECRET` as a Replit Secret with at least 32 characters. Replit provides `DATABASE_URL` for the managed PostgreSQL database.

```sh
npm install
npm run db:migrate
npm run dev
```

The development server runs on port 5000 and serves the API and Vite app on the same origin. Demo access is enabled explicitly in this Replit development environment with `AUTH_MODE=demo`. To enable it in another development environment, set that non-secret variable there. The default when it is absent is `disabled`.

## Authentication and authorization

- The browser receives a server-signed, HTTP-only session cookie stored in PostgreSQL. Session changes are protected by same-origin checks and a session-bound CSRF token.
- `AUTH_MODE=demo` enables a fixed synthetic pilot identity only outside production. It is rate limited, cannot be enabled as a fallback, and can access only the isolated `demo-practice` scope. Demo access does not read or write real identities, administrator grants, or practice memberships.
- `AUTH_MODE=disabled` fails closed. `AUTH_MODE=entra` reports that Microsoft Entra ID is not implemented; it does not show a fake SSO flow or fall back to demo.
- Microsoft Entra ID is the approved future provider. A verified identity is not itself a practice permission: server requests must resolve an active database membership for the exact practice. A global Administrator grant does not grant practice access.
- The current browser-local goals, delivery, pipeline, and reports are synthetic demo content. Do not enter real client, employee, or personal information.

The `server/auth` and `server/middleware` modules own identity and authorization decisions. `server/db` owns relational persistence. These are modules in one application; there are no microservices. Practice roles currently represented in the schema are Practice Lead, Delivery Lead, and Consultant. Global Administrator grants are stored separately from practice memberships.

## Database schema

The initial Drizzle schema includes organizations, practices, users, provider identity links, practice memberships, separate global Administrator grants, a one-time Administrator bootstrap audit, and PostgreSQL-backed sessions. Practice memberships are keyed by both user and practice. No business-data tables or startup-time schema changes are included.

When changing the schema during development:

```sh
npm run db:generate
npm run db:migrate
```

Do not run schema DDL at server startup. Replit applies managed production schema changes through its publish flow.

## First Administrator bootstrap

The first real Administrator is provisioned by a trusted operator from a deployment-side shell, never through a public HTTP endpoint or first-signup-wins flow. After the schema is applied, supply the target Entra immutable object ID and the operator identity in that shell, then provide the explicit confirmation flag:

```sh
BOOTSTRAP_ADMIN_SUBJECT='<verified immutable Entra object ID>' \
BOOTSTRAP_OPERATOR='<operator identity>' \
npm run admin:bootstrap -- --confirm-first-administrator
```

The command takes a PostgreSQL advisory transaction lock, refuses to run if an Administrator grant already exists, and atomically creates the identity link, global grant, and audit record with the operator and timestamp. There is no reusable bootstrap token or secret. The Administrator grant does not create a practice membership. Do not run this until the subject has been independently verified and the Entra identity adapter is implemented; the grant remains unusable for sign-in while Entra is deferred.

## Checks

```sh
npm test
npm run build
```

Tests cover unauthenticated access, users without practice membership, cross-practice denial, the separation of Administrator and practice access, demo scope isolation, and fail-closed authentication configuration.

## Pilot boundary

The app has an authenticated synthetic demo session and a server-side multi-practice access foundation, but no live Entra sign-in, administrator-management UI, or business data API. Browser-local demo records do not sync between people or browsers. This is not approved for real company data.

The pilot checklist in the app describes the existing synthetic demonstration. Its role examples are demo distinctions and do not establish permissions for real users.

## Post-merge setup

Replit runs `scripts/post-merge.sh` after a task merges. It installs dependencies from the committed lockfile and runs the root build script when one is defined. It does not migrate the database, seed data, or configure authentication. Workflow reconciliation runs afterward.

To run the setup script manually:

```sh
bash scripts/post-merge.sh
```

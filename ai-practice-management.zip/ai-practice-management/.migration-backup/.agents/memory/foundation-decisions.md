---
name: Foundation scope and pilot access decisions
description: Owner-approved stack, foundation scope, pilot access direction, hosting, and first-Administrator bootstrap.
---

The owner approved React, Express, PostgreSQL, and Drizzle with React + TypeScript + Vite for the frontend.

**Why:** The owner selected the recommended stack.

**How to apply:** Keep the implementation a maintainable modular monolith using this stack.

The current requested deliverable is the application foundation only: app shell, navigation, responsive layout, consistent design system, separate authentication and authorization, documented secure first-Administrator bootstrap, and setup documentation. Do not build business modules in this deliverable.

**Why:** The owner explicitly restricted the scope to foundation.

**How to apply:** Treat business workflows as separate work requiring their own request; future navigation must not imply those modules are implemented.

The owner said: “Let us enable SSO after the initial version is build and demonstrated. Goal is to have microsoft entra id authentication in future - you can give a flag to enable and disable so that I can demo app during Pilot phase.”

**Why:** The owner wants to demonstrate the initial version before enabling company SSO.

**How to apply:** Build explicit pilot demonstration access, keep its synthetic identity/data separate from real authorization, and fail closed when disabled. Do not claim Microsoft Entra ID is implemented merely because a mode flag exists.

The owner approved isolated pilot demo access first, Microsoft Entra ID as the future identity provider, Replit hosting for the pilot, and a one-time deployment-side first-Administrator bootstrap. The bootstrap must record who created the Administrator and when, disable itself after successful use, and leave no reusable bootstrap credential.

**Why:** These choices determine the pilot's access and hosting boundaries and the initial privileged account's provenance.

**How to apply:** Treat these as approved design decisions, not implemented capabilities. Keep company SSO optional for the initial demonstration. During implementation, make the bootstrap auditable and single-use; do not create a standing setup credential.

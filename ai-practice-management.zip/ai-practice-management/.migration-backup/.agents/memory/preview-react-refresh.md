---
name: Preview React refresh
description: Replit preview capture can block Vite's inline React refresh initialization even when the development response has no CSP header.
---

The preview capture browser blocked Vite's inline React refresh preamble with a `script-src 'self'` policy even after the application's development CSP was disabled and the development URL showed no CSP response header.

**Why:** This produced a blank screen and a React refresh preamble error despite a successful build and healthy API.

**How to apply:** Keep refresh initialization in the external client entrypoint using the plugin's documented preamble import. Do not weaken the production CSP to fix a development capture problem.

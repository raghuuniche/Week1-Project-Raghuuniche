#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

# Reconcile dependencies with the committed lockfile, without changing it.
if [[ -f pnpm-workspace.yaml ]]; then
  pnpm install --frozen-lockfile
elif [[ -f package-lock.json ]]; then
  npm ci --no-audit --no-fund
else
  echo "Post-merge setup requires a committed package-manager lockfile." >&2
  exit 1
fi

# Only run a build if this project defines one at the root.
if node -e 'process.exit(JSON.parse(require("node:fs").readFileSync("package.json", "utf8")).scripts?.build ? 0 : 1)'; then
  if [[ -f pnpm-workspace.yaml ]]; then
    pnpm run build
  else
    npm run build
  fi
fi

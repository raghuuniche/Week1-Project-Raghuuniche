import { randomBytes } from "node:crypto";
import path from "node:path";
import express, { type ErrorRequestHandler } from "express";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { createServer as createViteServer } from "vite";
import { pool } from "./db/client.js";
import { authorizePractice } from "./auth/authorization.js";
import { isIdentityAllowedByMode, readAuthConfig } from "./auth/config.js";
import { DEMO_IDENTITY } from "./auth/identity.js";
import { requireAuthentication, requireCsrf } from "./middleware/authentication.js";

const PgSessionStore = connectPgSimple(session);

export async function createApp() {
  const authConfig = readAuthConfig();
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  app.use(helmet({
    contentSecurityPolicy: process.env.NODE_ENV === "production"
      ? {
          directives: {
            defaultSrc: ["'self'"],
            connectSrc: ["'self'"],
            imgSrc: ["'self'", "data:"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
            scriptSrc: ["'self'"],
            objectSrc: ["'none'"],
            frameAncestors: ["'self'"],
          },
        }
      : false,
    crossOriginEmbedderPolicy: false,
  }));
  app.use(express.json({ limit: "16kb" }));
  app.use(session({
    name: "northstar.sid",
    secret: requireSessionSecret(),
    store: new PgSessionStore({
      pool,
      tableName: "sessions",
      createTableIfMissing: false,
    }),
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 8 * 60 * 60 * 1000,
      path: "/",
    },
  }));
  app.use((req, _res, next) => {
    if (req.session.identity && !isIdentityAllowedByMode(req.session.identity.kind, authConfig)) {
      delete req.session.identity;
    }
    next();
  });

  app.get("/api/health", (_req, res) => res.json({ ok: true }));
  app.get("/api/auth/status", (req, res) => {
    const identity = req.session.identity;
    res.json({
      mode: authConfig.mode,
      authenticated: Boolean(identity),
      identity: identity?.kind === "demo"
        ? { kind: "demo", displayName: identity.displayName, role: identity.role }
        : identity?.kind === "provider" ? { kind: "provider" } : null,
      demoAvailable: authConfig.demoAvailable,
      reason: authConfig.reason,
    });
  });
  app.get("/api/auth/csrf", (req, res) => {
    req.session.csrfToken ??= randomBytes(32).toString("hex");
    res.setHeader("Cache-Control", "no-store");
    res.json({ token: req.session.csrfToken });
  });

  app.post(
    "/api/auth/demo-session",
    rateLimit({ windowMs: 60_000, limit: 10, standardHeaders: "draft-8", legacyHeaders: false }),
    requireCsrf,
    (req, res, next) => {
      if (!authConfig.demoAvailable || process.env.NODE_ENV === "production") {
        res.status(404).json({ error: "demo_access_unavailable" });
        return;
      }
      req.session.regenerate((error) => {
        if (error) return next(error);
        req.session.identity = { ...DEMO_IDENTITY };
        req.session.csrfToken = randomBytes(32).toString("hex");
        req.session.save((saveError) => {
          if (saveError) return next(saveError);
          res.status(200).json({
            authenticated: true,
            identity: { kind: "demo", displayName: DEMO_IDENTITY.displayName, role: DEMO_IDENTITY.role },
          });
        });
      });
    },
  );

  app.post("/api/auth/logout", requireAuthentication, requireCsrf, (req, res, next) => {
    req.session.destroy((error) => {
      if (error) return next(error);
      res.clearCookie("northstar.sid", { httpOnly: true, sameSite: "lax", path: "/" });
      res.status(204).end();
    });
  });

  app.get("/api/practices/:practiceId/access", requireAuthentication, async (req, res, next) => {
    try {
      const practiceId = req.params.practiceId;
      if (typeof practiceId !== "string") {
        res.status(400).json({ error: "invalid_practice_id" });
        return;
      }
      const access = await authorizePractice(req.session.identity!, practiceId);
      if (!access.allowed) {
        res.status(403).json({ error: "practice_access_denied", reason: access.reason });
        return;
      }
      res.json(access);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/admin/access", requireAuthentication, async (req, res, next) => {
    try {
      const { hasGlobalAdministratorGrant } = await import("./auth/authorization.js");
      if (!await hasGlobalAdministratorGrant(req.session.identity!)) {
        res.status(403).json({ error: "administrator_required" });
        return;
      }
      res.json({ administrator: true });
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/practices/:practiceId/admin-access", requireAuthentication, async (req, res, next) => {
    try {
      if (typeof req.params.practiceId !== "string") {
        res.status(400).json({ error: "invalid_practice_id" });
        return;
      }
      const access = await authorizePractice(req.session.identity!, req.params.practiceId, ["practice_lead"]);
      if (!access.allowed) {
        res.status(403).json({ error: "practice_access_denied", reason: access.reason });
        return;
      }
      res.json({ ...access, practiceAdministrator: true });
    } catch (error) {
      next(error);
    }
  });

  const errorHandler: ErrorRequestHandler = (_error, _req, res, _next) => {
    if (!res.headersSent) res.status(500).json({ error: "internal_server_error" });
  };
  app.use(errorHandler);

  if (process.env.NODE_ENV === "production") {
    const distPath = path.resolve(process.cwd(), "dist");
    app.use(express.static(distPath, { index: false, fallthrough: true }));
    app.use((req, res, next) => {
      if (req.method === "GET" && !req.path.startsWith("/api/")) {
        res.sendFile(path.join(distPath, "index.html"), (error) => {
          if (error) next(error);
        });
      } else {
        next();
      }
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, allowedHosts: true },
      appType: "spa",
    });
    app.locals.viteServer = vite;
    app.use(vite.middlewares);
  }

  return app;
}

export function requireSessionSecret() {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error("SESSION_SECRET must be configured with at least 32 characters.");
  }
  return secret;
}

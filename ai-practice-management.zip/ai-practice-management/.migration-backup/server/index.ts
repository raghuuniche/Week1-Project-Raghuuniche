import { createServer } from "node:http";
import { createApp } from "./app.js";
import { pool } from "./db/client.js";

const port = Number.parseInt(process.env.PORT ?? "5000", 10);
const app = await createApp();
const server = createServer(app);

server.listen(port, "0.0.0.0", () => {
  console.info(`Northstar application listening on port ${port}`);
});

async function shutdown() {
  server.close(async () => {
    await pool.end();
    process.exit(0);
  });
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

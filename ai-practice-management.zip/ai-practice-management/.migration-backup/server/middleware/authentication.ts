import type { NextFunction, Request, Response } from "express";
import { hasGlobalAdministratorGrant } from "../auth/authorization.js";

export function requireAuthentication(req: Request, res: Response, next: NextFunction) {
  if (!req.session.identity) {
    res.status(401).json({ error: "authentication_required" });
    return;
  }
  next();
}

export function requireGlobalAdministrator(req: Request, res: Response, next: NextFunction) {
  const identity = req.session.identity;
  if (!identity) {
    res.status(401).json({ error: "authentication_required" });
    return;
  }
  void hasGlobalAdministratorGrant(identity).then((isAdministrator) => {
      if (!isAdministrator) {
        res.status(403).json({ error: "administrator_required" });
        return;
      }
      next();
    }).catch(next);
}

export function requireCsrf(req: Request, res: Response, next: NextFunction) {
  const origin = req.get("origin");
  const host = req.get("host");
  if (!origin || !host) {
    res.status(403).json({ error: "csrf_origin_required" });
    return;
  }
  try {
    if (new URL(origin).host !== host) {
      res.status(403).json({ error: "csrf_origin_mismatch" });
      return;
    }
  } catch {
    res.status(403).json({ error: "csrf_origin_invalid" });
    return;
  }

  const supplied = req.get("x-csrf-token") ?? "";
  const expected = req.session.csrfToken ?? "";
  if (!supplied || !expected || supplied !== expected) {
    res.status(403).json({ error: "csrf_token_invalid" });
    return;
  }
  next();
}

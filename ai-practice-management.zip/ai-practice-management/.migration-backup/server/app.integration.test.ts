import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { AddressInfo } from "node:net";
import type { Server } from "node:http";
import type { Express } from "express";
import type { ViteDevServer } from "vite";
import supertest from "supertest";

describe("authenticated demo API", () => {
  let app: Express;
  let server: Server;
  let origin: string;
  let viteServer: ViteDevServer | undefined;

  beforeAll(async () => {
    vi.stubEnv("AUTH_MODE", "demo");
    vi.stubEnv("NODE_ENV", "test");
    const { createApp } = await import("./app.js");
    app = await createApp();
    viteServer = app.locals.viteServer as ViteDevServer | undefined;
    server = app.listen(0, "127.0.0.1");
    await new Promise<void>((resolve, reject) => {
      server.once("listening", resolve);
      server.once("error", reject);
    });
    const address = server.address() as AddressInfo;
    origin = `http://127.0.0.1:${address.port}`;
  });

  afterAll(async () => {
    if (server?.listening) await new Promise<void>((resolve) => server.close(() => resolve()));
    await viteServer?.close();
    vi.unstubAllEnvs();
  });

  it("signs in only through the CSRF-protected synthetic session and enforces its practice scope", async () => {
    const client = supertest.agent(server);
    const unauthenticated = await client.get("/api/practices/demo-practice/access");
    expect(unauthenticated.status).toBe(401);

    const csrfResponse = await client.get("/api/auth/csrf");
    expect(csrfResponse.status).toBe(200);
    const token = csrfResponse.body.token as string;

    const badOrigin = await client.post("/api/auth/demo-session")
      .set("Origin", "https://attacker.invalid")
      .set("x-csrf-token", token);
    expect(badOrigin.status).toBe(403);

    const signIn = await client.post("/api/auth/demo-session")
      .set("Origin", origin)
      .set("x-csrf-token", token);
    expect(signIn.status).toBe(200);
    expect(signIn.body.identity).toMatchObject({ kind: "demo", role: "practice_lead" });

    const demoPractice = await client.get("/api/practices/demo-practice/access");
    expect(demoPractice.status).toBe(200);
    expect(demoPractice.body).toMatchObject({ allowed: true, synthetic: true });

    const realPractice = await client.get("/api/practices/00000000-0000-4000-8000-000000000001/access");
    expect(realPractice.status).toBe(403);

    const logoutToken = (await client.get("/api/auth/csrf")).body.token as string;
    const signOut = await client.post("/api/auth/logout")
      .set("Origin", origin)
      .set("x-csrf-token", logoutToken);
    expect(signOut.status).toBe(204);
    expect((await client.get("/api/practices/demo-practice/access")).status).toBe(401);
  });
});

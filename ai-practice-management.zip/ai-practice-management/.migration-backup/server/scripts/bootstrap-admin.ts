import { Pool } from "pg";

const CONFIRMATION = "--confirm-first-administrator";
const ENTRA_ISSUER = "microsoft-entra-id";

function requiredEnvironment(name: string): string {
  const value = process.env[name]?.trim();
  if (!value || value.length > 512) {
    throw new Error(`${name} must be set to a non-empty value of at most 512 characters.`);
  }
  return value;
}

async function bootstrap() {
  if (!process.argv.includes(CONFIRMATION)) {
    throw new Error(`Refusing to provision an Administrator without the exact ${CONFIRMATION} confirmation flag.`);
  }
  const databaseUrl = requiredEnvironment("DATABASE_URL");
  const subject = requiredEnvironment("BOOTSTRAP_ADMIN_SUBJECT");
  const operator = requiredEnvironment("BOOTSTRAP_OPERATOR");
  const pool = new Pool({ connectionString: databaseUrl, max: 1 });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(741903, 1)");
    const alreadyProvisioned = await client.query(
      "SELECT 1 FROM administrator_bootstrap_audits UNION ALL SELECT 1 FROM global_administrator_grants LIMIT 1",
    );
    if (alreadyProvisioned.rowCount) {
      throw new Error("Initial Administrator provisioning has already been completed.");
    }

    const linkedUser = await client.query<{ user_id: string; status: string }>(
      "SELECT identity_links.user_id, users.status FROM identity_links JOIN users ON users.id = identity_links.user_id WHERE issuer = $1 AND subject = $2",
      [ENTRA_ISSUER, subject],
    );
    let userId = linkedUser.rows[0]?.user_id;
    if (userId && linkedUser.rows[0].status !== "active") {
      throw new Error("Refusing to grant Administrator access to a disabled identity.");
    }
    if (!userId) {
      const user = await client.query<{ id: string }>(
        "INSERT INTO users (status) VALUES ('active') RETURNING id",
      );
      userId = user.rows[0].id;
      await client.query(
        "INSERT INTO identity_links (user_id, issuer, subject) VALUES ($1, $2, $3)",
        [userId, ENTRA_ISSUER, subject],
      );
    }
    await client.query(
      "INSERT INTO global_administrator_grants (user_id, role, granted_by_operator) VALUES ($1, 'global_administrator', $2)",
      [userId, operator],
    );
    await client.query(
      "INSERT INTO administrator_bootstrap_audits (administrator_user_id, provider_issuer, provider_subject, created_by_operator) VALUES ($1, $2, $3, $4)",
      [userId, ENTRA_ISSUER, subject, operator],
    );
    await client.query("COMMIT");
    console.info("Initial Administrator grant created and recorded in the audit table.");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

bootstrap().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : "Administrator bootstrap failed.");
  process.exitCode = 1;
});

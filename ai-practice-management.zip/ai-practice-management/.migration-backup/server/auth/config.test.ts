import { describe, expect, it } from "vitest";
import { isIdentityAllowedByMode, readAuthConfig } from "./config.js";

describe("authentication configuration", () => {
  it("defaults to disabled access rather than silently enabling demo", () => {
    expect(readAuthConfig({} as NodeJS.ProcessEnv)).toEqual({
      mode: "disabled",
      demoAvailable: false,
      reason: "AUTH_DISABLED",
    });
  });

  it("allows explicitly configured demo only outside production", () => {
    expect(readAuthConfig({ AUTH_MODE: "demo", NODE_ENV: "development" } as NodeJS.ProcessEnv))
      .toMatchObject({ mode: "demo", demoAvailable: true });
    expect(() => readAuthConfig({ AUTH_MODE: "demo", NODE_ENV: "production" } as NodeJS.ProcessEnv))
      .toThrow("AUTH_MODE=demo is prohibited in production.");
  });

  it("does not claim the future Entra provider is implemented", () => {
    expect(readAuthConfig({ AUTH_MODE: "entra" } as NodeJS.ProcessEnv)).toEqual({
      mode: "entra",
      demoAvailable: false,
      reason: "ENTRA_NOT_IMPLEMENTED",
    });
  });

  it("fails explicitly for unknown authentication modes", () => {
    expect(() => readAuthConfig({ AUTH_MODE: "automatic-fallback" } as NodeJS.ProcessEnv))
      .toThrow("AUTH_MODE must be one of: disabled, demo, entra.");
  });

  it("rejects existing demo sessions when demo access is disabled", () => {
    expect(isIdentityAllowedByMode("demo", readAuthConfig({ AUTH_MODE: "disabled" } as NodeJS.ProcessEnv))).toBe(false);
    expect(isIdentityAllowedByMode("provider", readAuthConfig({ AUTH_MODE: "entra" } as NodeJS.ProcessEnv))).toBe(false);
  });
});

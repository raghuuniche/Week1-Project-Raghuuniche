export type AuthMode = "disabled" | "demo" | "entra";

export interface AuthConfig {
  mode: AuthMode;
  demoAvailable: boolean;
  reason?: "AUTH_DISABLED" | "ENTRA_NOT_IMPLEMENTED";
}

export function isIdentityAllowedByMode(kind: "demo" | "provider", config: AuthConfig): boolean {
  return kind === "demo"
    ? config.mode === "demo" && config.demoAvailable
    : config.mode === "entra" && !config.reason;
}

export function readAuthConfig(
  env: NodeJS.ProcessEnv = process.env,
): AuthConfig {
  const configured = env.AUTH_MODE ?? "disabled";
  if (!["disabled", "demo", "entra"].includes(configured)) {
    throw new Error("AUTH_MODE must be one of: disabled, demo, entra.");
  }

  if (configured === "demo" && env.NODE_ENV === "production") {
    throw new Error("AUTH_MODE=demo is prohibited in production.");
  }

  if (configured === "entra") {
    return { mode: "entra", demoAvailable: false, reason: "ENTRA_NOT_IMPLEMENTED" };
  }
  if (configured === "disabled") {
    return { mode: "disabled", demoAvailable: false, reason: "AUTH_DISABLED" };
  }
  return { mode: "demo", demoAvailable: true };
}

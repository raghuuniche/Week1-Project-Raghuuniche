export const DEMO_PRACTICE_ID = "demo-practice";
export const DEMO_IDENTITY = Object.freeze({
  kind: "demo" as const,
  displayName: "Maya Chen",
  role: "practice_lead" as const,
  practiceId: DEMO_PRACTICE_ID,
});

export type DemoIdentity = typeof DEMO_IDENTITY;
export type ProviderIdentity = {
  kind: "provider";
  issuer: string;
  subject: string;
};
export type AuthenticatedIdentity = DemoIdentity | ProviderIdentity;

declare module "express-session" {
  interface SessionData {
    identity?: AuthenticatedIdentity;
    csrfToken?: string;
  }
}

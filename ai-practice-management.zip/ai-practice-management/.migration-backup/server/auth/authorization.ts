import { and, eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { globalAdministratorGrants, identityLinks, practiceMemberships, users } from "../db/schema.js";
import type { AuthenticatedIdentity } from "./identity.js";
import { resolvePracticeAccess } from "./authorization-policy.js";

export { resolvePracticeAccess } from "./authorization-policy.js";
export type { PracticeAccess } from "./authorization-policy.js";

export async function authorizePractice(
  identity: AuthenticatedIdentity,
  practiceId: string,
  requiredRoles: readonly string[] = [],
) {
  if (identity.kind === "demo") {
    return resolvePracticeAccess(identity, practiceId, async () => null, requiredRoles);
  }

  const [membership] = await db
    .select({ role: practiceMemberships.role })
    .from(identityLinks)
    .innerJoin(users, and(
      eq(identityLinks.userId, users.id),
      eq(users.status, "active"),
    ))
    .innerJoin(practiceMemberships, and(
      eq(practiceMemberships.userId, users.id),
      eq(practiceMemberships.practiceId, practiceId),
      eq(practiceMemberships.active, true),
    ))
    .where(and(
      eq(identityLinks.issuer, identity.issuer),
      eq(identityLinks.subject, identity.subject),
    ))
    .limit(1);

  return resolvePracticeAccess(identity, practiceId, async () => membership?.role ?? null, requiredRoles);
}

export async function hasGlobalAdministratorGrant(identity: AuthenticatedIdentity): Promise<boolean> {
  if (identity.kind === "demo") return false;
  const [grant] = await db
    .select({ userId: globalAdministratorGrants.userId })
    .from(globalAdministratorGrants)
    .innerJoin(identityLinks, eq(identityLinks.userId, globalAdministratorGrants.userId))
    .innerJoin(users, and(
      eq(users.id, globalAdministratorGrants.userId),
      eq(users.status, "active"),
    ))
    .where(and(
      eq(identityLinks.issuer, identity.issuer),
      eq(identityLinks.subject, identity.subject),
    ))
    .limit(1);
  return Boolean(grant);
}

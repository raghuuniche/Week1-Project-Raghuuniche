import { DEMO_PRACTICE_ID, type AuthenticatedIdentity } from "./identity.js";

export type PracticeAccess =
  | { allowed: true; practiceId: string; role: string; synthetic: boolean }
  | { allowed: false; reason: "identity_required" | "no_membership" | "wrong_demo_scope" | "role_denied" };

export async function resolvePracticeAccess(
  identity: AuthenticatedIdentity | null,
  practiceId: string,
  findMembershipRole: (user: AuthenticatedIdentity, practiceId: string) => Promise<string | null>,
  requiredRoles: readonly string[] = [],
): Promise<PracticeAccess> {
  if (!identity) return { allowed: false, reason: "identity_required" };
  if (identity.kind === "demo") {
    if (requiredRoles.length && !requiredRoles.includes(identity.role)) {
      return { allowed: false, reason: "role_denied" };
    }
    return identity.practiceId === DEMO_PRACTICE_ID && practiceId === DEMO_PRACTICE_ID
      ? { allowed: true, practiceId, role: identity.role, synthetic: true }
      : { allowed: false, reason: "wrong_demo_scope" };
  }

  const role = await findMembershipRole(identity, practiceId);
  if (!role) return { allowed: false, reason: "no_membership" };
  if (requiredRoles.length && !requiredRoles.includes(role)) {
    return { allowed: false, reason: "role_denied" };
  }
  return { allowed: true, practiceId, role, synthetic: false };
}

import { describe, expect, it } from "vitest";
import { DEMO_IDENTITY, type AuthenticatedIdentity } from "./identity.js";
import { resolvePracticeAccess } from "./authorization-policy.js";

const providerIdentity: AuthenticatedIdentity = {
  kind: "provider",
  issuer: "microsoft-entra-id",
  subject: "immutable-provider-subject",
};

describe("practice access policy", () => {
  it("denies requests with no authenticated identity", async () => {
    const result = await resolvePracticeAccess(null, "practice-a", async () => "practice_lead");
    expect(result).toEqual({ allowed: false, reason: "identity_required" });
  });

  it("denies a signed-in user who has no membership", async () => {
    const result = await resolvePracticeAccess(providerIdentity, "practice-a", async () => null);
    expect(result).toEqual({ allowed: false, reason: "no_membership" });
  });

  it("does not allow a membership in one practice to cross into another", async () => {
    const result = await resolvePracticeAccess(providerIdentity, "practice-b", async (_identity, targetPractice) =>
      targetPractice === "practice-a" ? "practice_lead" : null,
    );
    expect(result).toEqual({ allowed: false, reason: "no_membership" });
  });

  it("does not let a global Administrator grant replace practice membership", async () => {
    const result = await resolvePracticeAccess(
      providerIdentity,
      "practice-a",
      async () => null,
    );
    expect(result).toEqual({ allowed: false, reason: "no_membership" });
  });

  it("keeps the synthetic demo identity restricted to its synthetic practice", async () => {
    const allowed = await resolvePracticeAccess(DEMO_IDENTITY, "demo-practice", async () => null);
    const denied = await resolvePracticeAccess(DEMO_IDENTITY, "practice-a", async () => "practice_lead");
    expect(allowed).toMatchObject({ allowed: true, synthetic: true, role: "practice_lead" });
    expect(denied).toEqual({ allowed: false, reason: "wrong_demo_scope" });
  });

  it("uses the membership role returned by the server-side lookup", async () => {
    const result = await resolvePracticeAccess(providerIdentity, "practice-a", async () => "consultant");
    expect(result).toEqual({ allowed: true, practiceId: "practice-a", role: "consultant", synthetic: false });
  });

  it("denies a member whose role does not permit the requested operation", async () => {
    const result = await resolvePracticeAccess(providerIdentity, "practice-a", async () => "consultant", ["practice_lead"]);
    expect(result).toEqual({ allowed: false, reason: "role_denied" });
  });
});

import {
  boolean,
  check,
  index,
  jsonb,
  pgTable,
  primaryKey,
  text,
  timestamp,
  unique,
  uuid,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const organizations = pgTable("organizations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const practices = pgTable("practices", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "restrict" }),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  unique("practices_organization_slug_unique").on(table.organizationId, table.slug),
  index("practices_organization_id_idx").on(table.organizationId),
]);

export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  check("users_status_check", sql`${table.status} IN ('active', 'disabled')`),
]);

export const identityLinks = pgTable("identity_links", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  issuer: text("issuer").notNull(),
  subject: text("subject").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  unique("identity_links_issuer_subject_unique").on(table.issuer, table.subject),
  index("identity_links_user_id_idx").on(table.userId),
]);

export const practiceMemberships = pgTable("practice_memberships", {
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  practiceId: uuid("practice_id").notNull().references(() => practices.id, { onDelete: "restrict" }),
  role: text("role").notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  primaryKey({ name: "practice_memberships_pk", columns: [table.userId, table.practiceId] }),
  index("practice_memberships_practice_id_idx").on(table.practiceId),
  check("practice_memberships_role_check", sql`${table.role} IN ('practice_lead', 'delivery_lead', 'consultant')`),
]);

export const globalAdministratorGrants = pgTable("global_administrator_grants", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "restrict" }),
  role: text("role").notNull().default("global_administrator"),
  grantedAt: timestamp("granted_at", { withTimezone: true }).notNull().defaultNow(),
  grantedByOperator: text("granted_by_operator").notNull(),
}, (table) => [
  check("global_administrator_grants_role_check", sql`${table.role} = 'global_administrator'`),
]);

export const administratorBootstrapAudits = pgTable("administrator_bootstrap_audits", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  administratorUserId: uuid("administrator_user_id").notNull().unique()
    .references(() => users.id, { onDelete: "restrict" }),
  providerIssuer: text("provider_issuer").notNull(),
  providerSubject: text("provider_subject").notNull(),
  createdByOperator: text("created_by_operator").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  sid: text("sid").primaryKey(),
  sess: jsonb("sess").notNull(),
  expire: timestamp("expire", { precision: 6, mode: "date" }).notNull(),
}, (table) => [index("sessions_expire_idx").on(table.expire)]);

import { PageHeader, NoAccess } from "@/components/ui-kit";

export default function AccessDenied() {
  return (
    <div data-testid="page-access-denied">
      <PageHeader eyebrow="Access" title="This area needs practice access." />
      <NoAccess />
    </div>
  );
}

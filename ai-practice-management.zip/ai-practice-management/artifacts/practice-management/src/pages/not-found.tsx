import { Link } from "wouter";
import { Compass } from "lucide-react";

export default function NotFound() {
  return (
    <div className="py-16 text-center" data-testid="page-not-found">
      <Compass className="mx-auto h-10 w-10 text-muted-foreground" aria-hidden />
      <h1 className="font-display mt-4 text-4xl font-semibold">Off the chart.</h1>
      <p className="mx-auto mt-3 max-w-md text-muted-foreground">That page does not exist in Northstar. Check the address, or head back to the overview.</p>
      <Link href="/" data-testid="link-home" className="mt-6 inline-block rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">Back to overview</Link>
    </div>
  );
}

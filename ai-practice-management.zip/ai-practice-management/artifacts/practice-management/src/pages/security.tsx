import { PageHeader, Panel, Pill } from "@/components/ui-kit";

const steps = [
  ["Authentication", "Confirms who you are. Signing in grants no real access."],
  ["Practice membership", "A separate grant that places you in a practice with a role."],
  ["Administration", "Manages grants. An administrator grant alone gives no practice access."],
];

export default function Security() {
  return (
    <div>
      <PageHeader eyebrow="Security and access" title="Three separate gates.">
        This is public guidance describing the intended model. It contains no settings and cannot change anything.
      </PageHeader>
      <div className="space-y-6">
        <Panel title="Access model">
          <ol className="space-y-4">
            {steps.map(([t, d], i) => (
              <li key={t} className="flex gap-4" data-testid={`step-access-${i + 1}`}>
                <span className="font-display flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm text-primary-foreground">{i + 1}</span>
                <div><p className="font-semibold">{t}</p><p className="text-sm text-muted-foreground">{d}</p></div>
              </li>
            ))}
          </ol>
        </Panel>
        <Panel title="Demo sessions">
          <p className="text-sm leading-relaxed text-muted-foreground">A demo session is isolated and synthetic. It is always labelled on screen, can be ended at any time, and exposes no administrator controls.</p>
        </Panel>
        <Panel title="Microsoft Entra configuration" testId="panel-entra">
          <div className="mb-3"><Pill tone="warn">Deferred</Pill></div>
          <p className="text-sm leading-relaxed text-muted-foreground">
            Company sign-in through Microsoft Entra is planned for after the pilot. Until it is configured, real sign-in is unavailable and the app reports that configuration is required. Setup will be done by your organisation's administrators outside this page.
          </p>
        </Panel>
      </div>
    </div>
  );
}

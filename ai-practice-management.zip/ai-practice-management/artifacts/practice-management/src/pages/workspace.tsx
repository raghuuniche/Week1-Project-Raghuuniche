import { useMemo, useState } from "react";
import { Panel } from "@/components/ui-kit";
import { Frame, ROLE_LABEL, btn2, inp } from "@/components/workspace/shared";
import { RecordsPage } from "@/components/workspace/records-page";
import { SummaryView, PortfolioSummary } from "@/components/workspace/summary";

/* ------------------------------------------------------------------ pages */
export function WorkspaceDashboard() {
  return (
    <Frame eyebrow="Shared workspace" title="Practice dashboard" intro="Live shared records for the practice you select. Figures follow your role and one declared currency per practice.">
      {(c) => (
        <div className="space-y-6">
          {c.practice.role === "executive" && <PortfolioSummary />}
          <SummaryView c={c} />
          <Panel title="Your access" testId="panel-access">
            <p className="text-sm text-muted-foreground">You are signed in as {ROLE_LABEL[c.practice.role] ?? c.practice.role} in {c.practice.name}. Access is granted per practice and enforced by the server.</p>
          </Panel>
        </div>
      )}
    </Frame>
  );
}
export function WorkspacePipeline() {
  return <Frame eyebrow="Shared workspace" title="Pipeline" intro="Opportunities with value, stage and probability. Won value is pipeline, not booked revenue.">{(c) => <RecordsPage kind="pipeline" c={c} />}</Frame>;
}
export function WorkspaceDelivery() {
  return <Frame eyebrow="Shared workspace" title="Delivery" intro="Projects with status, budget and burn.">{(c) => <RecordsPage kind="delivery" c={c} />}</Frame>;
}
export function WorkspaceGoals() {
  return <Frame eyebrow="Shared workspace" title="Goals" intro="Practice goals with progress against target.">{(c) => <RecordsPage kind="goal" c={c} />}</Frame>;
}
export function WorkspaceReports() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const bad = useMemo(() => !!from && !!to && from > to, [from, to]);
  return (
    <Frame denyRoles={["team_member"]} denyMessage="Practice reports are not available to Team Members. Your own counts appear on the dashboard." eyebrow="Shared workspace" title="Reports" intro="Totals for an inclusive date range. Budgets and won pipeline are shown as they are, never as recognized revenue.">
      {(c) => (
        <div className="space-y-4">
          <div className="flex flex-wrap items-end gap-4">
            <label className="text-sm font-medium">From<input data-testid="input-from" type="date" className={`${inp} mt-1`} value={from} onChange={(e) => setFrom(e.target.value)} /></label>
            <label className="text-sm font-medium">To (inclusive)<input data-testid="input-to" type="date" className={`${inp} mt-1`} value={to} onChange={(e) => setTo(e.target.value)} /></label>
            {(from || to) && <button className={btn2} onClick={() => { setFrom(""); setTo(""); }} data-testid="button-clear-range">Clear range</button>}
          </div>
          {bad ? <p role="alert" className="text-sm font-medium text-destructive" data-testid="text-range-error">The start date must not be after the end date.</p> : <>
            {c.practice.role === "executive" && <PortfolioSummary from={from || undefined} to={to || undefined} />}
            <SummaryView c={c} report from={from || undefined} to={to || undefined} />
          </>}
        </div>
      )}
    </Frame>
  );
}


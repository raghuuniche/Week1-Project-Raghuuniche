import { useSession } from "@/lib/session";
import { PageHeader, Panel, NoAccess, Pill, FactRow, LoadingBlock, ErrorBlock } from "@/components/ui-kit";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { usePocActive } from "@/poc/store";
import { DemoEntry } from "@/components/demo-entry";

const future = ["Goals", "Delivery", "Pipeline", "Skills", "Library", "Meetings", "Partners", "Reports"];

export default function Home() {
  const { auth, foundation, foundationLoading, foundationError, retryFoundation, accessDenied } = useSession();
  const active = !!auth?.sessionActive;
  const pocActive = usePocActive();
  return (
    <div>
      <PageHeader eyebrow="Foundation overview" title="One shared workspace for the practice.">
        Northstar is the home for IT consulting practice leaders and staff. Explore the foundation and a development-only role demo with synthetic pipeline, delivery, goals and reports. Production use is not enabled.
      </PageHeader>
      <div className="space-y-6">
        {!active && <DemoEntry />}
        {active && !auth?.synthetic && (
          <Link href="/workspace" data-testid="link-open-workspace" className="group flex items-center justify-between gap-4 rounded-lg border border-primary bg-primary p-5 text-primary-foreground transition-transform hover:-translate-y-0.5">
            <span><span className="font-display block text-2xl font-semibold">Open shared workspace</span><span className="mt-1 block text-sm">Shared practice pipeline, delivery, goals and reports for the practices you are a verified member of.</span></span>
            <ArrowRight className="h-6 w-6 shrink-0 transition-transform group-hover:translate-x-1" aria-hidden />
          </Link>
        )}
        {pocActive && (
          <Link href="/poc" data-testid="link-open-role-demo" className="group flex items-center justify-between gap-4 rounded-lg border border-[hsl(39_70%_60%)] bg-accent p-5 text-accent-foreground transition-transform hover:-translate-y-0.5">
            <span><span className="font-display block text-2xl font-semibold">Open role demo</span><span className="mt-1 block text-sm">Functional synthetic practice-management preview: pipeline, delivery, goals and reports for five roles.</span></span>
            <ArrowRight className="h-6 w-6 shrink-0 transition-transform group-hover:translate-x-1" aria-hidden />
          </Link>
        )}
        {active && (
          <Panel title="Foundation status" testId="panel-foundation">
            {accessDenied && <NoAccess />}
            {foundationLoading && <LoadingBlock />}
            {foundationError && <ErrorBlock message="Foundation status could not be loaded." onRetry={retryFoundation} />}
            {foundation && (
              <div>
                <p className="mb-2 text-sm text-muted-foreground" data-testid="text-scope">{foundation.practiceName} - {foundation.scope}</p>
                <FactRow testId="fact-identity" label="Identity verified" on={foundation.identityVerified} value={foundation.identityVerified ? "Yes" : "No"} />
                <FactRow testId="fact-data" label="Real data access" on={foundation.realDataAccess} value={foundation.realDataAccess ? "Granted" : "None"} />
                <FactRow testId="fact-modules" label="Production business modules" on={foundation.businessModulesEnabled} value={foundation.businessModulesEnabled ? "Enabled" : "Not enabled"} />
                <FactRow testId="fact-admin" label="Administrator access" on={foundation.administratorAccess} value={foundation.administratorAccess ? "Present" : "None"} />
                <FactRow testId="fact-entra" label="Microsoft Entra sign-in" on={foundation.entraImplemented} value={foundation.entraImplemented ? "Implemented" : "Deferred"} />
              </div>
            )}
          </Panel>
        )}
        <Panel title="What is here today">
          <ul className="space-y-2 text-sm leading-relaxed text-muted-foreground">
            <li>Clear sign-in state and a visible account page.</li>
            <li>A plain-language explanation of how access will be granted.</li>
            <li>Consistent navigation that works on phones and desktops.</li>
            <li>Five preview roles, synthetic data entry, dashboards/reports and Excel/CSV pipeline import in the development demo.</li>
          </ul>
        </Panel>
        <Panel title="Not enabled for production">
          <p className="mb-4 text-sm text-muted-foreground">Real-data business modules are not enabled. Goals, delivery, pipeline and reports can be explored with synthetic data after starting the development demo; the other areas remain planned.</p>
          <div className="flex flex-wrap gap-2" data-testid="list-future">
            {future.map((f) => <Pill key={f} tone="off">{f} - unavailable</Pill>)}
          </div>
        </Panel>
      </div>
    </div>
  );
}

import { useSession } from "@/lib/session";
import { PageHeader, Panel, NoAccess, FactRow, LoadingBlock, ErrorBlock } from "@/components/ui-kit";
import { DemoEntry } from "@/components/demo-entry";

export default function Account() {
  const { auth, authLoading, authError, retryAuth, accessDenied } = useSession();
  return (
    <div>
      <PageHeader eyebrow="Account" title="Who you are, and what that unlocks.">
        Signing in proves who you are. It does not by itself give you access to any practice. Those are separate decisions.
      </PageHeader>
      <div className="space-y-6">
        {authLoading && <LoadingBlock />}
        {authError && <ErrorBlock message="Your account status could not be loaded." onRetry={retryAuth} />}
        {auth && !auth.sessionActive && <DemoEntry />}
        {auth?.sessionActive && (
          <Panel title="Current identity" testId="panel-identity">
            <p className="mb-2 text-sm text-muted-foreground">These values come from the server, not from your browser.</p>
            <FactRow testId="fact-name" label="Display name" on value={auth.displayName ?? "Not provided"} />
            <FactRow testId="fact-mode" label="Sign-in mode" on value={auth.mode} />
            <FactRow testId="fact-role" label="Role" on={!!auth.role} value={auth.role ?? "None"} />
            <FactRow testId="fact-practice" label="Practice membership" on={!!auth.practiceId} value={auth.practiceId ?? "None - no practice access"} />
            <FactRow testId="fact-administrator" label="Administrator" on={auth.administrator} value={auth.administrator ? "Yes (grants no practice access)" : "No"} />
            <FactRow testId="fact-synthetic" label="Synthetic data" on={auth.synthetic} value={auth.synthetic ? "Yes, demo only" : "No"} />
          </Panel>
        )}
        {accessDenied && <NoAccess showLink={false} />}
        <Panel title="What this means">
          <p className="text-sm leading-relaxed text-muted-foreground">
            A demo identity is labelled and synthetic. Administrator status never opens practice data on its own, and no controls for managing other people are shown here.
          </p>
        </Panel>
      </div>
    </div>
  );
}

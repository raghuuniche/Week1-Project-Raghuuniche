import { createContext, useContext, useEffect, useMemo, useRef, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetAuthStatus, getGetAuthStatusQueryKey,
  useGetFoundation, getGetFoundationQueryKey,
  useStartDemo, useEndSession,
  type AuthStatus, type FoundationStatus,
} from "@workspace/api-client-react";
import { startFreshDemo, demoStartErrorMessage } from "./demo-session";

export function errStatus(e: unknown): number | undefined {
  return (e as { status?: number } | null)?.status;
}

type Ctx = {
  auth?: AuthStatus;
  authLoading: boolean;
  authError: boolean;
  retryAuth: () => void;
  foundation?: FoundationStatus;
  foundationLoading: boolean;
  foundationError: boolean;
  staleSession: boolean;
  accessDenied: boolean;
  retryFoundation: () => void;
  startDemo: () => void;
  starting: boolean;
  startFailed: boolean;
  startFailureMessage: string;
  endSession: () => void;
  ending: boolean;
  endFailed: boolean;
};
const SessionCtx = createContext<Ctx | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const authQ = useGetAuthStatus({ query: { queryKey: getGetAuthStatusQueryKey(), retry: false, refetchInterval: 60_000, refetchIntervalInBackground: false } });
  const auth = authQ.data;
  const active = !!auth?.sessionActive;
  const synthetic = !!auth?.synthetic;
  const identityKey = `${active}|${synthetic}|${auth?.displayName ?? ""}|${auth?.role ?? ""}|${auth?.practiceId ?? ""}|${auth?.csrfToken ?? ""}`;
  useEffect(() => {
    const isWs = (q: { queryKey: readonly unknown[] }) => typeof q.queryKey[0] === "string" && (q.queryKey[0] as string).startsWith("/api/workspace");
    qc.cancelQueries({ predicate: isWs });
    qc.removeQueries({ predicate: (q) => typeof q.queryKey[0] === "string" && (q.queryKey[0] as string).startsWith("/api/workspace") });
  }, [identityKey, qc]);
  const foundQ = useGetFoundation({
    query: { queryKey: getGetFoundationQueryKey(), enabled: active && synthetic, retry: false },
  });
  const fStatus = errStatus(foundQ.error);
  const staleSession = active && synthetic && fStatus === 401;
  const accessDenied = active && synthetic && fStatus === 403;
  const staleHandled = useRef(false);
  useEffect(() => {
    return qc.getQueryCache().subscribe((ev) => {
      if (ev.type !== "updated" || ev.action.type !== "error") return;
      const k = ev.query.queryKey[0];
      if (typeof k !== "string" || !k.startsWith("/api/workspace") || errStatus(ev.action.error) !== 401) return;
      qc.setQueryData<AuthStatus | undefined>(getGetAuthStatusQueryKey(), (old) => old ? { ...old, sessionActive: false, displayName: null, role: null, practiceId: null, administrator: false, synthetic: false } : old);
      qc.removeQueries({ predicate: (q) => typeof q.queryKey[0] === "string" && (q.queryKey[0] as string).startsWith("/api/workspace") });
      qc.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
    });
  }, [qc]);

  const signedOut = (old?: AuthStatus): AuthStatus | undefined =>
    old ? { ...old, sessionActive: false, displayName: null, role: null, practiceId: null, administrator: false, synthetic: false } : old;

  useEffect(() => {
    if (!staleSession) { staleHandled.current = false; return; }
    if (staleHandled.current) return;
    staleHandled.current = true;
    qc.setQueryData<AuthStatus | undefined>(getGetAuthStatusQueryKey(), signedOut);
    qc.removeQueries({ queryKey: getGetFoundationQueryKey() });
    qc.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
  }, [staleSession, qc]);

  const reqOpts = { request: { headers: { "X-CSRF-Token": auth?.csrfToken ?? "" } } };
  const clearUser = () => { qc.removeQueries({ queryKey: getGetFoundationQueryKey() }); qc.removeQueries({ predicate: (q) => typeof q.queryKey[0] === "string" && (q.queryKey[0] as string).startsWith("/api/workspace") }); };
  const start = useStartDemo({
    ...reqOpts,
    mutation: {
      mutationFn: startFreshDemo,
      onSuccess: (data) => {
        clearUser();
        qc.setQueryData(getGetAuthStatusQueryKey(), data);
        qc.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
      },
      onError: (e) => {
        if (errStatus(e) === 401 || errStatus(e) === 403) qc.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
      },
    },
  });
  const end = useEndSession({
    ...reqOpts,
    mutation: {
      onSuccess: () => {
        qc.setQueryData<AuthStatus | undefined>(getGetAuthStatusQueryKey(), signedOut);
        clearUser();
        qc.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
      },
      onError: (e) => {
        if (errStatus(e) === 401 || errStatus(e) === 403) {
          qc.setQueryData<AuthStatus | undefined>(getGetAuthStatusQueryKey(), signedOut);
          clearUser();
          qc.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
        }
      },
    },
  });
  const startMutate = start.mutate, endMutate = end.mutate;

  const value = useMemo<Ctx>(() => ({
    auth, authLoading: authQ.isLoading, authError: authQ.isError, retryAuth: () => { authQ.refetch(); },
    foundation: active && synthetic ? foundQ.data : undefined,
    foundationLoading: active && synthetic && foundQ.isLoading,
    foundationError: active && synthetic && foundQ.isError && !staleSession && !accessDenied,
    staleSession, accessDenied, retryFoundation: () => { foundQ.refetch(); },
    startDemo: () => startMutate(), starting: start.isPending, startFailed: start.isError,
    startFailureMessage: demoStartErrorMessage(start.error),
    endSession: () => endMutate(), ending: end.isPending, endFailed: end.isError,
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [auth, authQ.isLoading, authQ.isError, authQ.refetch, active, synthetic, foundQ.data, foundQ.isLoading, foundQ.isError, foundQ.refetch, staleSession, accessDenied, start.isPending, start.isError, start.error, end.isPending, end.isError, startMutate, endMutate]);

  return <SessionCtx.Provider value={value}>{children}</SessionCtx.Provider>;
}

export function useSession() {
  const c = useContext(SessionCtx);
  if (!c) throw new Error("SessionProvider missing");
  return c;
}

import assert from "node:assert/strict";
import { test } from "node:test";
import { demoStartErrorMessage, startFreshDemo } from "./demo-session";

test("demo start obtains the current cookie's token before posting", async () => {
  const originalFetch = globalThis.fetch;
  const calls: string[] = [];
  globalThis.fetch = async (input, options) => {
    const url = String(input);
    calls.push(url);
    assert.equal(options?.credentials, "same-origin");
    if (url === "/api/auth/status") {
      return Response.json({ csrfToken: "synthetic-current-token" });
    }
    assert.equal(url, "/api/auth/demo");
    assert.equal(options?.method, "POST");
    assert.equal(new Headers(options?.headers).get("X-CSRF-Token"), "synthetic-current-token");
    return Response.json({ sessionActive: true });
  };
  try {
    assert.equal((await startFreshDemo()).sessionActive, true);
    assert.deepEqual(calls, ["/api/auth/status", "/api/auth/demo"]);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("failed session refresh never attempts demo start or fabricates success", async () => {
  const originalFetch = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async () => {
    calls++;
    return Response.json({ error: "internal_server_error" }, { status: 500 });
  };
  try {
    await assert.rejects(startFreshDemo());
    assert.equal(calls, 1);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("demo errors give safe actionable messages without exposing payloads", () => {
  assert.match(demoStartErrorMessage({ data: { error: "csrf_token_invalid" } }), /cookie/);
  assert.match(demoStartErrorMessage({ data: { error: "csrf_origin_mismatch" } }), /address/);
  assert.match(demoStartErrorMessage({ data: { error: "demo_unavailable" } }), /development Preview/);
  assert.match(demoStartErrorMessage({ status: 429 }), /one minute/);
  assert.match(demoStartErrorMessage(new Error("sensitive server detail")), /could not start/);
  assert.doesNotMatch(demoStartErrorMessage(new Error("sensitive server detail")), /sensitive/);
});

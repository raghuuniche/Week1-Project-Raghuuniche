import { getAuthStatus, startDemo } from "@workspace/api-client-react";

// A tab may retain an old token after another tab rotates the shared cookie,
// or after the demo API restarts. Get the token for the current cookie at click
// time, not from the periodically refreshed display cache.
export async function startFreshDemo() {
  const current = await getAuthStatus({ credentials: "same-origin" });
  return startDemo({
    credentials: "same-origin",
    headers: { "X-CSRF-Token": current.csrfToken },
  });
}

export function demoStartErrorMessage(error: unknown): string {
  const failure = error as { status?: number; data?: { error?: string } } | null;
  switch (failure?.data?.error) {
    case "csrf_token_invalid":
      return "Your browser could not keep the demo session cookie. Open the app in a new tab from Preview and try again. If it still fails, check whether your browser blocks cookies for this app.";
    case "csrf_origin_mismatch":
    case "csrf_origin_invalid":
      return "The demo request came from an unexpected browser address. Open the app in a new tab from Preview and try again.";
    case "demo_unavailable":
      return "The demo is not enabled in this environment. Use the development Preview; the demo is not available in a published app.";
    default:
      return failure?.status === 429
        ? "Too many demo-start attempts. Wait one minute, then try again."
        : "The demo session could not start. Please try again. If it still fails, open the app in a new tab from Preview.";
  }
}

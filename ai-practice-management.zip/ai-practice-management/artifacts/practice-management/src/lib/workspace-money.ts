export const DEC = /^\d+(\.\d{1,2})?$/;

/** Canonical two-decimal string without any floating-point step. */
export function dec2(v: string): string {
  const [i, f = ""] = v.trim().split(".");
  return `${i.replace(/^0+(?=\d)/, "")}.${(f + "00").slice(0, 2)}`;
}

/** Format a decimal-string amount exactly; the integer part goes through BigInt. */
export function money(v: string | undefined, cur: string): string {
  if (v === undefined || v === "") return "-";
  if (!DEC.test(v.trim())) return `${cur} ${v}`;
  const canon = dec2(v);
  const [ip, frac] = canon.split(".");
  try {
    const nf = new Intl.NumberFormat(undefined, { style: "currency", currency: cur, minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return nf.formatToParts(BigInt(ip)).map((p) => (p.type === "fraction" ? frac : p.value)).join("");
  } catch {
    return `${cur} ${canon}`;
  }
}

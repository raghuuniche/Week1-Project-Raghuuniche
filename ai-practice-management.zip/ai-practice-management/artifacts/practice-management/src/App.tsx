import { lazy, Suspense, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import Home from '@/pages/home';
import Account from '@/pages/account';
import AccessDenied from '@/pages/access-denied';
import Security from '@/pages/security';
import { Shell } from '@/components/shell';
import { SessionProvider } from '@/lib/session';
import { PocBoundary } from '@/poc/store';
import { WorkspaceDashboard, WorkspacePipeline, WorkspaceDelivery, WorkspaceGoals, WorkspaceReports } from '@/pages/workspace';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient({ defaultOptions: { queries: { refetchOnWindowFocus: false } } });
// Compile-time gating excludes the role demo and synthetic business fixtures
// from production chunks, not merely from visible navigation.
const PocDashboard = import.meta.env.DEV ? lazy(() => import('@/poc/dashboard')) : NotFound;
const PocPipeline = import.meta.env.DEV ? lazy(() => import('@/poc/pipeline')) : NotFound;
const PocDelivery = import.meta.env.DEV ? lazy(() => import('@/poc/delivery')) : NotFound;
const PocGoals = import.meta.env.DEV ? lazy(() => import('@/poc/goals')) : NotFound;
const PocReports = import.meta.env.DEV ? lazy(() => import('@/poc/reports')) : NotFound;
const PocAccess = import.meta.env.DEV ? lazy(() => import('@/poc/access')) : NotFound;

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Suspense fallback={<p>Loading page...</p>}><Switch>
        <Route path="/" component={Home} />
        <Route path="/account" component={Account} />
        <Route path="/access-denied" component={AccessDenied} />
        <Route path="/security" component={Security} />
        <Route path="/poc" component={PocDashboard} />
        <Route path="/poc/pipeline" component={PocPipeline} />
        <Route path="/poc/delivery" component={PocDelivery} />
        <Route path="/poc/goals" component={PocGoals} />
        <Route path="/poc/reports" component={PocReports} />
        <Route path="/poc/access" component={PocAccess} />
        <Route path="/workspace" component={WorkspaceDashboard} />
        <Route path="/workspace/pipeline" component={WorkspacePipeline} />
        <Route path="/workspace/delivery" component={WorkspaceDelivery} />
        <Route path="/workspace/goals" component={WorkspaceGoals} />
        <Route path="/workspace/reports" component={WorkspaceReports} />
        <Route component={NotFound} />
      </Switch></Suspense>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <SessionProvider>
            <PocBoundary>
              <Shell>
                <Router />
              </Shell>
            </PocBoundary>
          </SessionProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

import { Link } from "wouter";
import { Settings2, PlayCircle } from "lucide-react";
import { useSession } from "@/lib/session";
import { Panel, LoadingBlock, ErrorBlock } from "@/components/ui-kit";

export function DemoEntry() {
  const { auth, authLoading, authError, retryAuth, startDemo, starting, startFailed, startFailureMessage, staleSession } = useSession();
  if (authLoading) return <LoadingBlock rows={2} />;
  if (authError || !auth) return <ErrorBlock message="Northstar could not confirm your sign-in state. Nothing has been changed." onRetry={retryAuth} />;

  if (auth.mode === "disabled" || (!auth.demoAvailable && auth.mode !== "entra")) {
    return (
      <Panel testId="panel-config-required" className="border-l-4 border-l-[hsl(39_85%_50%)]">
        <div className="flex items-center gap-2 font-display text-xl font-semibold"><Settings2 className="h-5 w-5" aria-hidden />Configuration required</div>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground" data-testid="text-config-reason">
          Sign-in is not configured for this environment. {auth.configurationReason ?? "An administrator must complete setup before anyone can sign in."} This is not single sign-on; no sign-in option is offered until setup is complete.
        </p>
        <Link href="/security" className="mt-4 inline-block text-sm font-semibold underline underline-offset-4" data-testid="link-security-info">Read how access will work</Link>
      </Panel>
    );
  }
  if (auth.mode === "entra") {
    return (
      <Panel testId="panel-entra-pending">
        <h2 className="font-display text-xl font-semibold">Company sign-in is not available yet</h2>
        <p className="mt-2 text-sm text-muted-foreground">Microsoft Entra sign-in is deferred and not implemented in this foundation release.</p>
      </Panel>
    );
  }
  if (!import.meta.env.DEV) return <Panel testId="panel-config-required"><p className="text-sm text-muted-foreground">Demo sessions are available only in development. Verified company sign-in must be configured before shared records can be used.</p></Panel>;
  return (
    <Panel testId="panel-demo-entry" className="bg-primary text-primary-foreground border-primary">
      <h2 className="font-display text-2xl font-semibold">Look around with a demo session</h2>
      <p className="mt-2 max-w-xl text-sm leading-relaxed opacity-85">
        A demo session is synthetic and grants no real data or access. In development builds it also opens a functional proof of concept: pick one of five preview roles and work a pipeline, delivery, goals and reports, all in synthetic data kept in this browser tab. You choose when to start; nothing begins automatically.
      </p>
      {staleSession && <p role="alert" className="mt-3 text-sm font-semibold text-[hsl(39_88%_70%)]">Your previous session expired. Start a new demo session to continue.</p>}
      <div className="mt-5 flex flex-wrap items-center gap-4">
        <button onClick={startDemo} disabled={starting} data-testid="button-start-demo" className="inline-flex items-center gap-2 rounded-md bg-[hsl(39_88%_58%)] px-4 py-2.5 text-sm font-bold text-[hsl(218_45%_12%)] disabled:opacity-60">
          <PlayCircle className="h-4 w-4" aria-hidden />{starting ? "Starting..." : "Start demo session"}
        </button>
        <Link href="/security" className="text-sm font-semibold underline underline-offset-4" data-testid="link-foundation-info">Read the access model first</Link>
      </div>
      {startFailed && <p role="alert" className="mt-3 text-sm font-semibold text-[hsl(39_88%_70%)]">{startFailureMessage}</p>}
    </Panel>
  );
}

import { lazy, Suspense, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Star, Menu, X, LogOut, FlaskConical, Home, Briefcase, UserCircle, ShieldCheck, Lock } from "lucide-react";
import { useSession } from "@/lib/session";
import { usePocActive } from "@/poc/store";
import { AREAS, canView } from "@/poc/policy";
import { usePocOptional } from "@/poc/store";
const RolePicker = import.meta.env.DEV
  ? lazy(() => import("@/poc/role-picker").then((m) => ({ default: m.RolePicker })))
  : () => null;

const live = [
  { href: "/", label: "Overview", icon: Home },
  { href: "/account", label: "Account", icon: UserCircle },
  { href: "/security", label: "Access model", icon: ShieldCheck },
];
const shared = [
  { href: "/workspace", label: "Dashboard" },
  { href: "/workspace/pipeline", label: "Pipeline" },
  { href: "/workspace/delivery", label: "Delivery" },
  { href: "/workspace/goals", label: "Goals" },
  { href: "/workspace/reports", label: "Reports" },
];
const future = ["Goals", "Delivery", "Pipeline", "Skills", "Library", "Meetings", "Partners", "Reports"];

function Nav({ onNavigate }: { onNavigate?: () => void }) {
  const [loc] = useLocation();
  const pocActive = usePocActive();
  const poc = usePocOptional();
  const { auth } = useSession();
  const real = !!auth?.sessionActive && !auth.synthetic;
  const pocLinks = pocActive && poc ? AREAS.filter((a) => canView(poc.state.role, a.area)) : [];
  const futureList = pocActive ? future.filter((f) => !["Goals", "Delivery", "Pipeline", "Reports"].includes(f)) : future;
  return (
    <nav aria-label="Primary" className="flex flex-col gap-6">
      <ul className="space-y-1">
        {live.map(({ href, label, icon: Icon }) => {
          const cur = loc === href;
          return (
            <li key={href}>
              <Link href={href} onClick={onNavigate} aria-current={cur ? "page" : undefined} data-testid={`link-nav-${label.toLowerCase().replace(/\s/g, "-")}`}
                className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors ${cur ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60"}`}>
                <Icon className={`h-4 w-4 ${cur ? "text-sidebar-primary" : ""}`} aria-hidden />{label}
              </Link>
            </li>
          );
        })}
      </ul>
      {real && (
        <div data-testid="nav-workspace">
          <p className="flex items-center gap-2 px-3 font-mono text-[11px] uppercase tracking-[0.16em] text-sidebar-primary"><Briefcase className="h-3 w-3" aria-hidden />Shared workspace</p>
          <ul className="mt-2 space-y-1">
            {shared.map((a) => {
              const cur = loc === a.href;
              return (
                <li key={a.href}>
                  <Link href={a.href} onClick={onNavigate} aria-current={cur ? "page" : undefined} data-testid={`link-nav-workspace-${a.label.toLowerCase()}`}
                    className={`flex items-center rounded-md border-l-2 px-3 py-2 text-sm font-medium transition-colors ${cur ? "border-sidebar-primary bg-sidebar-accent text-sidebar-accent-foreground" : "border-transparent text-sidebar-foreground/80 hover:bg-sidebar-accent/60"}`}>{a.label}</Link>
                </li>
              );
            })}
          </ul>
        </div>
      )}
      {pocLinks.length > 0 && (
        <div data-testid="nav-poc">
          <p className="px-3 font-mono text-[11px] uppercase tracking-[0.16em] text-sidebar-primary">Role demo</p>
          <ul className="mt-2 space-y-1">
            {pocLinks.map((a) => {
              const cur = loc === a.path;
              return (
                <li key={a.path}>
                  <Link href={a.path} onClick={onNavigate} aria-current={cur ? "page" : undefined} data-testid={`link-nav-poc-${a.area}`}
                    className={`flex items-center rounded-md border-l-2 px-3 py-2 text-sm font-medium transition-colors ${cur ? "border-sidebar-primary bg-sidebar-accent text-sidebar-accent-foreground" : "border-transparent text-sidebar-foreground/80 hover:bg-sidebar-accent/60"}`}>{a.label}</Link>
                </li>
              );
            })}
          </ul>
        </div>
      )}
      <div>
        <p className="px-3 font-mono text-[11px] uppercase tracking-[0.16em] text-sidebar-foreground/50">Not yet available</p>
        <ul className="mt-2 space-y-0.5">
          {futureList.map((f) => (
            <li key={f} aria-disabled="true" data-testid={`nav-disabled-${f.toLowerCase()}`} className="flex cursor-not-allowed items-center justify-between rounded-md px-3 py-2 text-sm text-sidebar-foreground/40">
              {f}<Lock className="h-3 w-3" aria-hidden /><span className="sr-only">unavailable</span>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
}

function Brand() {
  return (
    <Link href="/" className="flex items-center gap-2.5" data-testid="link-brand">
      <Star className="h-5 w-5 fill-sidebar-primary text-sidebar-primary" aria-hidden />
      <span className="font-display text-xl font-semibold text-sidebar-accent-foreground">Northstar</span>
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const { auth, endSession, ending, endFailed } = useSession();
  const [open, setOpen] = useState(false);
  const demo = !!auth?.sessionActive && auth.mode === "demo";
  const pocActive = usePocActive();
  return (
    <div className="min-h-[100dvh] bg-background lg:flex">
      <aside className="hidden w-64 shrink-0 flex-col gap-8 bg-sidebar p-5 lg:flex lg:sticky lg:top-0 lg:h-[100dvh] lg:overflow-y-auto">
        <Brand />
        <Nav />
        <p className="mt-auto text-xs leading-relaxed text-sidebar-foreground/50">AI Practice Management. Foundation and synthetic role PoC.</p>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        {demo && (
          <div role="status" data-testid="banner-demo" className="sticky top-0 z-30 flex flex-wrap items-center justify-between gap-2 bg-accent px-4 py-2 text-accent-foreground border-b border-[hsl(39_70%_60%)]">
            <span className="flex items-center gap-2 text-sm font-semibold"><FlaskConical className="h-4 w-4" aria-hidden />{pocActive ? "Synthetic demo - Preview role is a presentation simulation, not an access grant." : "Demo session - synthetic foundation status only. No real data or access."}</span>
            <div className="flex flex-wrap items-center justify-end gap-3 sm:ml-auto">
            {pocActive && <Suspense fallback={null}><RolePicker /></Suspense>}
            <button onClick={endSession} disabled={ending} data-testid="button-logout" className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-1.5 text-sm font-semibold text-primary-foreground disabled:opacity-60">
              <LogOut className="h-4 w-4" aria-hidden />{ending ? "Ending..." : "End demo"}
            </button>
            </div>
            {endFailed && <span role="alert" className="w-full text-sm font-medium text-destructive">Could not end the session. Try again.</span>}
          </div>
        )}
        <header className="flex items-center justify-between bg-sidebar px-4 py-3 lg:hidden">
          <Brand />
          <button onClick={() => setOpen(true)} aria-label="Open navigation" data-testid="button-menu" className="rounded-md p-2 text-sidebar-foreground"><Menu className="h-5 w-5" /></button>
        </header>
        {open && (
          <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation">
            <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
            <div className="absolute inset-y-0 left-0 w-72 max-w-[85vw] overflow-y-auto bg-sidebar p-5">
              <div className="mb-8 flex items-center justify-between"><Brand />
                <button onClick={() => setOpen(false)} aria-label="Close navigation" data-testid="button-menu-close" className="rounded-md p-2 text-sidebar-foreground"><X className="h-5 w-5" /></button></div>
              <Nav onNavigate={() => setOpen(false)} />
            </div>
          </div>
        )}
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-8 sm:py-12">{children}</main>
      </div>
    </div>
  );
}

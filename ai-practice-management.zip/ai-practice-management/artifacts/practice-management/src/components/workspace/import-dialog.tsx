import { useRef, useState } from "react";
import { Download } from "lucide-react";
import { useImportWorkspacePipeline, type WorkspaceRecordInput, type WorkspaceRecord } from "@workspace/api-client-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { LoadingBlock } from "@/components/ui-kit";
import { parsePipelineFile } from "@/poc/pipeline-import";
import { money } from "@/lib/workspace-money";
import { dec2 } from "@/lib/workspace-money";
import { btn, btn2, apiMessage, useInvalidate, type Ctx } from "./shared";

/* ----------------------------------------------------------------- import */
type Parsed = { rows: WorkspaceRecordInput[]; errors: string[]; dupes: string[]; key: string; file: string; sig: string };
const keysByPayload = new Map<string, string>();
const norm = (t: string) => t.normalize("NFKC").trim().replace(/\s+/g, " ").toLowerCase();
const TEMPLATE_HEAD = "name,client,owner,stage,value,closeDate,probability\r\n";

export function ImportDialog({ c, existingRows, onClose }: { c: Ctx; existingRows: WorkspaceRecord[]; onClose: () => void }) {
  const invalidate = useInvalidate(c.practice.id);
  const imp = useImportWorkspacePipeline({ request: { headers: { "X-CSRF-Token": c.csrf } } });
  const [parsed, setParsed] = useState<Parsed | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [result, setResult] = useState<{ inserted: number; skipped: number } | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const seq = useRef(0);

  const template = () => {
    const sample = c.staff[0]?.userId ?? "00000000-0000-0000-0000-000000000000";
    const blob = new Blob([`${TEMPLATE_HEAD}Cloud assessment,Example client,${sample},Discovery,25000.00,2026-12-15,40\r\n`], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "northstar-pipeline-template.csv"; a.click(); URL.revokeObjectURL(url);
  };

  const choose = async (file: File | undefined) => {
    const mine = ++seq.current;
    setResult(null); setErr(null); setParsed(null);
    if (!file) return;
    setBusy(true);
    const r = await parsePipelineFile(file);
    if (mine !== seq.current) return;
    const errors = [...r.errors];
    const rows: WorkspaceRecordInput[] = [];
    const seen = new Map<string, number>();
    const dupes: string[] = [];
    const ids = new Map(c.staff.map((s) => [s.userId.toLowerCase(), s.userId]));
    r.rows.forEach((row, i) => {
      const line = i + 2;
      const owner = ids.get(row.owner.trim().toLowerCase());
      if (!owner) { errors.push(`Row ${line}: owner "${row.owner}" is not the user ID of an active member of this practice. Use the owner UUID from the staff list.`); return; }
      const exact = row.valueDecimal;
      if (!exact) { errors.push(`Row ${line}: value must be a plain amount with at most 14 integer digits and two decimals (exact source text is sent).`); return; }
      if (!Number.isInteger(row.probability)) { errors.push(`Row ${line}: probability must be a whole number.`); return; }
      const rec: WorkspaceRecordInput = { kind: "pipeline", name: row.name, client: row.client, assignedUserId: owner, stage: row.stage, value: dec2(exact), probability: row.probability, dueDate: row.closeDate };
      const sig = JSON.stringify([norm(row.name), norm(row.client)]);
      if (existingRows.some((existing) => norm(existing.name) === norm(row.name) && norm(existing.client ?? "") === norm(row.client))) {
        dupes.push(`Row ${line} already exists in this practice (${row.name}, ${row.client}); it will be skipped without overwriting.`);
      }
      if (seen.has(sig)) dupes.push(`Row ${line} duplicates row ${seen.get(sig)} (${row.name}, ${row.client}).`);
      else seen.set(sig, line);
      rows.push(rec);
    });
    const sigAll = `${c.practice.id}:${JSON.stringify(rows)}`;
    let key = keysByPayload.get(sigAll);
    if (!key) { key = crypto.randomUUID(); keysByPayload.set(sigAll, key); }
    setParsed({ rows, errors, dupes, key, file: file.name, sig: sigAll });
    setBusy(false);
  };

  const confirm = () => {
    if (!parsed || parsed.errors.length || !parsed.rows.length) return;
    setErr(null);
    // The key was minted when this file was parsed, so a failed retry reuses it.
    imp.mutate({ practiceId: c.practice.id, data: { key: parsed.key, rows: parsed.rows } }, {
      onSuccess: (res) => { keysByPayload.delete(parsed.sig); setResult(res); invalidate(); },
      onError: (e) => setErr(apiMessage(e)),
    });
  };

  return (
    <Dialog open onOpenChange={(o) => { if (!o && !imp.isPending) onClose(); }}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-2xl" data-testid="dialog-import">
        <DialogHeader>
          <DialogTitle className="font-display">Import pipeline</DialogTitle>
          <DialogDescription>CSV or XLSX (first sheet), up to 5 MB and 1,000 rows. The owner column must hold the user ID (UUID) of an active practice member; names and emails are not accepted. All rows are committed together or not at all.</DialogDescription>
        </DialogHeader>
        {!result && (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2">
              <button className={btn2} disabled={imp.isPending} onClick={template} data-testid="button-download-template"><Download className="h-4 w-4" aria-hidden />Download template</button>
            </div>
            <div className="rounded-md border border-card-border p-3">
              <p className="mb-2 text-xs font-semibold text-muted-foreground">Owner UUIDs for this practice</p>
              <ul className="space-y-1 font-mono text-xs" data-testid="list-owner-ids">{c.staff.map((s) => <li key={s.userId}>{s.label}: {s.userId}</li>)}</ul>
            </div>
            <input ref={input} type="file" accept=".csv,.xlsx" data-testid="input-import-file" disabled={imp.isPending} className="block w-full text-sm" onChange={(e) => choose(e.target.files?.[0])} />
            {busy && <LoadingBlock rows={1} />}
            {parsed && (
              <div className="space-y-3" data-testid="panel-import-preview">
                <p className="text-sm font-medium">{parsed.file}: {parsed.rows.length} valid row(s), {parsed.errors.length} error(s), {parsed.dupes.length} duplicate(s) in file.</p>
                {parsed.errors.length > 0 && <ul role="alert" className="max-h-48 list-disc space-y-1 overflow-y-auto pl-5 text-sm text-destructive" data-testid="list-import-errors">{parsed.errors.map((m, i) => <li key={i}>{m}</li>)}</ul>}
                {parsed.dupes.length > 0 && <ul className="max-h-32 list-disc space-y-1 overflow-y-auto pl-5 text-sm" data-testid="list-import-dupes">{parsed.dupes.map((m, i) => <li key={i}>{m}</li>)}</ul>}
                {parsed.errors.length === 0 && (
                  <div className="max-h-48 overflow-auto rounded-md border border-card-border">
                    <table className="w-full text-xs"><tbody>{parsed.rows.slice(0, 50).map((r, i) => <tr key={i} className="border-b border-card-border last:border-0"><td className="px-2 py-1">{r.name}</td><td className="px-2 py-1">{r.client}</td><td className="px-2 py-1">{r.stage}</td><td className="px-2 py-1 font-mono">{money(r.value, c.practice.currency)}</td><td className="px-2 py-1 font-mono">{r.dueDate}</td></tr>)}</tbody></table>
                  </div>
                )}
              </div>
            )}
            {err && <p role="alert" className="text-sm font-medium text-destructive" data-testid="text-import-error">{err} You can retry; the same request key is reused so nothing is imported twice.</p>}
            <div className="flex justify-end gap-2">
              <button className={btn2} onClick={onClose} disabled={imp.isPending} data-testid="button-cancel-import">Cancel</button>
              <button className={btn} onClick={confirm} disabled={imp.isPending || busy || !parsed || parsed.errors.length > 0 || parsed.rows.length === 0} data-testid="button-confirm-import">{imp.isPending ? "Importing..." : err ? "Retry import" : "Confirm import"}</button>
            </div>
          </div>
        )}
        {result && (
          <div className="space-y-3" data-testid="panel-import-result">
            <p className="text-sm"><span data-testid="text-import-inserted" className="font-semibold">{result.inserted} inserted</span>, <span data-testid="text-import-skipped" className="font-semibold">{result.skipped} skipped</span> as already present.</p>
            <div className="flex justify-end"><button className={btn} onClick={onClose} data-testid="button-import-done">Done</button></div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}


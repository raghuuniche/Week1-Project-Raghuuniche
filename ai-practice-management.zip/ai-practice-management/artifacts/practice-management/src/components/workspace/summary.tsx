import { useGetWorkspaceSummary, getGetWorkspaceSummaryQueryKey, useGetWorkspacePortfolioSummary, getGetWorkspacePortfolioSummaryQueryKey, type GetWorkspaceSummaryParams, type WorkspaceSummary } from "@workspace/api-client-react";
import { LoadingBlock, ErrorBlock } from "@/components/ui-kit";
import { money } from "@/lib/workspace-money";
import { POLL, type Ctx } from "./shared";

/* -------------------------------------------------------- summary widgets */
function Stat({ label, value, note, id }: { label: string; value: string; note?: string; id: string }) {
  return (
    <div className="rounded-lg border border-card-border bg-card p-4" data-testid={`stat-${id}`}>
      <p className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="font-display mt-1 text-2xl font-semibold">{value}</p>
      {note && <p className="mt-1 text-xs text-muted-foreground">{note}</p>}
    </div>
  );
}

export function SummaryView({ c, from, to, report }: { c: Ctx; from?: string; to?: string; report?: boolean }) {
  const params: GetWorkspaceSummaryParams = { ...(from ? { from } : {}), ...(to ? { to } : {}), ...(report ? { report: true } : {}) };
  const q = useGetWorkspaceSummary(c.practice.id, params, { query: { queryKey: getGetWorkspaceSummaryQueryKey(c.practice.id, params), retry: false, refetchInterval: POLL, refetchIntervalInBackground: false } });
  if (q.isLoading) return <LoadingBlock rows={3} />;
  if (q.isError || !q.data) return <ErrorBlock message="The summary could not be loaded." onRetry={() => q.refetch()} />;
  return <SummaryCards s={q.data} from={from} to={to} team={c.practice.role === "team_member"} />;
}

function SummaryCards({ s, from, to, team = false }: { s: WorkspaceSummary; from?: string; to?: string; team?: boolean }) {
  const cur = s.currency;
  return (
    <div className="space-y-4" data-testid="panel-summary">
      <p className="text-xs text-muted-foreground" data-testid="text-summary-basis">All money in {cur}; dates in {s.reportingTimeZone}. {from || to ? `Range ${from ?? "start"} to ${to ?? "latest"}, both days inclusive, applied to close, end or due date.` : "No date range applied."} {team && "Showing your own work only."}</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Stat id="delivery-count" label="Delivery projects" value={String(s.deliveryCount)} />
        <Stat id="delivery-risk" label="At risk or off track" value={String(s.deliveryRiskCount)} />
        <Stat id="goal-count" label="Goals" value={String(s.goalCount)} note={`${s.goalsMet} met`} />
        {s.openCount !== undefined && <Stat id="open-count" label="Open opportunities" value={String(s.openCount)} />}
        {s.openValue !== undefined && <Stat id="open-value" label="Open pipeline value" value={money(s.openValue, cur)} />}
        {s.weightedValue !== undefined && <Stat id="weighted" label="Probability-weighted value" value={money(s.weightedValue, cur)} />}
        {s.wonValue !== undefined && <Stat id="won" label="Won pipeline value" value={money(s.wonValue, cur)} note="Closed-won opportunity value. Not booked or recognized revenue." />}
        {s.lostValue !== undefined && <Stat id="lost" label="Lost pipeline value" value={money(s.lostValue, cur)} />}
        {s.deliveryBudget !== undefined && <Stat id="budget" label="Delivery budget" value={money(s.deliveryBudget, cur)} note="Planned budget, not revenue." />}
        {s.deliveryBurn !== undefined && <Stat id="burn" label="Delivery burn" value={money(s.deliveryBurn, cur)} />}
      </div>
    </div>
  );
}

export function PortfolioSummary({ from, to }: { from?: string; to?: string }) {
  const params = { ...(from ? { from } : {}), ...(to ? { to } : {}) };
  const q = useGetWorkspacePortfolioSummary(params, { query: { queryKey: getGetWorkspacePortfolioSummaryQueryKey(params), retry: false, refetchInterval: POLL, refetchIntervalInBackground: false } });
  if (q.isLoading) return <LoadingBlock rows={3} />;
  if (q.isError || !q.data) return <ErrorBlock message="Executive totals could not be loaded." onRetry={() => q.refetch()} />;
  return <section className="space-y-4" data-testid="panel-portfolio">
    <h2 className="font-display text-xl font-semibold">Across your {q.data.practiceCount} executive practices</h2>
    <p className="text-sm text-muted-foreground">Only practices with explicit Executive membership are included. Different currencies and reporting time zones remain separate.</p>
    {q.data.groups.map((group) => <div key={`${group.currency}:${group.reportingTimeZone}`} className="rounded-lg border p-4"><SummaryCards s={group} from={from} to={to} /></div>)}
  </section>;
}


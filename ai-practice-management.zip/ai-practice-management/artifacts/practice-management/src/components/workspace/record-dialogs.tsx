import { useState } from "react";
import { RefreshCw } from "lucide-react";
import {
  useCreateWorkspaceRecord, useUpdateWorkspaceRecord, useDeleteWorkspaceRecord, getWorkspaceRecord,
  type WorkspaceRecord, type WorkspaceRecordInput,
} from "@workspace/api-client-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { STAGES } from "@/poc/pipeline-import";
import { dec2, DEC } from "@/lib/workspace-money";
import { btn, btn2, inp, STATUSES, apiMessage, statusOf, ownerLabel, useInvalidate, type Ctx, type Kind, type Status } from "./shared";

/* ------------------------------------------------------------ record form */
export function RecordDialog({ c, kind, record, mode, onClose, onSaved }: { c: Ctx; kind: Kind; record?: WorkspaceRecord; mode: "full" | "status"; onClose: () => void; onSaved: () => void }) {
  const invalidate = useInvalidate(c.practice.id);
  const opts = { request: { headers: { "X-CSRF-Token": c.csrf } } };
  const create = useCreateWorkspaceRecord(opts);
  const update = useUpdateWorkspaceRecord(opts);
  const [version, setVersion] = useState(record?.version ?? 0);
  const [f, setF] = useState({
    name: record?.name ?? "", assignedUserId: record?.assignedUserId ?? (c.staff[0]?.userId ?? ""), dueDate: record?.dueDate ?? "",
    client: record?.client ?? "", stage: record?.stage ?? "Qualification", value: record?.value ?? "", probability: String(record?.probability ?? 50),
    status: (record?.status ?? "On track") as string, budget: record?.budget ?? "", burn: record?.burn ?? "",
    current: record?.current ?? "", target: record?.target ?? "", unit: record?.unit ?? "",
  });
  const [err, setErr] = useState<string | null>(null);
  const [conflict, setConflict] = useState(false);
  const [reloading, setReloading] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }));
  const pending = create.isPending || update.isPending;

  const build = (): WorkspaceRecordInput | string => {
    if (!f.name.trim()) return "Name is required.";
    if (!f.assignedUserId) return "Choose an assignee.";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(f.dueDate)) return "Choose a date.";
    const base = { kind, name: f.name.trim(), assignedUserId: f.assignedUserId, dueDate: f.dueDate };
    const bad = (v: string, l: string) => (DEC.test(v) ? null : `${l} must be a non-negative number with at most two decimals.`);
    if (kind === "pipeline") {
      const m = bad(f.value, "Value"); if (m) return m;
      const p = Number(f.probability);
      if (!Number.isInteger(p) || p < 0 || p > 100 || f.probability === "") return "Probability must be a whole number from 0 to 100.";
      if (!f.client.trim()) return "Client is required.";
      return { ...base, client: f.client.trim(), stage: f.stage as WorkspaceRecordInput["stage"], value: dec2(f.value), probability: p };
    }
    if (kind === "delivery") {
      const m = bad(f.budget, "Budget") ?? bad(f.burn, "Burn"); if (m) return m;
      if (!f.client.trim()) return "Client is required.";
      return { ...base, client: f.client.trim(), status: f.status as Status, budget: dec2(f.budget), burn: dec2(f.burn) };
    }
    const m = bad(f.current, "Current") ?? bad(f.target, "Target"); if (m) return m;
    if (!f.unit.trim()) return "Unit is required.";
    return { ...base, current: dec2(f.current), target: dec2(f.target), unit: f.unit.trim() };
  };

  const fail = (e: unknown) => {
    if (statusOf(e) === 409 && record) { setConflict(true); setErr("This record changed or duplicates another opportunity. Your draft is kept below; nothing was overwritten. Load the latest record before making changes."); }
    else setErr(apiMessage(e));
  };
  const done = () => { invalidate(); onSaved(); };

  const submit = () => {
    setErr(null); setConflict(false);
    if (mode === "status" && record) {
      update.mutate({ practiceId: c.practice.id, recordId: record.id, data: { version, status: f.status as Status } }, { onSuccess: done, onError: fail });
      return;
    }
    const input = build();
    if (typeof input === "string") { setErr(input); return; }
    if (record) update.mutate({ practiceId: c.practice.id, recordId: record.id, data: { version, record: input } }, { onSuccess: done, onError: fail });
    else create.mutate({ practiceId: c.practice.id, data: input }, { onSuccess: done, onError: fail });
  };

  const reload = async () => {
    if (!record) return;
    setReloading(true);
    try {
      const r = await getWorkspaceRecord(c.practice.id, record.id);
      setVersion(r.version);
      setF({
        name: r.name, assignedUserId: r.assignedUserId, dueDate: r.dueDate, client: r.client ?? "", stage: r.stage ?? "Qualification", value: r.value ?? "", probability: String(r.probability ?? 50),
        status: r.status ?? "On track", budget: r.budget ?? "", burn: r.burn ?? "", current: r.current ?? "", target: r.target ?? "", unit: r.unit ?? "",
      });
      setConflict(false); setErr(null); invalidate();
    } catch (e) { setErr(statusOf(e) === 404 ? "This record no longer exists." : apiMessage(e)); }
    setReloading(false);
  };

  const field = (label: string, k: keyof typeof f, type = "text", extra?: object) => (
    <label className="block text-sm font-medium">{label}
      <input data-testid={`input-${k}`} type={type} className={`${inp} mt-1`} value={f[k]} onChange={set(k)} {...extra} />
    </label>
  );
  const statusSel = (
    <label className="block text-sm font-medium">Status
      <select data-testid="select-status" className={`${inp} mt-1`} value={f.status} onChange={set("status")}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
    </label>
  );

  return (
    <Dialog open onOpenChange={(o) => { if (!o && !pending) onClose(); }}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto" data-testid="dialog-record">
        <DialogHeader>
          <DialogTitle className="font-display">{mode === "status" ? "Update status" : record ? `Edit ${kind}` : `New ${kind}`}</DialogTitle>
          <DialogDescription>{mode === "status" ? record?.name : "Saved to the shared practice record only when the server confirms."}</DialogDescription>
        </DialogHeader>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); submit(); }}>
          {mode === "status" ? statusSel : (
            <>
              {field("Name", "name", "text", { maxLength: 200 })}
              <label className="block text-sm font-medium">Assigned to
                <select data-testid="select-assignee" className={`${inp} mt-1`} value={f.assignedUserId} onChange={set("assignedUserId")}>
                  {!c.staff.some((s) => s.userId === f.assignedUserId) && f.assignedUserId && <option value={f.assignedUserId}>{ownerLabel(c, f.assignedUserId)}</option>}
                  {c.staff.map((s) => <option key={s.userId} value={s.userId}>{s.label}</option>)}
                </select>
              </label>
              {field(kind === "pipeline" ? "Expected close date" : kind === "delivery" ? "End date" : "Due date", "dueDate", "date")}
              {kind !== "goal" && field("Client", "client", "text", { maxLength: 200 })}
              {kind === "pipeline" && (
                <>
                  <label className="block text-sm font-medium">Stage
                    <select data-testid="select-stage" className={`${inp} mt-1`} value={f.stage} onChange={set("stage")}>{STAGES.map((s) => <option key={s}>{s}</option>)}</select>
                  </label>
                  {field(`Value (${c.practice.currency})`, "value", "text", { inputMode: "decimal" })}
                  {field("Probability (%)", "probability", "number", { min: 0, max: 100, step: 1 })}
                </>
              )}
              {kind === "delivery" && (
                <>
                  {statusSel}
                  {field(`Budget (${c.practice.currency})`, "budget", "text", { inputMode: "decimal" })}
                  {field(`Burn (${c.practice.currency})`, "burn", "text", { inputMode: "decimal" })}
                </>
              )}
              {kind === "goal" && (
                <>
                  {field("Current", "current", "text", { inputMode: "decimal" })}
                  {field("Target", "target", "text", { inputMode: "decimal" })}
                  {field("Unit", "unit", "text", { maxLength: 80 })}
                </>
              )}
            </>
          )}
          {err && <p role="alert" data-testid="text-form-error" className="text-sm font-medium text-destructive">{err}</p>}
          {conflict && <button type="button" onClick={reload} disabled={reloading} data-testid="button-reload-latest" className={btn2}><RefreshCw className="h-4 w-4" aria-hidden />{reloading ? "Loading..." : "Discard draft and load latest"}</button>}
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} disabled={pending} className={btn2} data-testid="button-cancel">Cancel</button>
            <button type="submit" disabled={pending || (conflict && true)} className={btn} data-testid="button-save">{pending ? "Saving..." : "Save"}</button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function DeleteDialog({ c, record, onClose }: { c: Ctx; record: WorkspaceRecord; onClose: () => void }) {
  const invalidate = useInvalidate(c.practice.id);
  const del = useDeleteWorkspaceRecord({ request: { headers: { "X-CSRF-Token": c.csrf } } });
  const [err, setErr] = useState<string | null>(null);
  const [stale, setStale] = useState(false);
  return (
    <Dialog open onOpenChange={(o) => { if (!o && !del.isPending) onClose(); }}>
      <DialogContent data-testid="dialog-delete">
        <DialogHeader>
          <DialogTitle className="font-display">Delete "{record.name}"?</DialogTitle>
          <DialogDescription>The record is removed from lists and totals. It is retained and audited by the system, not purged.</DialogDescription>
        </DialogHeader>
        {err && <p role="alert" className="text-sm font-medium text-destructive" data-testid="text-delete-error">{err}</p>}
        <div className="flex flex-wrap justify-end gap-2">
          {stale && <button className={btn2} data-testid="button-reload-after-conflict" onClick={() => { invalidate(); onClose(); }}>Reload latest</button>}
          <button className={btn2} onClick={onClose} disabled={del.isPending} data-testid="button-cancel-delete">Cancel</button>
          {!stale && (
            <button className={btn} disabled={del.isPending} data-testid="button-confirm-delete"
              onClick={() => del.mutate({ practiceId: c.practice.id, recordId: record.id, data: { version: record.version } }, {
                onSuccess: () => { invalidate(); onClose(); },
                onError: (e) => { if (statusOf(e) === 409) { setStale(true); setErr("This record changed since you loaded it. Reload the latest version before deciding again."); } else setErr(apiMessage(e)); },
              })}>{del.isPending ? "Deleting..." : "Delete record"}</button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}


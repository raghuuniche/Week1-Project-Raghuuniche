import { useState } from "react";
import { Plus, Pencil, Trash2, Upload } from "lucide-react";
import type { WorkspaceRecord } from "@workspace/api-client-react";
import { Panel, LoadingBlock, ErrorBlock, Pill } from "@/components/ui-kit";
import { money } from "@/lib/workspace-money";
import { btn, btn2, caps, KIND_LABEL, ownerLabel, useRecords, type Ctx, type Kind } from "./shared";
import { RecordDialog, DeleteDialog } from "./record-dialogs";
import { ImportDialog } from "./import-dialog";

/* ------------------------------------------------------------ list pages */
export function RecordsPage({ kind, c }: { kind: Kind; c: Ctx }) {
  const cp = caps(c.practice.role, kind);
  const q = useRecords(c.practice.id, kind, cp.read);
  const [editing, setEditing] = useState<{ r?: WorkspaceRecord; mode: "full" | "status" } | null>(null);
  const [deleting, setDeleting] = useState<WorkspaceRecord | null>(null);
  const [importing, setImporting] = useState(false);
  const cur = c.practice.currency;
  const dateLabel = kind === "pipeline" ? "Close" : kind === "delivery" ? "End" : "Due";

  if (!cp.read) return <Panel testId="panel-no-access"><p className="text-sm text-muted-foreground">Your role in this practice does not include {KIND_LABEL[kind].toLowerCase()} records.</p></Panel>;
  const failed = q.isError;
  const rows = failed ? [] : q.data ?? [];
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {!failed && cp.create && <button className={btn} onClick={() => setEditing({ mode: "full" })} data-testid="button-new-record"><Plus className="h-4 w-4" aria-hidden />New {kind}</button>}
        {!failed && cp.importing && <button className={btn2} onClick={() => setImporting(true)} data-testid="button-import"><Upload className="h-4 w-4" aria-hidden />Import file</button>}
        {!failed && !cp.create && !cp.statusOnly && <span className="text-sm text-muted-foreground" data-testid="text-read-only">Read-only for your role.</span>}
        {!failed && cp.statusOnly && <span className="text-sm text-muted-foreground">You see only your own work and can update its status.</span>}
        {q.isFetching && !q.isLoading && <span className="text-xs text-muted-foreground">Refreshing...</span>}
      </div>
      {q.isLoading && <LoadingBlock rows={4} />}
      {q.isError && <ErrorBlock message={`${KIND_LABEL[kind]} records could not be loaded.`} onRetry={() => q.refetch()} />}
      {!failed && q.data && rows.length === 0 && (
        <Panel testId="panel-empty-records"><p className="font-display text-lg font-semibold">No {KIND_LABEL[kind].toLowerCase()} records yet</p><p className="mt-1 text-sm text-muted-foreground">{cp.create ? "Create the first record or import a file." : "Nothing is assigned to you or shared with your role."}</p></Panel>
      )}
      {rows.length > 0 && (
        <div className="overflow-x-auto rounded-lg border border-card-border bg-card">
          <table className="w-full text-left text-sm" data-testid="table-records">
            <thead className="border-b border-card-border font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Name</th>
                {kind !== "goal" && c.practice.role !== "team_member" && <th className="px-4 py-3">Client</th>}
                {kind === "pipeline" && <><th className="px-4 py-3">Stage</th><th className="px-4 py-3 text-right">Value</th><th className="px-4 py-3 text-right">Prob.</th></>}
                {kind === "delivery" && <><th className="px-4 py-3">Status</th>{c.practice.role !== "team_member" && <><th className="px-4 py-3 text-right">Budget</th><th className="px-4 py-3 text-right">Burn</th></>}</>}
                {kind === "goal" && <th className="px-4 py-3">Progress</th>}
                <th className="px-4 py-3">Owner</th>
                <th className="px-4 py-3">{dateLabel}</th>
                <th className="px-4 py-3"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-card-border last:border-0" data-testid={`row-record-${r.id}`}>
                  <td className="px-4 py-3 font-medium">{r.name}</td>
                  {kind !== "goal" && c.practice.role !== "team_member" && <td className="px-4 py-3">{r.client ?? "-"}</td>}
                  {kind === "pipeline" && <><td className="px-4 py-3">{r.stage}</td><td className="px-4 py-3 text-right font-mono">{money(r.value, cur)}</td><td className="px-4 py-3 text-right font-mono">{r.probability}%</td></>}
                  {kind === "delivery" && <><td className="px-4 py-3"><Pill tone={r.status === "On track" || r.status === "Complete" ? "on" : r.status === "At risk" ? "warn" : "off"}>{r.status}</Pill></td>{c.practice.role !== "team_member" && <><td className="px-4 py-3 text-right font-mono">{money(r.budget, cur)}</td><td className="px-4 py-3 text-right font-mono">{money(r.burn, cur)}</td></>}</>}
                  {kind === "goal" && <td className="px-4 py-3 font-mono">{r.current} / {r.target} {r.unit}</td>}
                  <td className="px-4 py-3">{ownerLabel(c, r.assignedUserId)}</td>
                  <td className="px-4 py-3 font-mono">{r.dueDate}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1">
                      {cp.edit && <button aria-label={`Edit ${r.name}`} data-testid={`button-edit-${r.id}`} className={btn2} onClick={() => setEditing({ r, mode: "full" })}><Pencil className="h-4 w-4" aria-hidden /></button>}
                      {cp.statusOnly && r.assignedUserId === c.userId && <button data-testid={`button-status-${r.id}`} className={btn2} onClick={() => setEditing({ r, mode: "status" })}>Status</button>}
                      {cp.del && <button aria-label={`Delete ${r.name}`} data-testid={`button-delete-${r.id}`} className={btn2} onClick={() => setDeleting(r)}><Trash2 className="h-4 w-4" aria-hidden /></button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {!failed && editing && <RecordDialog c={c} kind={kind} record={editing.r} mode={editing.mode} onClose={() => setEditing(null)} onSaved={() => setEditing(null)} />}
      {!failed && deleting && <DeleteDialog c={c} record={deleting} onClose={() => setDeleting(null)} />}
      {!failed && importing && <ImportDialog c={c} existingRows={rows} onClose={() => setImporting(false)} />}
    </div>
  );
}


import { useState, type ReactNode } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetWorkspace, getGetWorkspaceQueryKey,
  useGetWorkspaceStaff, getGetWorkspaceStaffQueryKey,
  useGetWorkspaceRecords, getGetWorkspaceRecordsQueryKey,
  type WorkspacePractice, type WorkspaceStaff,
} from "@workspace/api-client-react";
import { useSession } from "@/lib/session";
import { PageHeader, Panel, LoadingBlock, ErrorBlock, Pill } from "@/components/ui-kit";

export type Kind = "pipeline" | "delivery" | "goal";
export type Status = "On track" | "At risk" | "Off track" | "Complete";
export const STATUSES: Status[] = ["On track", "At risk", "Off track", "Complete"];
export const KIND_LABEL: Record<Kind, string> = { pipeline: "Pipeline", delivery: "Delivery", goal: "Goals" };
export const POLL = 30_000;

export const btn = "inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60";
export const btn2 = "inline-flex items-center gap-2 rounded-md border border-card-border bg-card px-3 py-2 text-sm font-semibold disabled:opacity-60";
export const inp = "w-full rounded-md border border-card-border bg-background px-3 py-2 text-sm";

export function apiMessage(e: unknown): string {
  const d = (e as { data?: { error?: string } } | null)?.data;
  return d?.error ?? (e instanceof Error ? e.message : "Request failed.");
}
export const statusOf = (e: unknown) => (e as { status?: number } | null)?.status;

export type Caps = { create: boolean; edit: boolean; del: boolean; importing: boolean; statusOnly: boolean; read: boolean };
export function caps(role: string, kind: Kind): Caps {
  const none = { create: false, edit: false, del: false, importing: false, statusOnly: false, read: false };
  switch (role) {
    case "practice_director": return { create: true, edit: true, del: true, importing: kind === "pipeline", statusOnly: false, read: true };
    case "manager":
      if (kind === "pipeline") return { create: true, edit: true, del: true, importing: true, statusOnly: false, read: true };
      if (kind === "delivery") return { create: true, edit: true, del: false, importing: false, statusOnly: false, read: true };
      return { ...none, read: true };
    case "executive": return { ...none, read: true };
    case "team_member": return kind === "pipeline" ? none : { ...none, read: true, statusOnly: kind === "delivery" };
    default: return none;
  }
}
export const ROLE_LABEL: Record<string, string> = { executive: "Executive", practice_director: "Practice Director", manager: "Manager", team_member: "Team Member", administrator: "Administrator" };

export type Ctx = { practice: WorkspacePractice; userId: string; csrf: string; staff: WorkspaceStaff[]; isWriter: boolean };

/* ------------------------------------------------------------------ frame */
export function Frame({ eyebrow, title, intro, children, denyRoles, denyMessage }: { eyebrow: string; title: string; intro: string; children: (c: Ctx) => ReactNode; denyRoles?: string[]; denyMessage?: string }) {
  const { auth, authLoading } = useSession();
  const real = !!auth?.sessionActive && !auth.synthetic;
  const search = useSearch();
  const [loc, setLoc] = useLocation();
  const wq = useGetWorkspace({ query: { queryKey: getGetWorkspaceQueryKey(), enabled: real, retry: false, refetchInterval: 60_000, refetchIntervalInBackground: false } });
  const picked = new URLSearchParams(search).get("practice");
  const practices = wq.data?.practices ?? [];
  const practice = practices.find((p) => p.id === picked) ?? practices[0];
  const isWriter = !!practice && ["practice_director", "manager"].includes(practice.role);
  const staffQ = useGetWorkspaceStaff(practice?.id ?? "", { query: { queryKey: getGetWorkspaceStaffQueryKey(practice?.id ?? ""), enabled: real && isWriter, retry: false } });

  let body: ReactNode;
  if (authLoading) body = <LoadingBlock />;
  else if (!real) {
    body = (
      <Panel testId="panel-workspace-signin">
        <p className="text-sm text-muted-foreground">The shared workspace needs a verified sign-in. Demo sessions and signed-out visitors cannot open it; the synthetic role demo remains available separately.</p>
        <Link href="/" className="mt-3 inline-block text-sm font-semibold underline underline-offset-4" data-testid="link-workspace-home">Back to overview</Link>
      </Panel>
    );
  } else if (wq.isLoading) body = <LoadingBlock rows={4} />;
  else if (wq.isError) body = <ErrorBlock message={statusOf(wq.error) === 403 ? "Your account is not permitted to open the shared workspace." : "Workspace access could not be loaded."} onRetry={() => wq.refetch()} />;
  else if (!practice || !wq.data) {
    body = (
      <Panel testId="panel-workspace-empty">
        <h2 className="font-display text-xl font-semibold">No practice access yet</h2>
        <p className="mt-2 text-sm text-muted-foreground">Your verified account is not a member of any practice. Access is granted per practice by an administrator; nothing is shown until a membership exists.</p>
      </Panel>
    );
  } else if (practice.role === "administrator") {
    body = (
      <Panel testId="panel-workspace-admin">
        <p className="text-sm text-muted-foreground">The Administrator role carries no business-record access. Practice records are available to Executives, Directors, Managers and Team Members.</p>
      </Panel>
    );
  } else if (denyRoles?.includes(practice.role)) {
    body = <Panel testId="panel-role-denied"><p className="text-sm text-muted-foreground">{denyMessage ?? "Your role does not include this page."}</p></Panel>;
  } else if (isWriter && staffQ.isLoading) body = <LoadingBlock rows={4} />;
  else if (isWriter && staffQ.isError) body = <ErrorBlock message="Assignable staff could not be loaded." onRetry={() => staffQ.refetch()} />;
  else {
    body = <div key={`${practice.id}:${wq.data.userId}:${practice.role}`}>{children({ practice, userId: wq.data.userId, csrf: auth?.csrfToken ?? "", staff: staffQ.data ?? [], isWriter })}</div>;
  }

  return (
    <div>
      <PageHeader eyebrow={eyebrow} title={title}>{intro}</PageHeader>
      {real && practices.length > 0 && practice && (
        <div className="mb-6 flex flex-wrap items-end gap-4" data-testid="bar-practice">
          <label className="text-sm font-medium">Practice
            <select data-testid="select-practice" className={`${inp} mt-1 min-w-56`} value={practice.id} onChange={(e) => setLoc(`${loc}?practice=${e.target.value}`)}>
              {practices.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </label>
          <Pill tone="on">{ROLE_LABEL[practice.role] ?? practice.role}</Pill>
          <span className="text-xs text-muted-foreground" data-testid="text-practice-meta">Currency {practice.currency} - reporting time zone {practice.reportingTimeZone}</span>
        </div>
      )}
      <nav aria-label="Workspace sections" className="mb-6 flex flex-wrap gap-2">
        {[["", "Dashboard"], ["/pipeline", "Pipeline"], ["/delivery", "Delivery"], ["/goals", "Goals"], ["/reports", "Reports"]].map(([h, l]) => (
          <Link key={h} href={`/workspace${h}${practice ? `?practice=${practice.id}` : ""}`} data-testid={`link-ws-${l.toLowerCase()}`} className={btn2}>{l}</Link>
        ))}
      </nav>
      {body}
    </div>
  );
}

export function useInvalidate(practiceId: string) {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ predicate: (q) => typeof q.queryKey[0] === "string" && ((q.queryKey[0] as string).startsWith(`/api/workspace/practices/${practiceId}`) || q.queryKey[0] === "/api/workspace/summary") });
}

export function useRecords(practiceId: string, kind: Kind, enabled = true) {
  return useGetWorkspaceRecords(practiceId, { kind }, { query: { queryKey: getGetWorkspaceRecordsQueryKey(practiceId, { kind }), enabled, retry: false, refetchInterval: POLL, refetchIntervalInBackground: false } });
}

export function ownerLabel(c: Ctx, id: string) {
  if (id === c.userId) return "You";
  return c.staff.find((s) => s.userId === id)?.label ?? `Member ${id.slice(0, 8)}`;
}


import type { ReactNode } from "react";
import { Link } from "wouter";
import { ShieldOff, AlertTriangle, RefreshCw, CheckCircle2, MinusCircle } from "lucide-react";

export function PageHeader({ eyebrow, title, children }: { eyebrow: string; title: string; children?: ReactNode }) {
  return (
    <header className="mb-8 max-w-3xl">
      <p className="font-mono text-xs uppercase tracking-[0.18em] text-muted-foreground">{eyebrow}</p>
      <h1 className="font-display mt-2 text-3xl font-semibold sm:text-4xl" data-testid="text-page-title">{title}</h1>
      {children && <p className="mt-3 text-base leading-relaxed text-muted-foreground">{children}</p>}
    </header>
  );
}

export function Panel({ title, children, className = "", testId }: { title?: string; children: ReactNode; className?: string; testId?: string }) {
  return (
    <section data-testid={testId} className={`rounded-lg border border-card-border bg-card p-5 sm:p-6 ${className}`}>
      {title && <h2 className="font-display mb-4 text-xl font-semibold">{title}</h2>}
      {children}
    </section>
  );
}

export function Pill({ tone, children }: { tone: "on" | "off" | "warn"; children: ReactNode }) {
  const t = tone === "on" ? "bg-[hsl(172_40%_88%)] text-[hsl(172_50%_20%)]" : tone === "warn" ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground";
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${t}`}>{children}</span>;
}

export function FactRow({ label, value, on, testId }: { label: string; value: string; on?: boolean; testId?: string }) {
  const Icon = on ? CheckCircle2 : MinusCircle;
  return (
    <div className="flex items-start justify-between gap-4 border-b border-border py-3 last:border-0" data-testid={testId}>
      <div className="flex items-center gap-2 text-sm font-medium"><Icon className={`h-4 w-4 shrink-0 ${on ? "text-[hsl(172_40%_32%)]" : "text-muted-foreground"}`} aria-hidden />{label}</div>
      <span className="text-right text-sm text-muted-foreground">{value}</span>
    </div>
  );
}

export function LoadingBlock({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3" role="status" aria-label="Loading" data-testid="status-loading">
      {Array.from({ length: rows }).map((_, i) => <div key={i} className="h-10 animate-pulse rounded-md bg-muted" />)}
    </div>
  );
}

export function ErrorBlock({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div role="alert" className="rounded-lg border border-destructive/40 bg-destructive/5 p-5" data-testid="status-error">
      <div className="flex items-center gap-2 font-semibold text-destructive"><AlertTriangle className="h-4 w-4" aria-hidden />Something did not load</div>
      <p className="mt-1 text-sm text-muted-foreground">{message}</p>
      <button onClick={onRetry} data-testid="button-retry" className="mt-4 inline-flex items-center gap-2 rounded-md border border-input bg-card px-3 py-2 text-sm font-semibold hover:bg-muted">
        <RefreshCw className="h-4 w-4" aria-hidden />Try again
      </button>
    </div>
  );
}

export function NoAccess({ showLink = true }: { showLink?: boolean }) {
  return (
    <div role="alert" data-testid="status-no-access" className="rounded-lg border border-card-border border-l-4 border-l-[hsl(39_85%_50%)] bg-card p-5 sm:p-6">
      <div className="font-display flex items-center gap-2 text-xl font-semibold"><ShieldOff className="h-5 w-5" aria-hidden />No practice access</div>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        You are signed in, but signing in alone grants no practice access. Practice membership is granted separately. Contact an Administrator to be added to a practice.
      </p>
      {showLink && <Link href="/account" data-testid="link-account" className="mt-4 inline-block text-sm font-semibold underline underline-offset-4">View your account</Link>}
    </div>
  );
}

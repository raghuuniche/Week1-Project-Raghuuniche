import type { Goal, Opportunity, Practice, Project, Staff } from "./types";
import type { Role } from "./policy";
export const PRACTICES: Practice[] = [
  { id: "p1", name: "Cloud and Platform Modernization", short: "Cloud" },
  { id: "p2", name: "Data and Applied Analytics", short: "Data" },
];
export const STAFF: Staff[] = [
  { id: "s1", alias: "Director Lumen", practiceId: "p1" },
  { id: "s2", alias: "Director Quill", practiceId: "p2" },
  { id: "s3", alias: "Manager Cedar", practiceId: "p1" },
  { id: "s4", alias: "Consultant Orion", practiceId: "p1" },
  { id: "s5", alias: "Consultant Pike", practiceId: "p1" },
  { id: "s6", alias: "Manager Sable", practiceId: "p2" },
  { id: "s7", alias: "Consultant Vale", practiceId: "p2" },
  { id: "s8", alias: "Consultant Wren", practiceId: "p2" },
];
export const MANAGER_PRACTICE = "p1";
export const TEAM_MEMBER_ID = "s4";
export const staffAlias = (id: string) => STAFF.find((s) => s.id === id)?.alias ?? "Unassigned";
export const practiceShort = (id: string) => PRACTICES.find((p) => p.id === id)?.short ?? id;

const o = (id: string, practiceId: string, name: string, client: string, owner: string, stage: Opportunity["stage"], value: number, closeDate: string, probability: number): Opportunity => ({ id, practiceId, name, client, owner, stage, value, closeDate, probability });
export const SEED_OPPS: Opportunity[] = [
  o("o1", "p1", "Landing zone rebuild", "Harbor Mutual (synthetic)", "Director Lumen", "Proposal", 420000, "2025-09-30", 55),
  o("o2", "p1", "Legacy ERP hosting move", "Pellam Freight (synthetic)", "Manager Cedar", "Discovery", 265000, "2025-11-14", 30),
  o("o3", "p1", "Cost governance review", "Stonebridge Health (synthetic)", "Manager Cedar", "Negotiation", 138500, "2025-08-22", 75),
  o("o4", "p1", "Kubernetes platform pilot", "Calder Retail (synthetic)", "Director Lumen", "Won", 310000, "2025-06-10", 100),
  o("o5", "p1", "Disaster recovery assessment", "Marlow Credit Union (synthetic)", "Manager Cedar", "Qualification", 92000, "2025-12-05", 15),
  o("o6", "p1", "Identity platform migration", "Pellam Freight (synthetic)", "Director Lumen", "Lost", 184000, "2025-05-18", 0),
  o("o7", "p2", "Demand forecasting model", "Calder Retail (synthetic)", "Director Quill", "Proposal", 355000, "2025-10-03", 50),
  o("o8", "p2", "Claims data warehouse", "Harbor Mutual (synthetic)", "Manager Sable", "Negotiation", 512000, "2025-09-12", 70),
  o("o9", "p2", "Patient flow analytics", "Stonebridge Health (synthetic)", "Manager Sable", "Discovery", 201000, "2025-12-19", 25),
  o("o10", "p2", "Metrics layer standardization", "Marlow Credit Union (synthetic)", "Director Quill", "Won", 148000, "2025-07-01", 100),
  o("o11", "p2", "Document triage assistant", "Pellam Freight (synthetic)", "Director Quill", "Qualification", 120000, "2026-01-23", 10),
];
const p = (id: string, practiceId: string, name: string, client: string, assigneeId: string, status: Project["status"], budget: number, burn: number, endDate: string): Project => ({ id, practiceId, name, client, assigneeId, status, budget, burn, endDate });
export const SEED_PROJECTS: Project[] = [
  p("j1", "p1", "Kubernetes platform rollout", "Calder Retail (synthetic)", "s4", "On track", 310000, 46, "2025-10-31"),
  p("j2", "p1", "Cloud cost baseline", "Stonebridge Health (synthetic)", "s4", "At risk", 96000, 81, "2025-08-15"),
  p("j3", "p1", "Network segmentation design", "Harbor Mutual (synthetic)", "s5", "On track", 154000, 38, "2025-11-28"),
  p("j4", "p1", "Backup modernization", "Marlow Credit Union (synthetic)", "s3", "Complete", 77000, 97, "2025-06-30"),
  p("j5", "p2", "Metrics layer build", "Marlow Credit Union (synthetic)", "s7", "On track", 148000, 52, "2025-09-26"),
  p("j6", "p2", "Churn model refresh", "Calder Retail (synthetic)", "s8", "Off track", 119000, 108, "2025-08-01"),
  p("j7", "p2", "Reporting migration wave 2", "Harbor Mutual (synthetic)", "s6", "At risk", 205000, 74, "2025-10-17"),
];
const g = (id: string, practiceId: string, title: string, ownerId: string, current: number, target: number, unit: string, due: string): Goal => ({ id, practiceId, title, ownerId, current, target, unit, due });
export const SEED_GOALS: Goal[] = [
  g("g1", "p1", "Closed-won bookings", "s1", 310, 900, "$K", "2025-12-31"),
  g("g2", "p1", "Billable utilization", "s3", 71, 78, "%", "2025-12-31"),
  g("g3", "p1", "Certified platform engineers", "s4", 2, 4, "people", "2025-11-30"),
  g("g4", "p1", "Reusable accelerators published", "s4", 1, 3, "assets", "2025-12-15"),
  g("g5", "p2", "Closed-won bookings", "s2", 148, 750, "$K", "2025-12-31"),
  g("g6", "p2", "Billable utilization", "s6", 64, 75, "%", "2025-12-31"),
  g("g7", "p2", "Delivered projects rated 4+ by client", "s7", 3, 5, "projects", "2025-12-31"),
];
export type DemoState = { role: Role; practiceId: string; opps: Opportunity[]; projects: Project[]; goals: Goal[] };
export const seedState = (role: Role = "executive"): DemoState => ({ role, practiceId: "p1", opps: SEED_OPPS, projects: SEED_PROJECTS, goals: SEED_GOALS });

import type { Stage } from "./pipeline-import";
export type { Stage };
export type Practice = { id: string; name: string; short: string };
export type Staff = { id: string; alias: string; practiceId: string };
export type Opportunity = { id: string; practiceId: string; name: string; client: string; owner: string; stage: Stage; value: number; closeDate: string; probability: number };
export const PROJECT_STATUSES = ["On track", "At risk", "Off track", "Complete"] as const;
export type ProjectStatus = (typeof PROJECT_STATUSES)[number];
export type Project = { id: string; practiceId: string; name: string; client: string; assigneeId: string; status: ProjectStatus; budget: number; burn: number; endDate: string };
export type Goal = { id: string; practiceId: string; title: string; ownerId: string; current: number; target: number; unit: string; due: string };

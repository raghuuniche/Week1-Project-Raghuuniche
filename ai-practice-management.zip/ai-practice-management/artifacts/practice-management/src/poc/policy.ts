export const ROLES = ["executive", "practice_director", "manager", "team_member", "administrator"] as const;
export type Role = (typeof ROLES)[number];
export const ROLE_LABEL: Record<Role, string> = {
  executive: "Executive", practice_director: "Practice director", manager: "Manager", team_member: "Team member", administrator: "Administrator",
};
export type Area = "dashboard" | "pipeline" | "delivery" | "goals" | "reports" | "access";
export const AREAS: { area: Area; path: string; label: string }[] = [
  { area: "dashboard", path: "/poc", label: "Role dashboard" },
  { area: "pipeline", path: "/poc/pipeline", label: "Pipeline" },
  { area: "delivery", path: "/poc/delivery", label: "Delivery" },
  { area: "goals", path: "/poc/goals", label: "Goals" },
  { area: "reports", path: "/poc/reports", label: "Reports" },
  { area: "access", path: "/poc/access", label: "Role access" },
];
const VIEW: Record<Role, Area[]> = {
  executive: ["dashboard", "pipeline", "delivery", "goals", "reports", "access"],
  practice_director: ["dashboard", "pipeline", "delivery", "goals", "reports", "access"],
  manager: ["dashboard", "pipeline", "delivery", "goals", "reports", "access"],
  team_member: ["dashboard", "delivery", "goals", "access"],
  administrator: ["access"],
};
export const canView = (r: Role, a: Area) => VIEW[r].includes(a);
export const defaultPath = (r: Role) => (r === "administrator" ? "/poc/access" : "/poc");
export const pathArea = (p: string): Area | undefined => AREAS.find((a) => a.path === p)?.area;

export type Caps = { pipelineWrite: boolean; pipelineImport: boolean; deliveryWrite: boolean; deliveryOwnStatus: boolean; goalsWrite: boolean; allPractices: boolean; choosePractice: boolean; financials: boolean };
export function caps(r: Role): Caps {
  const dm = r === "practice_director" || r === "manager";
  return {
    pipelineWrite: dm, pipelineImport: dm, deliveryWrite: dm, deliveryOwnStatus: r === "team_member",
    goalsWrite: r === "practice_director", allPractices: r === "executive", choosePractice: r === "practice_director",
    financials: r === "executive" || dm,
  };
}
export const MATRIX: { label: string; test: (r: Role) => boolean | string }[] = [
  { label: "Role dashboard", test: (r) => canView(r, "dashboard") },
  { label: "View pipeline (financial)", test: (r) => canView(r, "pipeline") },
  { label: "Create, edit, delete, import opportunities", test: (r) => caps(r).pipelineWrite },
  { label: "View delivery", test: (r) => (r === "team_member" ? "Own only" : canView(r, "delivery")) },
  { label: "Create and edit projects", test: (r) => caps(r).deliveryWrite },
  { label: "Update delivery status", test: (r) => (r === "team_member" ? "Own only" : caps(r).deliveryWrite) },
  { label: "View goals", test: (r) => (r === "team_member" ? "Own only" : canView(r, "goals")) },
  { label: "Create and edit goals", test: (r) => caps(r).goalsWrite },
  { label: "Aggregate reports", test: (r) => canView(r, "reports") },
  { label: "Both practices", test: (r) => caps(r).allPractices },
  { label: "Practice data of any kind", test: (r) => r !== "administrator" },
  { label: "Grants and user management", test: () => false },
];

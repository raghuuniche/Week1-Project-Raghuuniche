import { useMemo, useState } from "react";
import { Download, Pencil, Plus, Search, Trash2, Upload } from "lucide-react";
import { PocPage } from "./page";
import { usePoc, useVisible } from "./store";
import { caps } from "./policy";
import { practiceShort } from "./seed";
import { STAGES, PIPELINE_TEMPLATE } from "./pipeline-import";
import type { Opportunity } from "./types";
import { Confirm, Empty, StageBadge, Table, btn, btnGhost, inputCls, money, td, th } from "./ui";
import { OppDialog } from "./opp-dialog";
import { ImportDialog } from "./import-dialog";

function downloadTemplate() {
  const url = URL.createObjectURL(new Blob([PIPELINE_TEMPLATE], { type: "text/csv;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url; a.download = "northstar-pipeline-template.csv";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function Body() {
  const { state, upsertOpp, deleteOpp, addOpps } = usePoc();
  const v = useVisible();
  const c = caps(state.role);
  const [q, setQ] = useState("");
  const [stage, setStage] = useState("all");
  const [prac, setPrac] = useState("all");
  const [edit, setEdit] = useState<Opportunity | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [del, setDel] = useState<Opportunity | null>(null);
  const [imp, setImp] = useState(false);
  const wp = v.writePractice;
  const writeList = useMemo(() => v.opps.filter((o) => o.practiceId === wp), [v.opps, wp]);
  const rows = useMemo(() => {
    const t = q.trim().toLowerCase();
    return v.opps.filter((o) => (stage === "all" || o.stage === stage) && (prac === "all" || o.practiceId === prac) && (!t || `${o.name} ${o.client} ${o.owner}`.toLowerCase().includes(t)));
  }, [v.opps, q, stage, prac]);
  const total = rows.reduce((s, o) => s + o.value, 0);
  const canEdit = c.pipelineWrite && !!wp;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-2">
        <div className="relative min-w-[200px] flex-1"><Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" aria-hidden />
          <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, client or owner" aria-label="Search pipeline" data-testid="input-search-pipeline" className={`${inputCls} pl-9`} /></div>
        <select value={stage} onChange={(e) => setStage(e.target.value)} aria-label="Filter by stage" data-testid="select-filter-stage" className={`${inputCls} !w-auto`}>
          <option value="all">All stages</option>{STAGES.map((s) => <option key={s} value={s}>{s}</option>)}</select>
        {v.practices.length > 1 && <select value={prac} onChange={(e) => setPrac(e.target.value)} aria-label="Filter by practice" data-testid="select-filter-practice" className={`${inputCls} !w-auto`}>
          <option value="all">Both practices</option>{v.practices.map((p) => <option key={p.id} value={p.id}>{p.short}</option>)}</select>}
        {canEdit && <>
          <button className={btn} onClick={() => { setEdit(null); setFormOpen(true); }} data-testid="button-new-opportunity"><Plus className="h-4 w-4" aria-hidden />New</button>
          <button className={btnGhost} onClick={() => setImp(true)} data-testid="button-import-pipeline"><Upload className="h-4 w-4" aria-hidden />Import</button>
          <button className={btnGhost} onClick={downloadTemplate} data-testid="button-download-template"><Download className="h-4 w-4" aria-hidden />Template CSV</button>
        </>}
      </div>
      {!c.pipelineWrite && <p className="text-sm text-muted-foreground" data-testid="text-readonly">Read only for this preview role. Entry and import are not available.</p>}
      <p className="text-sm text-muted-foreground" data-testid="text-pipeline-count">{rows.length} opportunities, {money(total)} total value</p>
      {rows.length === 0 ? (
        <Empty testId="empty-pipeline" title={v.opps.length === 0 ? "No opportunities yet" : "No opportunities match"}>{v.opps.length === 0 ? "Add an opportunity or import a CSV or XLSX file to start the pipeline." : "Clear the search or filters to see everything in view."}</Empty>
      ) : (
        <Table testId="table-pipeline">
          <thead><tr>
            <th className={th}>Opportunity</th><th className={th}>Client</th>{v.practices.length > 1 && <th className={th}>Practice</th>}<th className={th}>Owner</th><th className={th}>Stage</th><th className={`${th} text-right`}>Value</th><th className={`${th} text-right`}>Prob.</th><th className={th}>Close</th>{canEdit && <th className={th}><span className="sr-only">Actions</span></th>}
          </tr></thead>
          <tbody>{rows.map((o) => (
            <tr key={o.id} className="border-t border-border transition-colors hover:bg-muted/50" data-testid={`row-opportunity-${o.id}`}>
              <td className={`${td} font-medium`}>{o.name}</td><td className={td}>{o.client}</td>{v.practices.length > 1 && <td className={td}>{practiceShort(o.practiceId)}</td>}<td className={td}>{o.owner}</td>
              <td className={td}><StageBadge stage={o.stage} /></td><td className={`${td} text-right tabular-nums`}>{money(o.value)}</td><td className={`${td} text-right tabular-nums`}>{o.probability}%</td><td className={`${td} tabular-nums`}>{o.closeDate}</td>
              {canEdit && <td className={`${td} whitespace-nowrap text-right`}>
                <button className={btnGhost} onClick={() => { setEdit(o); setFormOpen(true); }} aria-label={`Edit ${o.name}`} data-testid={`button-edit-opportunity-${o.id}`}><Pencil className="h-3.5 w-3.5" aria-hidden /></button>{" "}
                <button className={btnGhost} onClick={() => setDel(o)} aria-label={`Delete ${o.name}`} data-testid={`button-delete-opportunity-${o.id}`}><Trash2 className="h-3.5 w-3.5" aria-hidden /></button></td>}
            </tr>))}</tbody>
        </Table>
      )}
      {canEdit && wp && <>
        <OppDialog open={formOpen} onOpenChange={setFormOpen} initial={edit} existing={writeList} onSave={(val, id) => upsertOpp({ ...val, id, practiceId: wp })} />
        <ImportDialog open={imp} onOpenChange={setImp} practiceName={practiceShort(wp)} existing={writeList} onCommit={(r) => addOpps(r.map((x) => ({ ...x, practiceId: wp })))} />
        <Confirm open={!!del} onOpenChange={(o) => !o && setDel(null)} testId="dialog-delete-opportunity" title="Delete opportunity?" body={`${del?.name ?? ""} will be removed from this demo session. This cannot be undone except by resetting demo data.`} confirmLabel="Delete" onConfirm={() => { if (del) deleteOpp(del.id); setDel(null); }} />
      </>}
    </div>
  );
}

export default function PocPipeline() {
  return <PocPage area="pipeline" eyebrow="Role demo - pipeline" title="Opportunities across the funnel." intro="Search, filter and, where your preview role allows, manage synthetic opportunities."><Body /></PocPage>;
}

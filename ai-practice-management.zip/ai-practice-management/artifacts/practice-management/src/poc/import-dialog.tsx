import { useMemo, useRef, useState } from "react";
import { Upload } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { parsePipelineFile, type ImportOpportunity } from "./pipeline-import";
import type { Opportunity } from "./types";
import { dupKey } from "./store";
import { StageBadge, Table, btn, btnGhost, money, td, th } from "./ui";

const MAX_BYTES = 5 * 1024 * 1024;

export function ImportDialog({ open, onOpenChange, practiceName, existing, onCommit }: { open: boolean; onOpenChange: (o: boolean) => void; practiceName: string; existing: Opportunity[]; onCommit: (rows: ImportOpportunity[]) => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<ImportOpportunity[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [parsed, setParsed] = useState(false);
  const [ack, setAck] = useState(false);
  const readVersion = useRef(0);

  const { fresh, skipped } = useMemo(() => {
    const seen = new Set(existing.map((o) => dupKey(o.name, o.client)));
    const f: ImportOpportunity[] = [];
    let s = 0;
    for (const r of rows) { const k = dupKey(r.name, r.client); if (seen.has(k)) s++; else { seen.add(k); f.push(r); } }
    return { fresh: f, skipped: s };
  }, [rows, existing]);

  const close = (o: boolean) => { if (!o) { readVersion.current++; setBusy(false); setFile(null); setRows([]); setErrors([]); setParsed(false); setAck(false); } onOpenChange(o); };
  const pick = async (f: File | null) => {
    const version = ++readVersion.current;
    setFile(f); setRows([]); setErrors([]); setParsed(false); setBusy(false);
    if (!f) return;
    if (f.size > MAX_BYTES) { setErrors(["File is larger than 5 MB."]); setParsed(true); return; }
    setBusy(true);
    try { const r = await parsePipelineFile(f); if (version !== readVersion.current) return; setRows(r.rows); setErrors(r.errors); }
    catch { if (version !== readVersion.current) return; setErrors(["The file could not be read. Use the template CSV or an .xlsx file."]); }
    setBusy(false); setParsed(true);
  };
  const blocked = errors.length > 0 || !parsed || busy || !ack || fresh.length === 0;
  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent className="max-h-[90dvh] max-w-3xl overflow-y-auto" data-testid="dialog-import">
        <DialogHeader><DialogTitle>Import opportunities</DialogTitle><DialogDescription>Rows are added to {practiceName}. The file cannot choose a practice. CSV or XLSX, up to 5 MB and 1000 rows.</DialogDescription></DialogHeader>
        <label className="flex cursor-pointer items-center gap-3 rounded-md border border-dashed border-input bg-muted/40 px-4 py-4 text-sm">
          <Upload className="h-4 w-4" aria-hidden />
          <span>{file ? file.name : "Choose a .csv or .xlsx file"}</span>
          <input type="file" accept=".csv,.xlsx" className="sr-only" data-testid="input-pipeline-file" onChange={(e) => { void pick(e.target.files?.[0] ?? null); e.target.value = ""; }} />
        </label>
        {busy && <p className="text-sm text-muted-foreground" data-testid="status-import-parsing">Reading file...</p>}
        {parsed && (
          <div className="space-y-3" data-testid="import-review">
            <p className="text-sm" data-testid="text-import-summary">{rows.length} valid row(s) read; {fresh.length} new; <strong data-testid="text-import-skipped">{skipped}</strong> duplicate(s) skipped (same name and client, any case).</p>
            {errors.length > 0 && (
              <div role="alert" className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive" data-testid="list-import-errors">
                <p className="font-semibold">{errors.length} error(s). Nothing can be imported until the file is fixed.</p>
                <ul className="mt-1 max-h-32 list-disc space-y-0.5 overflow-y-auto pl-5">{errors.map((e, i) => <li key={i}>{e}</li>)}</ul>
              </div>
            )}
            {errors.length === 0 && fresh.length > 0 && (
              <div className="max-h-56 overflow-y-auto">
                <Table testId="table-import-preview">
                  <thead><tr><th className={th}>Name</th><th className={th}>Client</th><th className={th}>Stage</th><th className={`${th} text-right`}>Value</th></tr></thead>
                  <tbody>{fresh.slice(0, 50).map((r, i) => <tr key={i} className="border-t border-border" data-testid={`row-import-${i}`}><td className={td}>{r.name}</td><td className={td}>{r.client}</td><td className={td}><StageBadge stage={r.stage} /></td><td className={`${td} text-right tabular-nums`}>{money(r.value)}</td></tr>)}</tbody>
                </Table>
                {fresh.length > 50 && <p className="mt-1 text-xs text-muted-foreground">Showing first 50 of {fresh.length}.</p>}
              </div>
            )}
          </div>
        )}
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} data-testid="checkbox-import-synthetic" className="mt-1" />I confirm this file contains synthetic data only, with no real client or personal information.</label>
        <div className="flex flex-wrap gap-2">
          <button className={btn} disabled={blocked} data-testid="button-commit-import" onClick={() => { onCommit(fresh); close(false); }}>Import {fresh.length} opportunity(ies)</button>
          <button className={btnGhost} onClick={() => close(false)} data-testid="button-cancel-import">Cancel</button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

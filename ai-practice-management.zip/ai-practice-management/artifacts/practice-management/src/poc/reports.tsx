import { useMemo, useState } from "react";
import { PocPage } from "./page";
import { useVisible } from "./store";
import { STAGES } from "./pipeline-import";
import { PROJECT_STATUSES } from "./types";
import { pipelineTotals } from "./metrics";
import { Empty, Stat, StageBadge, Table, inputCls, money, td, th, STATUS_CLS } from "./ui";

function Body() {
  const v = useVisible();
  const [prac, setPrac] = useState("all");
  const [stage, setStage] = useState("all");
  const opps = useMemo(() => v.opps.filter((o) => (prac === "all" || o.practiceId === prac) && (stage === "all" || o.stage === stage)), [v.opps, prac, stage]);
  const projects = useMemo(() => v.projects.filter((p) => prac === "all" || p.practiceId === prac), [v.projects, prac]);
  const t = pipelineTotals(opps);
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2">
        {v.practices.length > 1 && <select value={prac} onChange={(e) => setPrac(e.target.value)} aria-label="Practice filter" data-testid="select-report-practice" className={`${inputCls} !w-auto`}><option value="all">Both practices</option>{v.practices.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>}
        <select value={stage} onChange={(e) => setStage(e.target.value)} aria-label="Stage filter" data-testid="select-report-stage" className={`${inputCls} !w-auto`}><option value="all">All stages</option>{STAGES.map((s) => <option key={s}>{s}</option>)}</select>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat testId="report-total-count" label="Opportunities" value={String(opps.length)} />
        <Stat testId="report-open-value" label="Open value" value={money(t.openValue)} />
        <Stat testId="report-weighted" label="Weighted open" value={money(t.weighted)} />
        <Stat testId="report-won" label="Won / lost" value={`${money(t.wonValue)} / ${money(t.lostValue)}`} />
      </div>
      {opps.length === 0 ? <Empty testId="empty-report" title="Nothing matches these filters">Change the practice or stage filter.</Empty> : (
        <Table testId="table-report-stage">
          <thead><tr><th className={th}>Stage</th><th className={`${th} text-right`}>Count</th><th className={`${th} text-right`}>Total value</th><th className={`${th} text-right`}>Weighted</th></tr></thead>
          <tbody>{STAGES.map((s) => { const r = opps.filter((o) => o.stage === s); return (
            <tr key={s} className="border-t border-border" data-testid={`row-report-stage-${s.toLowerCase()}`}><td className={td}><StageBadge stage={s} /></td><td className={`${td} text-right tabular-nums`}>{r.length}</td><td className={`${td} text-right tabular-nums`}>{money(r.reduce((a, o) => a + o.value, 0))}</td><td className={`${td} text-right tabular-nums`}>{money(Math.round(r.reduce((a, o) => a + (o.value * o.probability) / 100, 0)))}</td></tr>); })}
            <tr className="border-t-2 border-border bg-muted/50 font-semibold" data-testid="row-report-total"><td className={td}>Total</td><td className={`${td} text-right tabular-nums`}>{opps.length}</td><td className={`${td} text-right tabular-nums`}>{money(opps.reduce((a, o) => a + o.value, 0))}</td><td className={`${td} text-right tabular-nums`}>{money(Math.round(opps.reduce((a, o) => a + (o.value * o.probability) / 100, 0)))}</td></tr></tbody>
        </Table>
      )}
      <Table testId="table-report-delivery">
        <thead><tr><th className={th}>Delivery status</th><th className={`${th} text-right`}>Projects</th><th className={`${th} text-right`}>Budget</th></tr></thead>
        <tbody>{PROJECT_STATUSES.map((s) => { const r = projects.filter((p) => p.status === s); return (
          <tr key={s} className="border-t border-border" data-testid={`row-report-status-${s.toLowerCase().replace(" ", "-")}`}><td className={td}><span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${STATUS_CLS[s]}`}>{s}</span></td><td className={`${td} text-right tabular-nums`}>{r.length}</td><td className={`${td} text-right tabular-nums`}>{money(r.reduce((a, p) => a + p.budget, 0))}</td></tr>); })}</tbody>
      </Table>
    </div>
  );
}

export default function PocReports() {
  return <PocPage area="reports" eyebrow="Role demo - reports" title="Totals recomputed from what you can see." intro="Aggregate tables follow your preview role and the filters below."><Body /></PocPage>;
}

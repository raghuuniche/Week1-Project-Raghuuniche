import type { ReactNode } from "react";
import type { usePocOptional as demoOptional } from "./store";

// Production shell compatibility only. No demo seeds, storage or role state.
export function PocBoundary({ children }: { children: ReactNode }) { return children; }
export function usePocActive() { return false; }
export function usePocOptional(): ReturnType<typeof demoOptional> { return null; }

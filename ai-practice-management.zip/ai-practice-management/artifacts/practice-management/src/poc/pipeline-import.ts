import Papa from "papaparse";
import { readSheet } from "read-excel-file/browser";

export const STAGES = ["Qualification", "Discovery", "Proposal", "Negotiation", "Won", "Lost"] as const;
export type Stage = (typeof STAGES)[number];
export type ImportOpportunity = {
  name: string;
  client: string;
  owner: string;
  stage: Stage;
  value: number;
  /** Exact source text when it is a plain amount (<=14 integer digits, <=2 decimals); production import only. */
  valueDecimal?: string;
  closeDate: string;
  probability: number;
};
export type PipelineImportResult = { rows: ImportOpportunity[]; errors: string[] };
const HEADERS = ["name", "client", "owner", "stage", "value", "closeDate", "probability"] as const;
const MAX_ROWS = 1000;
const MAX_BYTES = 5 * 1024 * 1024;
export const PIPELINE_TEMPLATE =
  "name,client,owner,stage,value,closeDate,probability\r\n" +
  "Demo cloud assessment,Example client,Demo director,Discovery,25000,2026-12-15,40\r\n";

function validDate(value: unknown): string | null {
  if (value instanceof Date) {
    return Number.isFinite(value.getTime()) ? value.toISOString().slice(0, 10) : null;
  }
  const text = String(value ?? "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return null;
  const parsed = new Date(`${text}T00:00:00Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === text ? text : null;
}

function numberCell(value: unknown): number | null {
  if (typeof value !== "number" && typeof value !== "string") return null;
  const text = String(value).trim();
  if (!text || !/^\d+(?:\.\d+)?$/.test(text)) return null;
  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed : null;
}

/** Validate the whole sheet before any browser demo records can be changed. */
export function validatePipelineRows(sheet: unknown[][]): PipelineImportResult {
  const rows: ImportOpportunity[] = [];
  const errors: string[] = [];
  if (!sheet.length) return { rows, errors: ["The file is empty. Use the downloadable template."] };
  const header = sheet[0].map((cell) => String(cell ?? "").replace(/^\uFEFF/, "").trim().toLowerCase());
  const duplicates = header.filter((name, i) => name && header.indexOf(name) !== i);
  if (duplicates.length) errors.push(`Duplicate columns: ${[...new Set(duplicates)].join(", ")}.`);
  const missing = HEADERS.filter((name) => !header.includes(name.toLowerCase()));
  if (missing.length) errors.push(`Missing columns: ${missing.join(", ")}.`);
  // Imported files cannot choose their access scope.
  const unknown = header.filter((name) => name && !HEADERS.some((known) => known.toLowerCase() === name));
  if (unknown.length) errors.push(`Unsupported columns: ${unknown.join(", ")}. Use the template columns only.`);
  if (errors.length) return { rows, errors };
  const index = Object.fromEntries(HEADERS.map((name) => [name, header.indexOf(name.toLowerCase())])) as Record<(typeof HEADERS)[number], number>;
  const data = sheet.slice(1).map((cells, i) => ({ cells, line: i + 2 }))
    .filter(({ cells }) => cells.some((cell) => String(cell ?? "").trim() !== ""));
  if (!data.length) return { rows, errors: ["No pipeline entries found below the header."] };
  if (data.length > MAX_ROWS) return { rows, errors: [`Import at most ${MAX_ROWS} entries at a time.`] };

  for (const { cells, line } of data) {
    const field = (key: (typeof HEADERS)[number]) => cells[index[key]];
    const name = String(field("name") ?? "").trim();
    const client = String(field("client") ?? "").trim();
    const owner = String(field("owner") ?? "").trim();
    const stageText = String(field("stage") ?? "").trim();
    const stage = STAGES.find((item) => item.toLowerCase() === stageText.toLowerCase());
    const value = numberCell(field("value"));
    const probability = numberCell(field("probability"));
    const closeDate = validDate(field("closeDate"));
    const issues: string[] = [];
    if (!name || !client || !owner) issues.push("name, client and owner are required");
    if ([name, client, owner].some((text) => text.length > 200)) issues.push("text fields must be at most 200 characters");
    if (!stage) issues.push(`stage must be one of ${STAGES.join(", ")}`);
    if (value === null || value > 1_000_000_000) issues.push("value must be a number between 0 and 1000000000 (no currency symbol)");
    if (probability === null || probability > 100) issues.push("probability must be a number between 0 and 100");
    if (!closeDate) issues.push("closeDate must be a valid YYYY-MM-DD date");
    if (cells.length > header.length && cells.slice(header.length).some((cell) => String(cell ?? "").trim())) issues.push("too many columns");
    if (issues.length) {
      errors.push(`Row ${line}: ${issues.join("; ")}.`);
    } else {
      const rawValue = String(field("value") ?? "").trim();
      const valueDecimal = /^\d{1,14}(\.\d{1,2})?$/.test(rawValue) ? rawValue : undefined;
      rows.push({ name, client, owner, stage: stage!, value: value!, valueDecimal, closeDate: closeDate!, probability: probability! });
    }
  }
  return { rows, errors };
}

export async function parsePipelineFile(file: File): Promise<PipelineImportResult> {
  if (file.size > MAX_BYTES) return { rows: [], errors: ["The file exceeds the 5 MB limit."] };
  if (file.size === 0) return { rows: [], errors: ["The file is empty."] };
  const extension = file.name.split(".").pop()?.toLowerCase();
  if (extension !== "csv" && extension !== "xlsx") return { rows: [], errors: ["Choose a .csv or .xlsx file. Legacy .xls files must be saved as .xlsx first."] };
  try {
    if (extension === "xlsx") {
      const sheet = await readSheet(file, 1);
      return validatePipelineRows(sheet);
    }
    const parsed = Papa.parse<string[]>(await file.text(), { skipEmptyLines: "greedy" });
    if (parsed.errors.length) return { rows: [], errors: parsed.errors.map((error) => `CSV could not be read: ${error.message}`) };
    return validatePipelineRows(parsed.data);
  } catch {
    return { rows: [], errors: ["Could not read the file. Check that it is a valid, unencrypted CSV or Excel workbook."] };
  }
}

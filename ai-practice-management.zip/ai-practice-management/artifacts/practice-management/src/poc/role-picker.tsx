import { Eye } from "lucide-react";
import { usePocOptional } from "./store";
import { ROLES, ROLE_LABEL, type Role } from "./policy";

export function RolePicker() {
  const poc = usePocOptional();
  if (!poc) return null;
  return (
    <label className="flex items-center gap-2 text-sm font-semibold" data-testid="picker-role">
      <Eye className="h-4 w-4" aria-hidden />
      <span>Preview role</span>
      <select value={poc.state.role} onChange={(e) => poc.setRole(e.target.value as Role)} data-testid="select-preview-role" aria-label="Preview role (presentation only, not an access grant)"
        className="rounded-md border border-[hsl(39_70%_60%)] bg-card px-2 py-1 text-sm font-medium text-foreground">
        {ROLES.map((r) => <option key={r} value={r}>{r} - {ROLE_LABEL[r]}</option>)}
      </select>
    </label>
  );
}

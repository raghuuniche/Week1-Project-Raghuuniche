import { Link } from "wouter";
import { PocPage } from "./page";
import { usePoc, useVisible } from "./store";
import { AREAS, ROLE_LABEL, canView, caps } from "./policy";
import { pipelineTotals, projectCounts } from "./metrics";
import { Empty, ProgressBar, Stat, money } from "./ui";

const FOCUS: Record<string, string> = {
  executive: "Read both practices side by side. Entry and import are off for this role.",
  practice_director: "Run one selected practice: goals, delivery and pipeline.",
  manager: "Run delivery and pipeline for your assigned practice. Goals are read only.",
  team_member: "Your own projects and goals. Update status on the work you own.",
  administrator: "Access simulation only. No practice data is shown to this role.",
};

function Body() {
  const { state } = usePoc();
  const v = useVisible();
  const c = caps(state.role);
  const pt = pipelineTotals(v.opps);
  const pc = projectCounts(v.projects);
  const goalPct = v.goals.length ? Math.round(v.goals.reduce((s, g) => s + Math.min(1, g.current / g.target), 0) / v.goals.length * 100) : 0;
  const links = AREAS.filter((a) => a.area !== "dashboard" && canView(state.role, a.area));
  return (
    <div className="space-y-6">
      <p className="text-sm font-medium" data-testid="text-role-focus">{ROLE_LABEL[state.role]}: {FOCUS[state.role]}</p>
      {v.practices.length === 0 ? <Empty testId="empty-dashboard" title="No practice data for this preview role">Choose another preview role from the top right to see practice data.</Empty> : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {c.financials && <Stat testId="stat-open-pipeline" label="Open pipeline" value={money(pt.openValue)} hint={`${pt.openCount} opportunities`} />}
            {c.financials && <Stat testId="stat-weighted" label="Weighted pipeline" value={money(pt.weighted)} hint="value x probability" />}
            {c.financials && <Stat testId="stat-won" label="Closed won" value={money(pt.wonValue)} />}
            <Stat testId="stat-projects" label={state.role === "team_member" ? "My projects" : "Projects"} value={String(pc.total)} hint={`${pc.atRisk} at risk or off track`} />
            <Stat testId="stat-goal-progress" label="Goal progress" value={`${goalPct}%`} hint={`${v.goals.length} goals`} />
          </div>
          {v.practices.length > 1 && (
            <div className="grid gap-3 md:grid-cols-2" data-testid="panel-practice-compare">
              {v.practices.map((p) => {
                const t = pipelineTotals(v.opps.filter((o) => o.practiceId === p.id));
                const pr = projectCounts(v.projects.filter((x) => x.practiceId === p.id));
                return (
                  <div key={p.id} className="rounded-lg border border-card-border border-t-4 border-t-primary bg-card p-4" data-testid={`card-practice-${p.id}`}>
                    <h3 className="font-display text-lg font-semibold">{p.name}</h3>
                    <dl className="mt-3 grid grid-cols-2 gap-y-2 text-sm"><dt className="text-muted-foreground">Open pipeline</dt><dd className="text-right tabular-nums">{money(t.openValue)}</dd><dt className="text-muted-foreground">Closed won</dt><dd className="text-right tabular-nums">{money(t.wonValue)}</dd><dt className="text-muted-foreground">Projects at risk</dt><dd className="text-right tabular-nums">{pr.atRisk} of {pr.total}</dd></dl>
                  </div>
                );
              })}
            </div>
          )}
          {v.goals.length > 0 && (
            <div className="rounded-lg border border-card-border bg-card p-4"><h3 className="font-display text-lg font-semibold">Goals in view</h3>
              <ul className="mt-3 space-y-3">{v.goals.slice(0, 5).map((g) => <li key={g.id} className="text-sm" data-testid={`dash-goal-${g.id}`}><div className="mb-1 flex justify-between gap-2"><span>{g.title}</span><span className="tabular-nums text-muted-foreground">{Math.round((g.current / g.target) * 100)}%</span></div><ProgressBar pct={(g.current / g.target) * 100} tone="bg-[hsl(172_40%_32%)]" /></li>)}</ul></div>
          )}
        </>
      )}
      <div className="flex flex-wrap gap-2">{links.map((l) => <Link key={l.path} href={l.path} data-testid={`link-dash-${l.area}`} className="rounded-md border border-input bg-card px-3 py-2 text-sm font-semibold transition-colors hover:bg-muted">{l.label}</Link>)}</div>
    </div>
  );
}

export default function PocDashboard() {
  return <PocPage area="dashboard" eyebrow="Role demo" title="Your daily workspace." intro="A focused view for the preview role you picked at the top right."><Body /></PocPage>;
}

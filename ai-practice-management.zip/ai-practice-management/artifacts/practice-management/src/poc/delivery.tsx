import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form } from "@/components/ui/form";
import { PocPage } from "./page";
import { usePoc, useVisible } from "./store";
import { caps } from "./policy";
import { STAFF, practiceShort, staffAlias } from "./seed";
import { PROJECT_STATUSES, type Project, type ProjectStatus } from "./types";
import { Confirm, Empty, Field, ProgressBar, STATUS_CLS, Table, btn, btnGhost, dateStr, inputCls, money, numStr, td, th } from "./ui";

const schema = z.object({
  name: z.string().trim().min(1, "Name is required").max(120),
  client: z.string().trim().min(1, "Client is required").max(120),
  assigneeId: z.string().min(1),
  status: z.enum(PROJECT_STATUSES),
  budget: numStr(0, 1_000_000_000, "Budget"),
  burn: numStr(0, 300, "Budget used"),
  endDate: dateStr,
});
type V = z.infer<typeof schema>;
const blank: V = { name: "", client: "", assigneeId: "", status: "On track", budget: "0", burn: "0", endDate: "" };

function ProjectDialog({ open, onOpenChange, initial, practiceId, onSave }: { open: boolean; onOpenChange: (o: boolean) => void; initial: Project | null; practiceId: string; onSave: (p: Omit<Project, "id" | "practiceId">, id?: string) => void }) {
  const staff = STAFF.filter((s) => s.practiceId === practiceId);
  const form = useForm<V>({ resolver: zodResolver(schema), defaultValues: blank });
  useEffect(() => {
    if (open) form.reset(initial ? { ...initial, budget: String(initial.budget), burn: String(initial.burn) } : { ...blank, assigneeId: staff[0]?.id ?? "" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initial, form, practiceId]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent data-testid="dialog-project">
        <DialogHeader><DialogTitle>{initial ? "Edit project" : "New project"}</DialogTitle><DialogDescription>Synthetic record, stored in this browser tab only.</DialogDescription></DialogHeader>
        <Form {...form}>
          <form className="grid gap-3 sm:grid-cols-2" data-testid="form-project" onSubmit={form.handleSubmit((v) => { onSave({ ...v, status: v.status as ProjectStatus, budget: Number(v.budget), burn: Number(v.burn) }, initial?.id); onOpenChange(false); })}>
            <div className="sm:col-span-2"><Field form={form} name="name" label="Project name" testId="input-project-name" /></div>
            <Field form={form} name="client" label="Client (synthetic)" testId="input-project-client" />
            <Field form={form} name="assigneeId" label="Lead" options={staff.map((s) => ({ value: s.id, label: s.alias }))} testId="select-project-lead" />
            <Field form={form} name="status" label="Status" options={PROJECT_STATUSES.map((s) => ({ value: s, label: s }))} testId="select-project-status" />
            <Field form={form} name="endDate" label="Planned end" type="date" testId="input-project-end" />
            <Field form={form} name="budget" label="Budget (USD)" type="number" testId="input-project-budget" />
            <Field form={form} name="burn" label="Budget used (%)" type="number" testId="input-project-burn" />
            <div className="sm:col-span-2"><button type="submit" className={btn} data-testid="button-save-project">{initial ? "Save changes" : "Add project"}</button></div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function Body() {
  const { state, upsertProject, deleteProject, setProjectStatus } = usePoc();
  const v = useVisible();
  const c = caps(state.role);
  const [edit, setEdit] = useState<Project | null>(null);
  const [open, setOpen] = useState(false);
  const [del, setDel] = useState<Project | null>(null);
  const wp = v.writePractice;
  const canWrite = c.deliveryWrite && !!wp;
  const multi = v.practices.length > 1;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground" data-testid="text-delivery-scope">{state.role === "team_member" ? "Showing only projects assigned to you. You can update their status." : `${v.projects.length} projects in view.`}</p>
        {canWrite && <button className={btn} onClick={() => { setEdit(null); setOpen(true); }} data-testid="button-new-project"><Plus className="h-4 w-4" aria-hidden />New project</button>}
      </div>
      {v.projects.length === 0 ? <Empty testId="empty-delivery" title="No projects in view">{canWrite ? "Add the first project for this practice." : "Nothing is assigned to this preview role."}</Empty> : (
        <Table testId="table-delivery">
          <thead><tr><th className={th}>Project</th><th className={th}>Client</th>{multi && <th className={th}>Practice</th>}<th className={th}>Lead</th><th className={th}>Status</th>{c.financials && <th className={`${th} text-right`}>Budget</th>}<th className={`${th} w-32`}>Budget used</th><th className={th}>Ends</th>{canWrite && <th className={th}><span className="sr-only">Actions</span></th>}</tr></thead>
          <tbody>{v.projects.map((p) => (
            <tr key={p.id} className="border-t border-border transition-colors hover:bg-muted/50" data-testid={`row-project-${p.id}`}>
              <td className={`${td} font-medium`}>{p.name}</td><td className={td}>{p.client}</td>{multi && <td className={td}>{practiceShort(p.practiceId)}</td>}<td className={td}>{staffAlias(p.assigneeId)}</td>
              <td className={td}>{c.deliveryOwnStatus ? (
                <select value={p.status} onChange={(e) => setProjectStatus(p.id, e.target.value as ProjectStatus)} aria-label={`Status for ${p.name}`} data-testid={`select-status-${p.id}`} className={`${inputCls} !w-auto !py-1`}>{PROJECT_STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
              ) : <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-semibold ${STATUS_CLS[p.status]}`} data-testid={`status-project-${p.id}`}>{p.status}</span>}</td>
              {c.financials && <td className={`${td} text-right tabular-nums`}>{money(p.budget)}</td>}
              <td className={td}><div className="flex items-center gap-2"><ProgressBar pct={p.burn} tone={p.burn > 100 ? "bg-destructive" : p.burn > 80 ? "bg-[hsl(39_88%_50%)]" : "bg-primary"} /><span className="w-10 text-xs tabular-nums">{p.burn}%</span></div></td>
              <td className={`${td} tabular-nums`}>{p.endDate}</td>
              {canWrite && <td className={`${td} whitespace-nowrap text-right`}>
                <button className={btnGhost} onClick={() => { setEdit(p); setOpen(true); }} aria-label={`Edit ${p.name}`} data-testid={`button-edit-project-${p.id}`}><Pencil className="h-3.5 w-3.5" aria-hidden /></button>{" "}
                <button className={btnGhost} onClick={() => setDel(p)} aria-label={`Delete ${p.name}`} data-testid={`button-delete-project-${p.id}`}><Trash2 className="h-3.5 w-3.5" aria-hidden /></button></td>}
            </tr>))}</tbody>
        </Table>
      )}
      {canWrite && wp && <>
        <ProjectDialog open={open} onOpenChange={setOpen} initial={edit} practiceId={wp} onSave={(val, id) => upsertProject({ ...val, id, practiceId: wp })} />
        <Confirm open={!!del} onOpenChange={(o) => !o && setDel(null)} testId="dialog-delete-project" title="Delete project?" body={`${del?.name ?? ""} will be removed from this demo session.`} confirmLabel="Delete" onConfirm={() => { if (del) deleteProject(del.id); setDel(null); }} />
      </>}
    </div>
  );
}

export default function PocDelivery() {
  return <PocPage area="delivery" eyebrow="Role demo - delivery" title="Projects and how they are tracking." intro="Status, budget burn and ownership for the work in view."><Body /></PocPage>;
}

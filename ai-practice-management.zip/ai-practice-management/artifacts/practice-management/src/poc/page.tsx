import { useState, type ReactNode } from "react";
import { Link } from "wouter";
import { Lock, RotateCcw, TriangleAlert } from "lucide-react";
import { useSession } from "@/lib/session";
import { DemoEntry } from "@/components/demo-entry";
import { LoadingBlock, PageHeader, Panel } from "@/components/ui-kit";
import { NOTICE, usePoc, usePocActive } from "./store";
import { ROLE_LABEL, canView, caps, type Area } from "./policy";
import { PRACTICES } from "./seed";
import { Confirm, btnGhost, inputCls } from "./ui";

function Notice() {
  const { state, storageError, reset, setPractice } = usePoc();
  const [confirm, setConfirm] = useState(false);
  const c = caps(state.role);
  return (
    <div className="mb-6 space-y-2" data-testid="poc-notice">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[hsl(39_70%_60%)] bg-accent/60 px-4 py-2.5 text-sm">
        <p className="text-accent-foreground" data-testid="text-poc-notice"><strong>Preview role: {ROLE_LABEL[state.role]}.</strong> Presentation simulation only, not an access grant. {NOTICE}.</p>
        <div className="flex flex-wrap items-center gap-2">
          {c.choosePractice && (
            <label className="flex items-center gap-2 text-xs font-semibold">Managing practice
              <select value={state.practiceId} onChange={(e) => setPractice(e.target.value)} data-testid="select-practice" className={`${inputCls} !w-auto !py-1`}>
                {PRACTICES.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </label>
          )}
          <button onClick={() => setConfirm(true)} className={btnGhost} data-testid="button-reset-demo"><RotateCcw className="h-3.5 w-3.5" aria-hidden />Reset demo data</button>
        </div>
      </div>
      {storageError && <div role="alert" data-testid="alert-storage" className="flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/5 px-4 py-2.5 text-sm font-medium text-destructive"><TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />{storageError}</div>}
      <Confirm open={confirm} onOpenChange={setConfirm} testId="dialog-reset" title="Reset demo data?" body="All synthetic changes in this tab, including imported and edited records, return to the seed data. The preview role stays the same." confirmLabel="Reset demo data" onConfirm={() => reset()} />
    </div>
  );
}

function Denied({ title, body }: { title: string; body: string }) {
  return (
    <Panel testId="panel-poc-denied" className="border-l-4 border-l-destructive">
      <div className="flex items-center gap-2 font-display text-xl font-semibold"><Lock className="h-5 w-5" aria-hidden />{title}</div>
      <p className="mt-2 text-sm text-muted-foreground">{body}</p>
      <Link href="/" className="mt-4 inline-block text-sm font-semibold underline underline-offset-4" data-testid="link-denied-home">Back to overview</Link>
    </Panel>
  );
}

function Guarded({ area, children, eyebrow, title, intro }: { area: Area; children: ReactNode; eyebrow: string; title: string; intro: string }) {
  const { state } = usePoc();
  if (!canView(state.role, area)) {
    return <><Notice /><Denied title="Not available for this preview role" body={`The ${ROLE_LABEL[state.role]} preview does not include this page. Choose another preview role from the top right, or open Role access to see what each role can do.`} /><Link href="/poc/access" className="mt-3 inline-block text-sm font-semibold underline underline-offset-4" data-testid="link-denied-access">Open Role access</Link></>;
  }
  return <div className="animate-in fade-in slide-in-from-bottom-1 duration-300"><PageHeader eyebrow={eyebrow} title={title}>{intro}</PageHeader><Notice />{children}</div>;
}

export function PocPage(props: { area: Area; children: ReactNode; eyebrow: string; title: string; intro: string }) {
  const { auth, authLoading } = useSession();
  const active = usePocActive();
  if (authLoading) return <LoadingBlock />;
  if (!active) {
    if (!import.meta.env.DEV) return <Denied title="Role demo is not available" body="The synthetic role demo only exists in development builds." />;
    if (!auth?.sessionActive) return <DemoEntry />;
    return <Denied title="Role demo is not available for this session" body="The role demo needs an active synthetic demo session without access problems. Nothing is shown here." />;
  }
  return <Guarded {...props} />;
}

import { Check, Minus } from "lucide-react";
import { PocPage } from "./page";
import { usePoc } from "./store";
import { MATRIX, ROLES, ROLE_LABEL } from "./policy";
import { Table, td, th } from "./ui";

function Body() {
  const { state } = usePoc();
  return (
    <div className="space-y-4">
      <p className="text-sm" data-testid="text-access-current">Current preview: <strong>{ROLE_LABEL[state.role]}</strong>. {state.role === "administrator" ? "This preview shows the simulated access matrix only: no practice data, no grants and no user management. Pick another preview role to see practice data." : "Highlighted column is your current preview."}</p>
      <Table testId="table-access-matrix">
        <thead><tr><th className={th}>Capability</th>{ROLES.map((r) => <th key={r} className={`${th} text-center ${r === state.role ? "bg-accent text-accent-foreground" : ""}`} data-testid={`head-role-${r}`}>{ROLE_LABEL[r]}</th>)}</tr></thead>
        <tbody>{MATRIX.map((m) => (
          <tr key={m.label} className="border-t border-border" data-testid={`row-cap-${m.label.toLowerCase().replace(/[^a-z]+/g, "-")}`}>
            <td className={td}>{m.label}</td>
            {ROLES.map((r) => { const t = m.test(r); return <td key={r} className={`${td} text-center ${r === state.role ? "bg-accent/40" : ""}`}>{typeof t === "string" ? <span className="text-xs font-semibold">{t}</span> : t ? <Check className="mx-auto h-4 w-4 text-[hsl(172_40%_32%)]" aria-label="Allowed" /> : <Minus className="mx-auto h-4 w-4 text-muted-foreground" aria-label="Not allowed" />}</td>; })}
          </tr>))}</tbody>
      </Table>
      <p className="text-xs text-muted-foreground">This matrix explains the demo. It does not grant or change real access.</p>
    </div>
  );
}

export default function PocAccess() {
  return <PocPage area="access" eyebrow="Role demo - access" title="What each role can do." intro="A simulated capability matrix for the five preview roles."><Body /></PocPage>;
}

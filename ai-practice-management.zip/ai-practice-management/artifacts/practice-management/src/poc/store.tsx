import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useLocation } from "wouter";
import { useSession } from "@/lib/session";
import { ROLES, caps, canView, defaultPath, pathArea, type Role } from "./policy";
import { MANAGER_PRACTICE, PRACTICES, TEAM_MEMBER_ID, seedState, type DemoState } from "./seed";
import type { Goal, Opportunity, Project } from "./types";

export const STORAGE_KEY = "northstar.poc.session.v1";
export const NOTICE = "Synthetic data only; saved in this browser tab, cleared on End demo";

export function usePocActive() {
  const { auth, staleSession, accessDenied } = useSession();
  return !!(import.meta.env.DEV && auth && auth.mode === "demo" && auth.sessionActive && auth.synthetic && !staleSession && !accessDenied);
}

function load(): { state: DemoState; error: string | null } {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return { state: seedState(), error: null };
    const s = JSON.parse(raw) as DemoState;
    if (!ROLES.includes(s.role) || !Array.isArray(s.opps) || !Array.isArray(s.projects) || !Array.isArray(s.goals) || !PRACTICES.some((p) => p.id === s.practiceId)) throw new Error("shape");
    return { state: s, error: null };
  } catch {
    return { state: seedState(), error: "Saved demo data in this tab could not be read, so the seed data was loaded instead." };
  }
}

export const dupKey = (name: string, client: string) => `${name.trim().toLowerCase()}|${client.trim().toLowerCase()}`;
const uid = (pre: string) => `${pre}-${crypto.randomUUID().slice(0, 8)}`;

type Store = {
  state: DemoState;
  storageError: string | null;
  setRole: (r: Role) => void;
  setPractice: (id: string) => void;
  upsertOpp: (o: Omit<Opportunity, "id"> & { id?: string }) => void;
  deleteOpp: (id: string) => void;
  addOpps: (rows: Omit<Opportunity, "id">[]) => void;
  upsertProject: (o: Omit<Project, "id"> & { id?: string }) => void;
  deleteProject: (id: string) => void;
  setProjectStatus: (id: string, s: Project["status"]) => void;
  upsertGoal: (o: Omit<Goal, "id"> & { id?: string }) => void;
  deleteGoal: (id: string) => void;
  reset: () => void;
};
const Ctx = createContext<Store | null>(null);

function upsert<T extends { id: string }>(list: T[], item: Omit<T, "id"> & { id?: string }, pre: string): T[] {
  if (item.id) return list.map((x) => (x.id === item.id ? ({ ...x, ...item } as T) : x));
  return [...list, { ...item, id: uid(pre) } as T];
}

function ActiveStore({ children }: { children: ReactNode }) {
  const initial = useRef(load());
  const [state, setState] = useState<DemoState>(initial.current.state);
  const [storageError, setStorageError] = useState<string | null>(initial.current.error);
  const [loc, setLoc] = useLocation();
  const prevRole = useRef(state.role);

  useEffect(() => {
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state)); setStorageError((e) => (e && e.startsWith("Could not save") ? null : e)); }
    catch { setStorageError("Could not save demo changes in this browser tab. Changes will be lost on reload."); }
  }, [state]);

  useEffect(() => {
    if (prevRole.current === state.role) return;
    prevRole.current = state.role;
    const a = pathArea(loc);
    if (loc.startsWith("/poc") && (!a || !canView(state.role, a))) setLoc(defaultPath(state.role));
  }, [state.role, loc, setLoc]);

  const patch = useCallback((f: (s: DemoState) => DemoState) => setState(f), []);
  const value = useMemo<Store>(() => ({
    state, storageError,
    setRole: (role) => patch((s) => ({ ...s, role })),
    setPractice: (practiceId) => patch((s) => ({ ...s, practiceId })),
    upsertOpp: (o) => patch((s) => ({ ...s, opps: upsert(s.opps, o, "o") })),
    deleteOpp: (id) => patch((s) => ({ ...s, opps: s.opps.filter((x) => x.id !== id) })),
    addOpps: (rows) => patch((s) => ({ ...s, opps: [...s.opps, ...rows.map((r) => ({ ...r, id: uid("o") }))] })),
    upsertProject: (o) => patch((s) => ({ ...s, projects: upsert(s.projects, o, "j") })),
    deleteProject: (id) => patch((s) => ({ ...s, projects: s.projects.filter((x) => x.id !== id) })),
    setProjectStatus: (id, status) => patch((s) => ({ ...s, projects: s.projects.map((x) => (x.id === id ? { ...x, status } : x)) })),
    upsertGoal: (o) => patch((s) => ({ ...s, goals: upsert(s.goals, o, "g") })),
    deleteGoal: (id) => patch((s) => ({ ...s, goals: s.goals.filter((x) => x.id !== id) })),
    reset: () => { setStorageError(null); setState(seedState(state.role)); },
  }), [state, storageError, patch]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/** Mounts the store only inside an active synthetic demo; clears stored data otherwise. */
export function PocBoundary({ children }: { children: ReactNode }) {
  const active = usePocActive();
  const { auth, authLoading } = useSession();
  const [clearError, setClearError] = useState(false);
  const settled = !authLoading && !!auth;
  useEffect(() => {
    if (settled && !active) {
      try { sessionStorage.removeItem(STORAGE_KEY); setClearError(false); }
      catch { setClearError(true); }
    }
  }, [settled, active]);
  if (!active) return <>{clearError && <p role="alert" data-testid="alert-demo-clear" className="bg-destructive p-3 text-destructive-foreground">This browser blocked clearing the tab's synthetic demo data. Close this tab to discard it.</p>}{children}</>;
  return <ActiveStore>{children}</ActiveStore>;
}

export function usePocOptional() { return useContext(Ctx); }
export function usePoc() {
  const c = useContext(Ctx);
  if (!c) throw new Error("Demo store is only available inside an active synthetic demo");
  return c;
}

/** Data visible to the previewed role. Enforced here, not just in navigation. */
export function useVisible() {
  const { state } = usePoc();
  return useMemo(() => {
    const { role } = state;
    const c = caps(role);
    let ids: string[] = [];
    if (c.allPractices) ids = PRACTICES.map((p) => p.id);
    else if (role === "practice_director") ids = [state.practiceId];
    else if (role === "manager") ids = [MANAGER_PRACTICE];
    else if (role === "team_member") ids = [MANAGER_PRACTICE];
    const inP = <T extends { practiceId: string }>(l: T[]) => l.filter((x) => ids.includes(x.practiceId));
    return {
      practiceIds: ids,
      practices: PRACTICES.filter((p) => ids.includes(p.id)),
      opps: c.financials ? inP(state.opps) : [],
      projects: role === "team_member" ? inP(state.projects).filter((x) => x.assigneeId === TEAM_MEMBER_ID) : inP(state.projects),
      goals: role === "team_member" ? inP(state.goals).filter((x) => x.ownerId === TEAM_MEMBER_ID) : inP(state.goals),
      writePractice: role === "practice_director" ? state.practiceId : role === "manager" ? MANAGER_PRACTICE : null,
    };
  }, [state]);
}

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form } from "@/components/ui/form";
import { STAGES } from "./pipeline-import";
import type { Opportunity, Stage } from "./types";
import { Field, btn, dateStr, numStr } from "./ui";

const schema = z.object({
  name: z.string().trim().min(1, "Name is required").max(120),
  client: z.string().trim().min(1, "Client is required").max(120),
  owner: z.string().trim().min(1, "Owner is required").max(80),
  stage: z.enum(STAGES),
  value: numStr(0, 1_000_000_000, "Value"),
  closeDate: dateStr,
  probability: numStr(0, 100, "Probability"),
});
type V = z.infer<typeof schema>;
const blank: V = { name: "", client: "", owner: "", stage: "Qualification", value: "0", closeDate: "", probability: "10" };

export function OppDialog({ open, onOpenChange, initial, existing, onSave }: { open: boolean; onOpenChange: (o: boolean) => void; initial: Opportunity | null; existing: Opportunity[]; onSave: (v: Omit<Opportunity, "id" | "practiceId">, id?: string) => void }) {
  const form = useForm<V>({ resolver: zodResolver(schema), defaultValues: blank });
  useEffect(() => {
    if (open) form.reset(initial ? { ...initial, value: String(initial.value), probability: String(initial.probability) } : blank);
  }, [open, initial, form]);
  const submit = (v: V) => {
    const k = `${v.name.trim().toLowerCase()}|${v.client.trim().toLowerCase()}`;
    if (existing.some((o) => o.id !== initial?.id && `${o.name.trim().toLowerCase()}|${o.client.trim().toLowerCase()}` === k)) {
      form.setError("name", { message: "An opportunity with this name and client already exists" });
      return;
    }
    onSave({ ...v, stage: v.stage as Stage, value: Number(v.value), probability: Number(v.probability) }, initial?.id);
    onOpenChange(false);
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent data-testid="dialog-opportunity">
        <DialogHeader><DialogTitle>{initial ? "Edit opportunity" : "New opportunity"}</DialogTitle><DialogDescription>Synthetic record, stored in this browser tab only.</DialogDescription></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(submit)} className="grid gap-3 sm:grid-cols-2" data-testid="form-opportunity">
            <div className="sm:col-span-2"><Field form={form} name="name" label="Opportunity name" testId="input-opp-name" /></div>
            <Field form={form} name="client" label="Client (synthetic)" testId="input-opp-client" />
            <Field form={form} name="owner" label="Owner alias" testId="input-opp-owner" />
            <Field form={form} name="stage" label="Stage" options={STAGES.map((s) => ({ value: s, label: s }))} testId="select-opp-stage" />
            <Field form={form} name="value" label="Value (USD)" type="number" testId="input-opp-value" />
            <Field form={form} name="closeDate" label="Expected close" type="date" testId="input-opp-close" />
            <Field form={form} name="probability" label="Probability (%)" type="number" testId="input-opp-probability" />
            <div className="sm:col-span-2"><button type="submit" className={btn} data-testid="button-save-opportunity">{initial ? "Save changes" : "Add opportunity"}</button></div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

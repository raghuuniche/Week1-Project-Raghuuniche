import type { Opportunity, Project } from "./types";
export const isOpen = (o: Opportunity) => o.stage !== "Won" && o.stage !== "Lost";
export function pipelineTotals(opps: Opportunity[]) {
  const open = opps.filter(isOpen);
  return {
    openCount: open.length,
    openValue: open.reduce((s, o) => s + o.value, 0),
    weighted: Math.round(open.reduce((s, o) => s + (o.value * o.probability) / 100, 0)),
    wonValue: opps.filter((o) => o.stage === "Won").reduce((s, o) => s + o.value, 0),
    lostValue: opps.filter((o) => o.stage === "Lost").reduce((s, o) => s + o.value, 0),
  };
}
export const projectCounts = (ps: Project[]) => ({
  total: ps.length,
  atRisk: ps.filter((p) => p.status === "At risk" || p.status === "Off track").length,
  budget: ps.reduce((s, p) => s + p.budget, 0),
});

import type { ReactNode } from "react";
import type { UseFormReturn } from "react-hook-form";
import { FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import type { Stage } from "./types";

export const money = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);
export const num = (n: number) => new Intl.NumberFormat("en-US").format(n);
export const btn = "inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:opacity-90 disabled:opacity-50";
export const btnGhost = "inline-flex items-center gap-1.5 rounded-md border border-input bg-card px-2.5 py-1.5 text-sm font-medium transition-colors hover:bg-muted disabled:opacity-50";
export const inputCls = "w-full rounded-md border border-input bg-card px-3 py-2 text-sm outline-none transition-shadow focus:ring-2 focus:ring-ring";
export const th = "px-3 py-2 text-left font-mono text-[11px] font-medium uppercase tracking-wider text-muted-foreground";
export const td = "px-3 py-2.5 text-sm align-middle";

const STAGE_CLS: Record<Stage, string> = {
  Qualification: "bg-muted text-muted-foreground",
  Discovery: "bg-[hsl(205_45%_88%)] text-[hsl(210_55%_24%)]",
  Proposal: "bg-accent text-accent-foreground",
  Negotiation: "bg-[hsl(24_75%_86%)] text-[hsl(18_65%_28%)]",
  Won: "bg-[hsl(172_40%_86%)] text-[hsl(172_50%_20%)]",
  Lost: "bg-destructive/10 text-destructive",
};
export function StageBadge({ stage }: { stage: Stage }) {
  return <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-semibold ${STAGE_CLS[stage]}`}>{stage}</span>;
}
export const STATUS_CLS: Record<string, string> = {
  "On track": "bg-[hsl(172_40%_86%)] text-[hsl(172_50%_20%)]",
  "At risk": "bg-accent text-accent-foreground",
  "Off track": "bg-destructive/10 text-destructive",
  Complete: "bg-muted text-muted-foreground",
};

export function Stat({ label, value, hint, testId }: { label: string; value: string; hint?: string; testId: string }) {
  return (
    <div className="rounded-lg border border-card-border bg-card p-4 transition-transform duration-200 hover:-translate-y-0.5" data-testid={testId}>
      <p className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="font-display mt-1 text-2xl font-semibold" data-testid={`${testId}-value`}>{value}</p>
      {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function Empty({ title, children, testId }: { title: string; children?: ReactNode; testId: string }) {
  return (
    <div className="rounded-lg border border-dashed border-input bg-muted/40 px-6 py-10 text-center" data-testid={testId}>
      <p className="font-display text-lg font-semibold">{title}</p>
      {children && <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">{children}</p>}
    </div>
  );
}

export function Table({ children, testId }: { children: ReactNode; testId: string }) {
  return <div className="overflow-x-auto rounded-lg border border-card-border bg-card"><table className="w-full min-w-[640px] border-collapse" data-testid={testId}>{children}</table></div>;
}

export function ProgressBar({ pct, tone = "bg-primary" }: { pct: number; tone?: string }) {
  return <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted"><div className={`h-full origin-left rounded-full transition-transform duration-500 ${tone}`} style={{ transform: `scaleX(${Math.max(0, Math.min(100, pct)) / 100})` }} /></div>;
}

export function Confirm({ open, onOpenChange, title, body, confirmLabel, onConfirm, testId }: { open: boolean; onOpenChange: (o: boolean) => void; title: string; body: string; confirmLabel: string; onConfirm: () => void; testId: string }) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent data-testid={testId}>
        <AlertDialogHeader><AlertDialogTitle>{title}</AlertDialogTitle><AlertDialogDescription>{body}</AlertDialogDescription></AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel data-testid={`${testId}-cancel`}>Cancel</AlertDialogCancel>
          <AlertDialogAction data-testid={`${testId}-confirm`} onClick={onConfirm}>{confirmLabel}</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function Field({ form, name, label, type = "text", options, testId }: { form: UseFormReturn<any>; name: string; label: string; type?: string; options?: { value: string; label: string }[]; testId: string }) {
  return (
    <FormField control={form.control} name={name} render={({ field }) => (
      <FormItem>
        <FormLabel>{label}</FormLabel>
        <FormControl>
          {options ? (
            <select {...field} data-testid={testId} className={inputCls}>{options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
          ) : (
            <input {...field} type={type} step={type === "number" ? "any" : undefined} data-testid={testId} className={inputCls} />
          )}
        </FormControl>
        <FormMessage />
      </FormItem>
    )} />
  );
}
import { z } from "zod";
export const numStr = (min: number, max = Number.MAX_SAFE_INTEGER, label = "Value") =>
  z.string().refine((v) => v.trim() !== "" && Number.isFinite(Number(v)) && Number(v) >= min && Number(v) <= max, `${label} must be a number from ${min} to ${max === Number.MAX_SAFE_INTEGER ? "any size" : max}`);
export const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use a valid date");

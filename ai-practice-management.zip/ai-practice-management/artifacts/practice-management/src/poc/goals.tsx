import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form } from "@/components/ui/form";
import { PocPage } from "./page";
import { usePoc, useVisible } from "./store";
import { caps } from "./policy";
import { STAFF, practiceShort, staffAlias } from "./seed";
import type { Goal } from "./types";
import { Confirm, Empty, Field, ProgressBar, Table, btn, btnGhost, dateStr, numStr, td, th } from "./ui";

const schema = z.object({
  title: z.string().trim().min(1, "Title is required").max(120),
  ownerId: z.string().min(1),
  current: numStr(0, 1_000_000_000, "Current"),
  target: numStr(1, 1_000_000_000, "Target"),
  unit: z.string().trim().min(1, "Unit is required").max(20),
  due: dateStr,
});
type V = z.infer<typeof schema>;
const blank: V = { title: "", ownerId: "", current: "0", target: "100", unit: "%", due: "" };

function GoalDialog({ open, onOpenChange, initial, practiceId, onSave }: { open: boolean; onOpenChange: (o: boolean) => void; initial: Goal | null; practiceId: string; onSave: (g: Omit<Goal, "id" | "practiceId">, id?: string) => void }) {
  const staff = STAFF.filter((s) => s.practiceId === practiceId);
  const form = useForm<V>({ resolver: zodResolver(schema), defaultValues: blank });
  useEffect(() => {
    if (open) form.reset(initial ? { ...initial, current: String(initial.current), target: String(initial.target) } : { ...blank, ownerId: staff[0]?.id ?? "" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initial, form, practiceId]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent data-testid="dialog-goal">
        <DialogHeader><DialogTitle>{initial ? "Edit goal" : "New goal"}</DialogTitle><DialogDescription>Synthetic record, stored in this browser tab only.</DialogDescription></DialogHeader>
        <Form {...form}>
          <form className="grid gap-3 sm:grid-cols-2" data-testid="form-goal" onSubmit={form.handleSubmit((v) => { onSave({ ...v, current: Number(v.current), target: Number(v.target) }, initial?.id); onOpenChange(false); })}>
            <div className="sm:col-span-2"><Field form={form} name="title" label="Goal" testId="input-goal-title" /></div>
            <Field form={form} name="ownerId" label="Owner" options={staff.map((s) => ({ value: s.id, label: s.alias }))} testId="select-goal-owner" />
            <Field form={form} name="due" label="Due" type="date" testId="input-goal-due" />
            <Field form={form} name="current" label="Current" type="number" testId="input-goal-current" />
            <Field form={form} name="target" label="Target" type="number" testId="input-goal-target" />
            <Field form={form} name="unit" label="Unit" testId="input-goal-unit" />
            <div className="sm:col-span-2"><button type="submit" className={btn} data-testid="button-save-goal">{initial ? "Save changes" : "Add goal"}</button></div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function Body() {
  const { state, upsertGoal, deleteGoal } = usePoc();
  const v = useVisible();
  const c = caps(state.role);
  const [edit, setEdit] = useState<Goal | null>(null);
  const [open, setOpen] = useState(false);
  const [del, setDel] = useState<Goal | null>(null);
  const wp = v.writePractice;
  const canWrite = c.goalsWrite && !!wp;
  const multi = v.practices.length > 1;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground" data-testid="text-goals-scope">{state.role === "team_member" ? "Showing goals you own." : canWrite ? "You manage goals for the selected practice." : "Read only for this preview role."}</p>
        {canWrite && <button className={btn} onClick={() => { setEdit(null); setOpen(true); }} data-testid="button-new-goal"><Plus className="h-4 w-4" aria-hidden />New goal</button>}
      </div>
      {v.goals.length === 0 ? <Empty testId="empty-goals" title="No goals in view">{canWrite ? "Add the first goal for this practice." : "No goals are assigned to this preview role."}</Empty> : (
        <Table testId="table-goals">
          <thead><tr><th className={th}>Goal</th>{multi && <th className={th}>Practice</th>}<th className={th}>Owner</th><th className={th}>Progress</th><th className={th}>Due</th>{canWrite && <th className={th}><span className="sr-only">Actions</span></th>}</tr></thead>
          <tbody>{v.goals.map((g) => {
            const pct = Math.round((g.current / g.target) * 100);
            return (
              <tr key={g.id} className="border-t border-border transition-colors hover:bg-muted/50" data-testid={`row-goal-${g.id}`}>
                <td className={`${td} font-medium`}>{g.title}</td>{multi && <td className={td}>{practiceShort(g.practiceId)}</td>}<td className={td}>{staffAlias(g.ownerId)}</td>
                <td className={`${td} min-w-[200px]`}><div className="flex items-center gap-2"><ProgressBar pct={pct} tone="bg-[hsl(172_40%_32%)]" /><span className="whitespace-nowrap text-xs tabular-nums" data-testid={`text-goal-progress-${g.id}`}>{g.current}/{g.target} {g.unit} ({pct}%)</span></div></td>
                <td className={`${td} tabular-nums`}>{g.due}</td>
                {canWrite && <td className={`${td} whitespace-nowrap text-right`}>
                  <button className={btnGhost} onClick={() => { setEdit(g); setOpen(true); }} aria-label={`Edit ${g.title}`} data-testid={`button-edit-goal-${g.id}`}><Pencil className="h-3.5 w-3.5" aria-hidden /></button>{" "}
                  <button className={btnGhost} onClick={() => setDel(g)} aria-label={`Delete ${g.title}`} data-testid={`button-delete-goal-${g.id}`}><Trash2 className="h-3.5 w-3.5" aria-hidden /></button></td>}
              </tr>);
          })}</tbody>
        </Table>
      )}
      {canWrite && wp && <>
        <GoalDialog open={open} onOpenChange={setOpen} initial={edit} practiceId={wp} onSave={(val, id) => upsertGoal({ ...val, id, practiceId: wp })} />
        <Confirm open={!!del} onOpenChange={(o) => !o && setDel(null)} testId="dialog-delete-goal" title="Delete goal?" body={`${del?.title ?? ""} will be removed from this demo session.`} confirmLabel="Delete" onConfirm={() => { if (del) deleteGoal(del.id); setDel(null); }} />
      </>}
    </div>
  );
}

export default function PocGoals() {
  return <PocPage area="goals" eyebrow="Role demo - goals" title="What each practice is aiming for." intro="Targets, current position and owners for the goals in view."><Body /></PocPage>;
}

# Northstar design tokens

Direction: editorial paper-and-ink, brass accent. Light mode only in use.

## Palette (HSL, defined in `src/index.css`)
| Token | Value | Use |
|---|---|---|
| background | 42 33% 96% | warm paper page |
| card | 44 40% 98% | panels |
| foreground | 218 40% 14% | ink text |
| muted-foreground | 218 14% 38% | secondary text |
| border | 38 18% 84% | hairlines |
| primary | 218 48% 22% | ink-navy buttons, step markers |
| sidebar | 218 45% 13% | navigation rail |
| sidebar-primary | 39 88% 58% | brass star accent |
| accent | 39 85% 88% | demo banner, warnings |
| destructive | 4 62% 40% | errors |
| teal (inline) | 172 40% 32% / 88% | positive fact icon / pill |

## Typography
- Display: Fraunces 500/600 (`.font-display`)
- Body: Hanken Grotesk 400-700
- Mono labels: JetBrains Mono, uppercase, 0.16-0.18em tracking
- Page title 30/36px, panel title 20px, body 14px

## Spacing and radius
- Radius base 0.5rem (8px); controls `rounded-md`, panels `rounded-lg`
- Panel padding 20px (24px at sm+); page padding 16px (32px at sm+), max width 64rem
- Vertical rhythm between panels 24px; header gap 32px
- Sidebar 16rem; mobile drawer 18rem

## Status language
Brass left border = needs attention (config required, no practice access). Amber banner = demo session. Destructive tint = load errors with retry.

import { test } from "node:test";
import assert from "node:assert/strict";
import { validatePipelineRows, parsePipelineFile } from "../src/poc/pipeline-import";

const header = ["name", "client", "owner", "stage", "value", "closeDate", "probability"];
const good = ["Example, assessment", "Demo client", "Demo director", "Discovery", "25000", "2026-12-15", "40"];

test("accepts canonical pipeline input, reordered headers and Excel dates", () => {
  const result = validatePipelineRows([header, good, ["Other", "Demo", "Director", "won", 0, new Date("2026-12-15T00:00:00Z"), 100]]);
  assert.deepEqual(result.errors, []);
  assert.equal(result.rows[0].value, 25000);
  assert.equal(result.rows[1].stage, "Won");
  assert.equal(result.rows[1].closeDate, "2026-12-15");
  const reversed = validatePipelineRows([[...header].reverse(), [...good].reverse()]);
  assert.deepEqual(reversed.rows, [result.rows[0]]);
});

test("rejects bad headers and attempts to assign scope", () => {
  for (const sheet of [
    [header.slice(1), good],
    [[...header, "practiceId"], [...good, "other-practice"]],
    [[...header, "name"], [...good, "duplicate"]],
  ]) assert.ok(validatePipelineRows(sheet).errors.length);
});

test("validates required fields, real dates, finite values, bounds and stage", () => {
  for (const [index, value] of [[0, ""], [3, "Invalid"], [4, "-1"], [4, "Infinity"], [4, "$100"], [4, "1000000001"], [5, "2026-02-30"], [5, "12/15/2026"], [6, "101"], [6, ""]] as const) {
    const row: unknown[] = [...good];
    row[index] = value;
    const result = validatePipelineRows([header, row]);
    assert.equal(result.rows.length, 0);
    assert.match(result.errors[0], /^Row 2:/);
  }
  assert.ok(validatePipelineRows([header, [...good, "extra"]]).errors.length);
});

test("returns row-level errors for preview so a caller can block the whole import", () => {
  const bad = [...good]; bad[4] = "bad";
  const result = validatePipelineRows([header, good, bad]);
  assert.equal(result.rows.length, 1);
  assert.equal(result.errors.length, 1);
  assert.match(result.errors[0], /^Row 3:/);
});

test("rejects empty and oversized sheets", () => {
  for (const sheet of [[], [header], [header, ...Array.from({ length: 1001 }, () => good)]]) {
    assert.ok(validatePipelineRows(sheet).errors.length);
  }
});

test("CSV parser handles quoted commas and BOM; blocks malformed CSV and wrong files", async () => {
  const file = new File(['\uFEFFname,client,owner,stage,value,closeDate,probability\r\n"Example, assessment",Demo,Director,Proposal,5000,2026-12-15,60'], "demo.csv");
  const parsed = await parsePipelineFile(file);
  assert.deepEqual(parsed.errors, []);
  assert.equal(parsed.rows[0].name, "Example, assessment");
  for (const bad of [
    new File(["x"], "demo.xls"),
    new File([], "empty.csv"),
    new File(['name,client\n"unterminated'], "broken.csv"),
    new File(["not a workbook"], "demo.xlsx"),
    new File([new Uint8Array(5 * 1024 * 1024 + 1)], "huge.csv"),
  ]) assert.ok((await parsePipelineFile(bad)).errors.length);
});

test("CSV mixed validity preserves errors so the review cannot commit valid rows alone", async () => {
  const invalid = [...good]; invalid[4] = "-10";
  const quote = (cells: string[]) => cells.map((s) => `"${s.replaceAll('"', '""')}"`).join(",");
  const parsed = await parsePipelineFile(new File([[header.join(","), quote(good), quote(invalid)].join("\r\n")], "mixed.csv"));
  assert.equal(parsed.rows.length, 1);
  assert.match(parsed.errors[0], /^Row 3:/);
});

test("normalizes header case and whitespace but rejects scope and duplicate columns in real CSV", async () => {
  const normalized = await parsePipelineFile(new File([`${header.map((h) => ` ${h.toUpperCase()} `).join(",")}\nSimple,Demo,Alias,discovery,10,2026-12-15,50`], "case.CSV"));
  assert.deepEqual(normalized.errors, []);
  assert.equal(normalized.rows[0].stage, "Discovery");
  for (const extra of ["practiceId", "NAME"]) {
    const parsed = await parsePipelineFile(new File([`${header.join(",")},${extra}\nSimple,Demo,Alias,Discovery,10,2026-12-15,50,p2`], "scope.csv"));
    assert.equal(parsed.rows.length, 0);
    assert.ok(parsed.errors.length);
  }
});

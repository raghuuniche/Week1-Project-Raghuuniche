import assert from "node:assert/strict";
import { test } from "node:test";
import { requireTestDatabase } from "./test-database";

test("integration target fails closed instead of falling back to application or remote databases", () => {
  const original = process.env.FOUNDATION_TEST_DATABASE_URL;
  try {
    delete process.env.FOUNDATION_TEST_DATABASE_URL;
    assert.throws(requireTestDatabase, /is required/);
    for (const value of [
      "postgresql://test@example.invalid:25432/foundation_test_gate",
      "postgresql://test@127.0.0.1:5432/foundation_test_gate",
      "postgresql://test@127.0.0.1:25432/application",
      "postgresql://test@127.0.0.1:25432/foundation_test_gate?host=example.invalid",
    ]) {
      process.env.FOUNDATION_TEST_DATABASE_URL = value;
      assert.throws(requireTestDatabase, /dedicated loopback/);
    }
    process.env.FOUNDATION_TEST_DATABASE_URL = "postgresql://test@127.0.0.1:25432/foundation_test_gate";
    assert.equal(requireTestDatabase(), process.env.FOUNDATION_TEST_DATABASE_URL);
  } finally {
    if (original === undefined) delete process.env.FOUNDATION_TEST_DATABASE_URL;
    else process.env.FOUNDATION_TEST_DATABASE_URL = original;
  }
});

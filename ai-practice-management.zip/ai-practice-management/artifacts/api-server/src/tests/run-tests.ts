import { spawn } from "node:child_process";
import { readdir } from "node:fs/promises";
import pg from "pg";
import { requireTestDatabase } from "./test-database";

const connectionString = requireTestDatabase();
const pool = new pg.Pool({ connectionString, connectionTimeoutMillis: 5_000 });
try {
  // Missing services/schema must fail, not silently turn integration tests into skips.
  await pool.query("SELECT singleton FROM public.administrator_bootstrap_audits LIMIT 0");
} finally {
  await pool.end();
}
const files = (await readdir(new URL(".", import.meta.url)))
  .filter((name) => name.endsWith(".test.ts"))
  .sort()
  .map((name) => new URL(name, import.meta.url).pathname);
if (!files.length) throw new Error("No foundation API tests found.");
const child = spawn(process.execPath, ["--import", "tsx", "--test", ...files], {
  stdio: "inherit",
  env: { ...process.env, DATABASE_URL: connectionString, NODE_ENV: "test" },
});
child.on("error", () => { process.exitCode = 1; });
child.on("exit", (code) => { process.exitCode = code ?? 1; });

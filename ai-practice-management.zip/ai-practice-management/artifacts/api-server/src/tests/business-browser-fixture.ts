// Test-only runtime, NOT imported by the product server or its build.
import express from "express";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { createApp } from "../app";
import { requireTestDatabase } from "./test-database";

const target = requireTestDatabase();
if (process.env.NODE_ENV !== "test" || process.env.DATABASE_URL !== target) throw new Error("Synthetic browser fixture needs its isolated test database");
const { db, pool, organizations, practices, users, identityLinks, practiceMemberships, businessRecords, globalAdministratorGrants } = await import("@workspace/db");
const [org] = await db.insert(organizations).values({ name: "Synthetic browser verification" }).returning();
const [practice] = await db.insert(practices).values({ organizationId: org.id, slug: randomUUID(), name: "Synthetic browser practice" }).returning();
const [other] = await db.insert(practices).values({ organizationId: org.id, slug: randomUUID(), name: "Synthetic other browser practice", currency: "EUR" }).returning();
const issuer = `https://synthetic.invalid/${randomUUID()}`;
const ids: Record<string, string> = {};
for (const role of ["practice_director", "manager", "team_member", "executive", "administrator"]) {
  const [user] = await db.insert(users).values({}).returning();
  ids[role] = user.id;
  await db.insert(identityLinks).values({ userId: user.id, issuer, subject: user.id });
  if (role !== "administrator") await db.insert(practiceMemberships).values({ userId: user.id, practiceId: practice.id, role: role as "practice_director" | "manager" | "team_member" | "executive" });
}
await db.insert(practiceMemberships).values({ userId: ids.executive, practiceId: other.id, role: "executive" });
await db.insert(globalAdministratorGrants).values({ userId: ids.administrator, grantedByOperator: "synthetic browser fixture" });
await db.insert(businessRecords).values([
  { organizationId: org.id, practiceId: practice.id, kind: "delivery", name: "Synthetic assigned project", client: "Synthetic client", assignedUserId: ids.team_member, dueDate: "2026-10-10", status: "On track", budget: "500.00", burn: "100.00" },
  { organizationId: org.id, practiceId: practice.id, kind: "goal", name: "Synthetic assigned goal", assignedUserId: ids.team_member, dueDate: "2026-10-10", current: "1.00", target: "2.00", unit: "units" },
]);
const app = createApp({ ...process.env, AUTH_MODE: "entra" }, (app) => {
  app.post("/api/__synthetic/session/:role", (req, res, next) => {
    const userId = ids[String(req.params.role)];
    if (!userId) { res.status(404).end(); return; }
    req.session.regenerate((error) => {
      if (error) { next(error); return; }
      req.session.identity = { kind: "provider", issuer, subject: userId };
      req.session.save((error) => { if (error) next(error); else res.status(204).end(); });
    });
  });
  app.get("/api/__synthetic/context", (_req, res) => res.json({ practiceId: practice.id, otherPracticeId: other.id, ids }));
});
const web = path.resolve(import.meta.dirname, "../../../practice-management/dist/public");
app.use(express.static(web));
app.use((req, res) => {
  if (req.method !== "GET") { res.status(404).end(); return; }
  res.sendFile(path.join(web, "index.html"));
});
const server = app.listen(25442, "127.0.0.1", () => console.log("Business UI fixture ready at http://127.0.0.1:25442"));
for (const signal of ["SIGTERM", "SIGINT"] as const) process.on(signal, () => {
  server.close(() => { void pool.end().then(() => process.exit(0)); });
});

import { test } from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import { createApp } from "../app";
import { readAuthConfig } from "../auth/config";
import { DEMO_IDENTITY } from "../auth/identity";
import { resolvePracticeAccess } from "../auth/policy";
import { hasGlobalAdministratorGrant } from "../auth/authorization";

const env = { NODE_ENV: "test", AUTH_MODE: "demo", SESSION_SECRET: "test-only-not-an-application-credential-32-characters" };
const origin = "http://foundation.test";
function get(agent: ReturnType<typeof request.agent>, path: string) {
  return agent.get(path).set("Host", "foundation.test");
}
function post(agent: ReturnType<typeof request.agent>, path: string, token?: string) {
  const req = agent.post(path).set("Host", "foundation.test").set("Origin", origin);
  return token ? req.set("X-CSRF-Token", token) : req;
}
test("mode defaults off, invalid config rejected, demo cannot be production or an unspecified environment", () => {
  assert.equal(readAuthConfig({}).mode, "disabled");
  assert.throws(() => readAuthConfig({ AUTH_MODE: "unknown" }));
  assert.throws(() => readAuthConfig({ AUTH_MODE: "demo", NODE_ENV: "production" }));
  assert.throws(() => readAuthConfig({ AUTH_MODE: "demo", NODE_ENV: "development", REPLIT_DEPLOYMENT: "1" }));
  assert.throws(() => readAuthConfig({ AUTH_MODE: "demo" }));
  assert.equal(readAuthConfig({ AUTH_MODE: "entra" }).reason, "ENTRA_NOT_IMPLEMENTED");
  assert.throws(() => createApp({ NODE_ENV: "test", SESSION_SECRET: "short" }));
});
test("identity and Administrator status never substitute for exact practice membership", async () => {
  const identity = { kind: "provider" as const, issuer: "verified-issuer", subject: "verified-subject" };
  assert.equal((await resolvePracticeAccess(null, "a", async () => "manager")).allowed, false);
  assert.equal((await resolvePracticeAccess(identity, "a", async () => null)).allowed, false);
  // A provider could have a global admin grant; policy deliberately takes no
  // grant override and cannot turn it into a practice membership.
  const findMembership = async (_identity: unknown, scope: string) => scope === "a" ? "manager" : null;
  assert.equal((await resolvePracticeAccess(identity, "a", findMembership)).allowed, true);
  assert.equal((await resolvePracticeAccess(identity, "b", findMembership)).allowed, false);
  assert.equal((await resolvePracticeAccess(identity, "a", findMembership, ["administrator"])).allowed, false);
});
test("synthetic identity cannot access real scope, database, or Administrator grants", async () => {
  const neverRead = async () => { throw new Error("demo must not query membership data"); };
  assert.equal((await resolvePracticeAccess(DEMO_IDENTITY, "demo-practice", neverRead)).allowed, true);
  assert.equal((await resolvePracticeAccess(DEMO_IDENTITY, "real-practice", neverRead)).allowed, false);
  assert.equal((await resolvePracticeAccess(DEMO_IDENTITY, "demo-practice", neverRead, ["administrator"])).allowed, false);
  assert.equal(await hasGlobalAdministratorGrant(DEMO_IDENTITY), false);
});
test("API demo entry, session rotation, scope isolation, logout, stale-token denial", async () => {
  const app = createApp(env);
  const agent = request.agent(app);
  await get(agent, "/api/foundation").set("X-Role", "administrator").set("X-User", "spoofed").expect(401);
  const status = await get(agent, "/api/auth/status").expect(200);
  assert.equal(status.body.sessionActive, false);
  assert.match(status.headers["set-cookie"][0], /HttpOnly/);
  await post(agent, "/api/auth/demo").expect(403);
  await agent.post("/api/auth/demo").set("Host", "foundation.test").set("Origin", "http://attacker.test").set("X-CSRF-Token", status.body.csrfToken).expect(403);
  await agent.post("/api/auth/demo").set("Host", "foundation.test").set("Origin", "https://foundation.test").set("X-CSRF-Token", status.body.csrfToken).expect(403);
  const active = await post(agent, "/api/auth/demo", status.body.csrfToken).expect(200);
  assert.equal(active.body.synthetic, true);
  assert.equal(active.body.administrator, false);
  assert.equal(active.body.role, "practice_director");
  assert.notEqual(active.body.csrfToken, status.body.csrfToken);
  assert.notEqual(active.headers["set-cookie"][0].split(";")[0], status.headers["set-cookie"][0].split(";")[0]);
  const activeCookie = active.headers["set-cookie"][0].split(";")[0];
  const foundation = await get(agent, "/api/foundation").expect(200);
  assert.equal(foundation.body.realDataAccess, false);
  assert.equal(foundation.body.businessModulesEnabled, false);
  assert.equal(foundation.body.identityVerified, false);
  await get(agent, "/api/practices/demo-practice/access").expect(200);
  await get(agent, "/api/practices/11111111-1111-1111-1111-111111111111/access").expect(403);
  await get(agent, "/api/admin/setup").expect(403);
  await post(agent, "/api/admin/bootstrap", active.body.csrfToken).expect(404);
  await post(agent, "/api/auth/logout", status.body.csrfToken).expect(403);
  await post(agent, "/api/auth/logout", active.body.csrfToken).expect(204);
  // Clearing the browser cookie alone is not logout. Replaying the old signed
  // session must fail because the server-owned session was destroyed.
  await request(app).get("/api/foundation").set("Host", "foundation.test").set("Cookie", activeCookie).expect(401);
  await get(agent, "/api/foundation").expect(401);
  assert.equal((await get(agent, "/api/auth/status").expect(200)).body.sessionActive, false);
});
for (const mode of ["disabled", "entra"]) {
  test(`${mode} cannot fall back to demo or grant data access`, async () => {
    const agent = request.agent(createApp({ ...env, AUTH_MODE: mode }));
    const status = await get(agent, "/api/auth/status").expect(200);
    assert.equal(status.body.demoAvailable, false);
    assert.equal(status.body.sessionActive, false);
    await post(agent, "/api/auth/demo", status.body.csrfToken).expect(403);
    await get(agent, "/api/foundation").expect(401);
  });
}

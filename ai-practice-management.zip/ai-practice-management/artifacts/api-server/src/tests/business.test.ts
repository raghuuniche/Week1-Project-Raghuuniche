import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { spawn, type ChildProcess } from "node:child_process";
import { once } from "node:events";
import { fileURLToPath } from "node:url";
import request from "supertest";
import { and, eq, sql } from "drizzle-orm";
import { createApp } from "../app";
import { requireTestDatabase } from "./test-database";
import { DatabaseSessionStore } from "../auth/session-store";
import { moneyUnits, validCalendarDate } from "../business/validation";
import { summarize } from "../business/summary";

const connection = requireTestDatabase();
const env = { NODE_ENV: "test", AUTH_MODE: "entra", SESSION_SECRET: "synthetic-session-secret-only-for-isolated-tests-32" };
const host = "foundation.test";
const issuer = `https://synthetic.invalid/${randomUUID()}`;
type Agent = ReturnType<typeof request.agent>;
async function login(subject: string) {
  // This route exists ONLY in this test-created app, not createApp()/index.
  const app = createApp(env, (app) => app.post("/api/__synthetic/session", (req, res, next) => {
    req.session.regenerate((error) => {
      if (error) { next(error); return; }
      req.session.identity = { kind: "provider", issuer, subject };
      req.session.save((error) => { if (error) next(error); else res.status(204).end(); });
    });
  }));
  const agent = request.agent(app);
  const session = await agent.post("/api/__synthetic/session").set("Host", host).expect(204);
  const status = await agent.get("/api/auth/status").set("Host", host).expect(200);
  const cookie = ((session.headers["set-cookie"] as unknown as string[]) ?? []).map((c) => c.split(";")[0]).join("; ");
  return { agent, token: status.body.csrfToken as string, cookie };
}
function get(agent: Agent, path: string) { return agent.get(path).set("Host", host); }
function mutate(auth: { agent: Agent; token: string }, method: "post" | "patch" | "delete", path: string, body: object) {
  return auth.agent[method](path).set("Host", host).set("Origin", `http://${host}`).set("X-CSRF-Token", auth.token).send(body);
}
const base = (p: string) => `/api/workspace/practices/${p}`;

test("shared business: verified scopes, atomic imports, conflicts, retained history and restart persistence", async (t) => {
  const schema = await import("@workspace/db");
  const { db, pool, organizations, practices, users, identityLinks, practiceMemberships, businessRecords, businessAudits, businessImports, globalAdministratorGrants } = schema;
  let server: ChildProcess | undefined;
  try {
    const [organization] = await db.insert(organizations).values({ name: "Synthetic shared verification" }).returning();
    const [otherOrg] = await db.insert(organizations).values({ name: "Synthetic isolated organization" }).returning();
    const [practice] = await db.insert(practices).values({ organizationId: organization.id, name: "Synthetic practice", slug: randomUUID(), currency: "USD", reportingTimeZone: "America/Los_Angeles" }).returning();
    const [otherPractice] = await db.insert(practices).values({ organizationId: otherOrg.id, name: "Synthetic other practice", slug: randomUUID(), currency: "EUR" }).returning();
    const ids: Record<string, string> = {};
    for (const role of ["practice_director", "manager", "team_member", "other_team", "executive", "administrator", "admin_member", "outsider"]) {
      const [user] = await db.insert(users).values({}).returning();
      ids[role] = user.id;
      await db.insert(identityLinks).values({ userId: user.id, issuer, subject: user.id });
      if (!["administrator", "outsider"].includes(role)) await db.insert(practiceMemberships).values({ userId: user.id, practiceId: practice.id,
        role: role === "other_team" ? "team_member" : role === "admin_member" ? "administrator" : role as "practice_director" | "manager" | "team_member" | "executive" });
    }
    await db.insert(practiceMemberships).values({ userId: ids.executive, practiceId: otherPractice.id, role: "executive" });
    await db.insert(globalAdministratorGrants).values({ userId: ids.administrator, grantedByOperator: "synthetic test operator" });
    const director = await login(ids.practice_director), secondDirector = await login(ids.practice_director);
    const manager = await login(ids.manager), team = await login(ids.team_member), executive = await login(ids.executive);
    const administrator = await login(ids.administrator), adminMember = await login(ids.admin_member), outsider = await login(ids.outsider);
    const pipeline = (name: string) => ({ kind: "pipeline", name, client: "Synthetic client", assignedUserId: ids.manager, dueDate: "2026-10-10", stage: "Discovery", value: "123.45", probability: 50 });
    const delivery = { kind: "delivery", name: "Synthetic assigned delivery", client: "Synthetic client", assignedUserId: ids.team_member, dueDate: "2026-10-10", status: "On track", budget: "500.00", burn: "100.00" };
    const goal = { kind: "goal", name: "Synthetic goal", assignedUserId: ids.team_member, dueDate: "2026-10-10", current: "1.50", target: "2.00", unit: "units" };
    let opportunityId = "", deliveryId = "";
    await t.test("authentication cannot be spoofed and demo never reads business data", async () => {
      const unsigned = request.agent(createApp(env));
      await get(unsigned, "/api/workspace").set("X-User", ids.practice_director).set("X-Role", "practice_director").expect(401);
      const demo = request.agent(createApp({ ...env, AUTH_MODE: "demo" }));
      const status = await get(demo, "/api/auth/status");
      await mutate({ agent: demo, token: status.body.csrfToken }, "post", "/api/auth/demo", {}).expect(200);
      await get(demo, "/api/workspace").expect(403);
      await get(administrator.agent, "/api/workspace").expect(200).then((r) => assert.deepEqual(r.body.practices, []));
      await get(administrator.agent, `${base(practice.id)}/records?kind=delivery`).expect(403);
      await get(adminMember.agent, `${base(practice.id)}/summary`).expect(403);
      await get(outsider.agent, `${base(practice.id)}/records?kind=pipeline`).expect(403);
      const access = await get(executive.agent, "/api/workspace").expect(200);
      assert.equal(access.body.practices.length, 2);
      await get(director.agent, `${base(otherPractice.id)}/summary`).expect(403);
    });
    await t.test("role writes, validation, explicit failures and cross-session reads", async () => {
      const created = await mutate(director, "post", `${base(practice.id)}/records`, pipeline("Synthetic opportunity")).expect(201);
      opportunityId = created.body.id;
      assert.equal(created.body.value, "123.45");
      const otherRead = await get(secondDirector.agent, `${base(practice.id)}/records/${opportunityId}`).expect(200);
      assert.equal(otherRead.body.id, opportunityId);
      await mutate(executive, "post", `${base(practice.id)}/records`, pipeline("Executive forbidden")).expect(403);
      await mutate(manager, "post", `${base(practice.id)}/records`, goal).expect(403);
      await mutate(director, "post", `${base(practice.id)}/records`, { ...pipeline("Invalid owner"), assignedUserId: ids.outsider }).expect(422);
      await mutate(director, "post", `${base(practice.id)}/records`, { ...pipeline("Invalid date"), dueDate: "2026-02-30" }).expect(422);
      await mutate(director, "post", `${base(practice.id)}/records`, { ...pipeline("Invalid money"), value: "1.001" }).expect(422);
      await mutate(director, "post", `${base(practice.id)}/records`, { ...pipeline("Scope injection"), practiceId: otherPractice.id }).expect(422);
      const createdDelivery = await mutate(manager, "post", `${base(practice.id)}/records`, delivery).expect(201);
      deliveryId = createdDelivery.body.id;
      await mutate(manager, "delete", `${base(practice.id)}/records/${deliveryId}`, { version: 1 }).expect(403);
      await mutate(director, "post", `${base(practice.id)}/records`, goal).expect(201);
      await get(executive.agent, `${base(otherPractice.id)}/records/${opportunityId}`).expect(404);
      await director.agent.post(`${base(practice.id)}/records`).set("Host", host).set("Origin", "http://attacker.invalid").set("X-CSRF-Token", director.token).send(pipeline("CSRF forbidden")).expect(403);
    });
    await t.test("team assignment boundaries omit financial fields and forbid aggregate reports", async () => {
      await mutate(director, "post", `${base(practice.id)}/records`, { ...delivery, name: "Synthetic other assignment", assignedUserId: ids.other_team }).expect(201);
      await get(team.agent, `${base(practice.id)}/records?kind=pipeline`).expect(403);
      await get(team.agent, `${base(practice.id)}/records/${opportunityId}`).expect(404);
      const own = await get(team.agent, `${base(practice.id)}/records?kind=delivery`).expect(200);
      assert.equal(own.body.length, 1);
      for (const key of ["value", "budget", "burn", "client", "organizationId"]) assert.equal(Object.hasOwn(own.body[0], key), false);
      const others = await get(director.agent, `${base(practice.id)}/records?kind=delivery`);
      const otherId = others.body.find((r: { id: string }) => r.id !== deliveryId).id;
      await get(team.agent, `${base(practice.id)}/records/${otherId}`).expect(404);
      await mutate(team, "patch", `${base(practice.id)}/records/${otherId}`, { version: 1, status: "Complete" }).expect(403);
      await mutate(team, "patch", `${base(practice.id)}/records/${deliveryId}`, { version: 1, record: { ...delivery, budget: "1.00" } }).expect(403);
      await mutate(team, "patch", `${base(practice.id)}/records/${deliveryId}`, { version: 1, status: "At risk" }).expect(200);
      await mutate(team, "patch", `${base(practice.id)}/records/${deliveryId}`, { version: 1, status: "Complete" }).expect(409);
      await get(team.agent, `${base(practice.id)}/summary?report=true`).expect(403);
      const summary = await get(team.agent, `${base(practice.id)}/summary`).expect(200);
      assert.equal(summary.body.deliveryCount, 1);
      assert.equal(Object.hasOwn(summary.body, "openValue"), false);
      const ownGoals = await get(team.agent, `${base(practice.id)}/records?kind=goal`).expect(200);
      assert.equal(ownGoals.body.length, 1);
    });
    await t.test("concurrent edits cannot overwrite newer work and history is attributable", async () => {
      const results = await Promise.all([
        mutate(director, "patch", `${base(practice.id)}/records/${opportunityId}`, { version: 1, record: { ...pipeline("Synthetic opportunity"), value: "200.00" } }),
        mutate(secondDirector, "patch", `${base(practice.id)}/records/${opportunityId}`, { version: 1, record: { ...pipeline("Synthetic opportunity"), value: "300.00" } }),
      ]);
      assert.deepEqual(results.map((r) => r.status).sort(), [200, 409]);
      const changes = await db.select().from(businessAudits).where(eq(businessAudits.recordId, opportunityId));
      assert.equal(changes.length, 2);
      assert.ok(changes.every((r) => r.actorUserId === ids.practice_director));
      assert.ok(changes.find((r) => r.action === "update")?.before);
    });
    await t.test("invalid imports roll back all rows, duplicates and concurrent retries commit once", async () => {
      const invalidKey = randomUUID();
      await mutate(director, "post", `${base(practice.id)}/imports`, { key: invalidKey, rows: [pipeline("Rollback first"), { ...pipeline("Rollback second"), assignedUserId: ids.outsider }] }).expect(422);
      const rolledBack = await db.select().from(businessRecords).where(and(eq(businessRecords.practiceId, practice.id), eq(businessRecords.name, "Rollback first")));
      assert.equal(rolledBack.length, 0);
      assert.equal((await db.select().from(businessImports).where(eq(businessImports.key, invalidKey))).length, 0);
      const key = randomUUID();
      const rows = [pipeline(" Concurrent   import "), { ...pipeline("concurrent import"), client: " SYNTHETIC   CLIENT " }];
      const responses = await Promise.all([
        mutate(director, "post", `${base(practice.id)}/imports`, { key, rows }),
        mutate(secondDirector, "post", `${base(practice.id)}/imports`, { key, rows }),
      ]);
      for (const response of responses) { assert.equal(response.status, 200); assert.deepEqual(response.body, { inserted: 1, skipped: 1 }); }
      const duplicate = await mutate(manager, "post", `${base(practice.id)}/imports`, { key: randomUUID(), rows: [pipeline("CONCURRENT IMPORT")] }).expect(200);
      assert.deepEqual(duplicate.body, { inserted: 0, skipped: 1 });
      await mutate(director, "post", `${base(practice.id)}/imports`, { key, rows: [pipeline("different payload")] }).expect(409);
      await mutate(director, "post", `${base(practice.id)}/imports`, { key: randomUUID(), rows: Array.from({ length: 1001 }, () => pipeline("too many")) }).expect(422);
      await mutate(director, "post", `${base(practice.id)}/records`, pipeline("CONCURRENT IMPORT")).expect(409);
      const winner = await Promise.all([
        mutate(director, "post", `${base(practice.id)}/imports`, { key: randomUUID(), rows: [pipeline("Import entry race")] }),
        mutate(manager, "post", `${base(practice.id)}/records`, pipeline("Import entry race")),
      ]);
      assert.equal(winner[0].status, 200);
      assert.ok([201, 409].includes(winner[1].status));
      assert.equal((await db.select().from(businessRecords).where(and(eq(businessRecords.practiceId, practice.id), eq(businessRecords.nameKey, "import entry race")))).length, 1);
    });
    await t.test("summary uses exact decimals, inclusive date filters and no revenue claim", async () => {
      assert.equal(moneyUnits("123.45"), 12345n);
      assert.equal(validCalendarDate("2026-02-30"), false);
      const full = await get(executive.agent, `${base(practice.id)}/summary?from=2026-10-10&to=2026-10-10&report=true`).expect(200);
      assert.equal(full.body.openCount, 3);
      assert.equal(full.body.deliveryRiskCount, 1);
      assert.equal(full.body.currency, "USD");
      assert.equal(full.body.reportingTimeZone, "America/Los_Angeles");
      const portfolio = await get(executive.agent, "/api/workspace/summary?from=2026-10-10&to=2026-10-10").expect(200);
      assert.equal(portfolio.body.practiceCount, 2);
      assert.equal(portfolio.body.groups.length, 2);
      assert.equal(portfolio.body.groups.find((g: { currency: string }) => g.currency === "USD").openCount, 3);
      assert.equal(portfolio.body.groups.find((g: { currency: string }) => g.currency === "EUR").openValue, "0.00");
      await get(team.agent, "/api/workspace/summary").expect(403);
      await get(director.agent, "/api/workspace/summary").expect(403);
      const empty = await get(executive.agent, `${base(practice.id)}/summary?from=2026-10-11`).expect(200);
      assert.equal(empty.body.openValue, "0.00");
      await get(executive.agent, `${base(practice.id)}/summary?from=2026-02-30`).expect(400);
      await get(executive.agent, `${base(practice.id)}/summary?from=2026-10-11&to=2026-10-10`).expect(400);
      const rows = await db.select().from(businessRecords).where(eq(businessRecords.id, opportunityId));
      const half = summarize([{ ...rows[0], value: "0.01", probability: 50 }], false);
      assert.equal("weightedValue" in half && half.weightedValue, "0.01");
    });
    await t.test("retained deletion disappears from lists and totals and stale deletion is rejected", async () => {
      const before = await get(director.agent, `${base(practice.id)}/records/${opportunityId}`);
      await mutate(director, "delete", `${base(practice.id)}/records/${opportunityId}`, { version: 1 }).expect(409);
      await mutate(director, "delete", `${base(practice.id)}/records/${opportunityId}`, { version: before.body.version }).expect(204);
      await get(director.agent, `${base(practice.id)}/records/${opportunityId}`).expect(404);
      const [retained] = await db.select().from(businessRecords).where(eq(businessRecords.id, opportunityId));
      assert.ok(retained.deletedAt);
      const changes = await db.select().from(businessAudits).where(eq(businessAudits.recordId, opportunityId));
      assert.ok(changes.find((r) => r.action === "delete")?.before);
      const after = await get(director.agent, `${base(practice.id)}/summary`).expect(200);
      assert.equal(after.body.openCount, 2);
    });
    await t.test("signed database sessions and committed records survive a real API process restart", async () => {
      const entry = fileURLToPath(new URL("../index.ts", import.meta.url));
      const port = 25441;
      async function startServer() {
        const child = spawn(process.execPath, ["--import", "tsx", entry], { env: { ...process.env, ...env, DATABASE_URL: connection, PORT: String(port) }, stdio: "ignore" });
        for (let i = 0; i < 60; i++) {
          if (child.exitCode !== null) throw new Error("Synthetic restart server exited");
          try { if ((await fetch(`http://127.0.0.1:${port}/api/healthz`)).ok) return child; } catch { /* wait for owned loopback process */ }
          await new Promise((r) => setTimeout(r, 100));
        }
        child.kill("SIGKILL");
        throw new Error("Synthetic restart server not ready");
      }
      server = await startServer();
      const read = async (cookie: string) => fetch(`http://127.0.0.1:${port}${base(practice.id)}/records?kind=delivery`, { headers: { Cookie: cookie } });
      const first = await read(director.cookie);
      assert.equal(first.status, 200);
      assert.equal((await first.json() as unknown[]).length, 2);
      const stopped = once(server, "exit"); server.kill("SIGTERM"); await stopped; server = undefined;
      server = await startServer();
      const after = await read(secondDirector.cookie);
      assert.equal(after.status, 200);
      assert.equal((await after.json() as unknown[]).length, 2);
      const store = new DatabaseSessionStore();
      await new Promise<void>((resolve, reject) => store.destroy("synthetic-nonexistent-id", (error) => error ? reject(error) : resolve()));
      await db.update(practiceMemberships).set({ active: false }).where(and(eq(practiceMemberships.userId, ids.practice_director), eq(practiceMemberships.practiceId, practice.id)));
      assert.equal((await read(director.cookie)).status, 403);
      await db.update(users).set({ status: "disabled" }).where(eq(users.id, ids.manager));
      await get(manager.agent, "/api/workspace").expect(401);
      const disabledStatus = await get(manager.agent, "/api/auth/status").expect(200);
      assert.equal(disabledStatus.body.sessionActive, false);
      await mutate(team, "post", "/api/auth/logout", {}).expect(204);
      await get(team.agent, `${base(practice.id)}/records?kind=delivery`).expect(401);
      await db.execute(sql`UPDATE authentication_sessions SET expires_at = now() - interval '1 second'`);
      assert.equal((await read(secondDirector.cookie)).status, 401);
    });
  } finally {
    if (server && server.exitCode === null) { const stopped = once(server, "exit"); server.kill("SIGTERM"); await stopped; }
    await pool.end();
  }
});

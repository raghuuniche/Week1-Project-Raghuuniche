// Never fall back to the application's DATABASE_URL, even for disposable schemas.
export function requireTestDatabase(): string {
  const value = process.env.FOUNDATION_TEST_DATABASE_URL;
  if (!value) throw new Error("FOUNDATION_TEST_DATABASE_URL is required; application DATABASE_URL is not a test target.");
  const url = new URL(value);
  if (
    process.env.NODE_ENV === "production" ||
    process.env.REPLIT_DEPLOYMENT === "1" ||
    !["postgres:", "postgresql:"].includes(url.protocol) ||
    !["127.0.0.1", "localhost"].includes(url.hostname) ||
    !/^\/foundation_test_[a-z0-9_]+$/.test(url.pathname) ||
    !url.port || url.port === "5432" ||
    url.search || url.hash
  ) throw new Error("Tests require a dedicated loopback PostgreSQL port and foundation_test_* database, never production.");
  return value;
}

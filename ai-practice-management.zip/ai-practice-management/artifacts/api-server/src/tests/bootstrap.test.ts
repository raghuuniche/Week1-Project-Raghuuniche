import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import pg from "pg";
import { bootstrapFirstAdministrator, validateBootstrapInput } from "@workspace/db/bootstrap";
import { requireTestDatabase } from "./test-database";

const input = {
  tenantId: "11111111-1111-1111-1111-111111111111",
  objectId: "22222222-2222-2222-2222-222222222222",
  operator: "integration-test-operator",
  confirmed: true,
};
test("bootstrap refuses missing confirmation and demo identities before connecting", () => {
  assert.throws(() => validateBootstrapInput({ ...input, confirmed: false }));
  assert.throws(() => validateBootstrapInput({ ...input, objectId: "demo-practice" }));
  assert.throws(() => validateBootstrapInput({ ...input, tenantId: "" }));
  assert.throws(() => validateBootstrapInput({ ...input, operator: "" }));
});
test("real PostgreSQL transactions serialize concurrent bootstrap and preserve the durable singleton", async () => {
  const connectionString = requireTestDatabase();
  // All writes are isolated in a disposable namespace, never live identities.
  const schema = `foundation_test_${randomUUID().replaceAll("-", "")}`;
  const management = new pg.Pool({ connectionString, connectionTimeoutMillis: 5_000 });
  const isolated = new pg.Pool({ connectionString, options: `-c search_path=${schema},public`, connectionTimeoutMillis: 5_000 });
  try {
    await management.query(`CREATE SCHEMA "${schema}"`);
    for (const table of ["users", "identity_links", "global_administrator_grants", "administrator_bootstrap_audits", "practice_memberships"]) {
      await management.query(`CREATE TABLE "${schema}"."${table}" (LIKE public."${table}" INCLUDING ALL)`);
    }
    const results = await Promise.allSettled([
      bootstrapFirstAdministrator(isolated, input),
      bootstrapFirstAdministrator(isolated, { ...input, objectId: "33333333-3333-3333-3333-333333333333" }),
    ]);
    assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
    assert.equal(results.filter((r) => r.status === "rejected").length, 1);
    const counts = await isolated.query("SELECT (SELECT count(*) FROM users)::int AS users, (SELECT count(*) FROM identity_links)::int AS links, (SELECT count(*) FROM global_administrator_grants)::int AS grants, (SELECT count(*) FROM administrator_bootstrap_audits)::int AS audits, (SELECT count(*) FROM practice_memberships)::int AS memberships");
    assert.deepEqual(counts.rows[0], { users: 1, links: 1, grants: 1, audits: 1, memberships: 0 });
    await assert.rejects(bootstrapFirstAdministrator(isolated, input), /already completed/);
    await isolated.query("DELETE FROM global_administrator_grants");
    await assert.rejects(bootstrapFirstAdministrator(isolated, input), /already completed/);
    await assert.rejects(isolated.query("INSERT INTO administrator_bootstrap_audits (singleton, administrator_user_id, provider_issuer, provider_subject, created_by_operator) SELECT 2, administrator_user_id, provider_issuer, provider_subject, created_by_operator FROM administrator_bootstrap_audits"));
    // Approved five roles, enforced in the relational schema.
    for (const role of ["executive", "practice_director", "manager", "team_member", "administrator"]) {
      await isolated.query("INSERT INTO practice_memberships (user_id, practice_id, role) VALUES ($1, $2, $3)", [randomUUID(), randomUUID(), role]);
    }
    await assert.rejects(isolated.query("INSERT INTO practice_memberships (user_id, practice_id, role) VALUES ($1, $2, $3)", [randomUUID(), randomUUID(), "practice_lead"]));
  } finally {
    await isolated.end();
    await management.query(`DROP SCHEMA IF EXISTS "${schema}" CASCADE`);
    await management.end();
  }
});

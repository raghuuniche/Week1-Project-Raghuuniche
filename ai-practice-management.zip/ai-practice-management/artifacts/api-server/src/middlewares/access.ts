import { timingSafeEqual } from "node:crypto";
import type { NextFunction, Request, Response } from "express";

export function requireAuthentication(req: Request, res: Response, next: NextFunction) {
  if (!req.session.identity) {
    res.status(401).json({ error: "authentication_required" });
    return;
  }
  next();
}
export function requireCsrf(req: Request, res: Response, next: NextFunction) {
  const origin = req.get("origin");
  const host = req.get("host");
  try {
    const parsed = origin ? new URL(origin) : null;
    if (!parsed || !host || parsed.host !== host || parsed.protocol !== `${req.protocol}:`) {
      res.status(403).json({ error: "csrf_origin_mismatch" });
      return;
    }
  } catch {
    res.status(403).json({ error: "csrf_origin_invalid" });
    return;
  }
  const supplied = Buffer.from(req.get("x-csrf-token") ?? "");
  const expected = Buffer.from(req.session.csrfToken ?? "");
  if (!expected.length || supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) {
    res.status(403).json({ error: "csrf_token_invalid" });
    return;
  }
  next();
}

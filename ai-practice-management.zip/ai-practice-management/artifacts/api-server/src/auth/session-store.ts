import { createHash } from "node:crypto";
import session from "express-session";
import { and, eq, gt } from "drizzle-orm";

// No startup DDL and no live connection in demo mode. The identity adapter
// uses the same signed-cookie sessions; it must rotate the ID after verification.
export class DatabaseSessionStore extends session.Store {
  private hash(id: string) { return createHash("sha256").update(id).digest("hex"); }

  get(id: string, callback: (error: unknown, value?: session.SessionData | null) => void) {
    void (async () => {
      const { db, authenticationSessions: table } = await import("@workspace/db");
      const [row] = await db.select().from(table).where(and(eq(table.idHash, this.hash(id)), gt(table.expiresAt, new Date())));
      return row ? row.data as session.SessionData : null;
    })().then((value) => callback(null, value), callback);
  }

  set(id: string, value: session.SessionData, callback?: (error?: unknown) => void) {
    void (async () => {
      const { db, authenticationSessions: table } = await import("@workspace/db");
      const expiresAt = value.cookie.expires ? new Date(value.cookie.expires) : new Date(Date.now() + 3_600_000);
      const row = { idHash: this.hash(id), data: JSON.parse(JSON.stringify(value)), expiresAt };
      await db.insert(table).values(row).onConflictDoUpdate({ target: table.idHash, set: { data: row.data, expiresAt } });
    })().then(() => callback?.(), (error) => callback?.(error));
  }

  destroy(id: string, callback?: (error?: unknown) => void) {
    void (async () => {
      const { db, authenticationSessions: table } = await import("@workspace/db");
      await db.delete(table).where(eq(table.idHash, this.hash(id)));
    })().then(() => callback?.(), (error) => callback?.(error));
  }
}

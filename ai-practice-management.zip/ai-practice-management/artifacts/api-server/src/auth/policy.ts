import { DEMO_PRACTICE_ID, type AuthenticatedIdentity } from "./identity";

export type PracticeAccess =
  | { allowed: true; practiceId: string; role: string; synthetic: boolean }
  | { allowed: false; reason: "identity_required" | "no_membership" | "wrong_demo_scope" | "role_denied" };
export async function resolvePracticeAccess(
  identity: AuthenticatedIdentity | null,
  practiceId: string,
  findMembership: (identity: AuthenticatedIdentity, practiceId: string) => Promise<string | null>,
  requiredRoles: readonly string[] = [],
): Promise<PracticeAccess> {
  if (!identity) return { allowed: false, reason: "identity_required" };
  if (identity.kind === "demo") {
    if (practiceId !== DEMO_PRACTICE_ID) return { allowed: false, reason: "wrong_demo_scope" };
    if (requiredRoles.length && !requiredRoles.includes(identity.role)) return { allowed: false, reason: "role_denied" };
    return { allowed: true, practiceId, role: identity.role, synthetic: true };
  }
  const role = await findMembership(identity, practiceId);
  if (!role) return { allowed: false, reason: "no_membership" };
  if (requiredRoles.length && !requiredRoles.includes(role)) return { allowed: false, reason: "role_denied" };
  return { allowed: true, practiceId, role, synthetic: false };
}

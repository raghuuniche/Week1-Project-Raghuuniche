import { and, eq } from "drizzle-orm";
import type { AuthenticatedIdentity } from "./identity";
import { resolvePracticeAccess } from "./policy";

export async function authorizePractice(identity: AuthenticatedIdentity | null, practiceId: string, roles: readonly string[] = []) {
  return resolvePracticeAccess(identity, practiceId, async (user, scope) => {
    if (user.kind !== "provider") return null;
    // Lazy import: synthetic demo requests never open or query the real DB.
    const { db, identityLinks, users, practiceMemberships } = await import("@workspace/db");
    const [membership] = await db.select({ role: practiceMemberships.role })
      .from(identityLinks)
      .innerJoin(users, and(eq(users.id, identityLinks.userId), eq(users.status, "active")))
      .innerJoin(practiceMemberships, and(eq(practiceMemberships.userId, users.id), eq(practiceMemberships.practiceId, scope), eq(practiceMemberships.active, true)))
      .where(and(eq(identityLinks.issuer, user.issuer), eq(identityLinks.subject, user.subject))).limit(1);
    return membership?.role ?? null;
  }, roles);
}
export async function hasGlobalAdministratorGrant(identity: AuthenticatedIdentity | null): Promise<boolean> {
  if (!identity || identity.kind !== "provider") return false;
  const { db, identityLinks, users, globalAdministratorGrants } = await import("@workspace/db");
  const [grant] = await db.select({ userId: users.id }).from(identityLinks)
    .innerJoin(users, and(eq(users.id, identityLinks.userId), eq(users.status, "active")))
    .innerJoin(globalAdministratorGrants, eq(globalAdministratorGrants.userId, users.id))
    .where(and(eq(identityLinks.issuer, identity.issuer), eq(identityLinks.subject, identity.subject))).limit(1);
  return Boolean(grant);
}

export type AuthMode = "disabled" | "demo" | "entra";
export type AuthConfig = {
  mode: AuthMode;
  demoAvailable: boolean;
  reason: "AUTH_DISABLED" | "ENTRA_NOT_IMPLEMENTED" | null;
};
export function readAuthConfig(env: NodeJS.ProcessEnv = process.env): AuthConfig {
  const mode = env.AUTH_MODE ?? "disabled";
  if (!["disabled", "demo", "entra"].includes(mode)) {
    throw new Error("AUTH_MODE must be disabled, demo, or entra.");
  }
  if (mode === "demo" && (env.NODE_ENV === "production" || env.REPLIT_DEPLOYMENT === "1")) {
    throw new Error("Demo mode is prohibited in production.");
  }
  if (mode === "demo" && env.NODE_ENV !== "development" && env.NODE_ENV !== "test") {
    throw new Error("Demo mode requires an explicit development or test environment.");
  }
  return {
    mode: mode as AuthMode,
    demoAvailable: mode === "demo",
    reason: mode === "disabled" ? "AUTH_DISABLED" : mode === "entra" ? "ENTRA_NOT_IMPLEMENTED" : null,
  };
}

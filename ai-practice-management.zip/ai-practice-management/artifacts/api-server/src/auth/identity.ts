export const DEMO_PRACTICE_ID = "demo-practice";
export const DEMO_IDENTITY = Object.freeze({
  kind: "demo" as const,
  displayName: "Pilot User",
  role: "practice_director" as const,
  practiceId: DEMO_PRACTICE_ID,
});
// The future adapter must validate signature, issuer, audience, expiry, nonce,
// state and tenant before creating this identity. Never derive it from headers.
// subject is the validated Entra object ID (oid), scoped by the tenant issuer.
export type ProviderIdentity = { kind: "provider"; issuer: string; subject: string };
export type AuthenticatedIdentity = typeof DEMO_IDENTITY | ProviderIdentity;
declare module "express-session" {
  interface SessionData {
    identity?: AuthenticatedIdentity;
    csrfToken?: string;
  }
}

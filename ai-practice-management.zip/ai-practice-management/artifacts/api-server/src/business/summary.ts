import type { BusinessRecord } from "@workspace/db";
import { moneyText, moneyUnits } from "./validation";

// All money arithmetic uses integer hundredths; round weighted TOTAL once,
// half-up to a hundredth. Pipeline outcomes/budgets are not booked revenue.
export function summarize(rows: BusinessRecord[], team: boolean) {
  const delivery = rows.filter((r) => r.kind === "delivery");
  const goals = rows.filter((r) => r.kind === "goal");
  const base = {
    deliveryCount: delivery.length,
    deliveryRiskCount: delivery.filter((r) => r.status === "At risk" || r.status === "Off track").length,
    goalCount: goals.length,
    goalsMet: goals.filter((r) => moneyUnits(r.current!) >= moneyUnits(r.target!)).length,
  };
  if (team) return base;
  const pipeline = rows.filter((r) => r.kind === "pipeline");
  const open = pipeline.filter((r) => r.stage !== "Won" && r.stage !== "Lost");
  const sum = (rs: BusinessRecord[], key: "value" | "budget" | "burn") => moneyText(rs.reduce((total, r) => total + moneyUnits(r[key]!), 0n));
  return { ...base, openCount: open.length, openValue: sum(open, "value"),
    weightedValue: moneyText((open.reduce((n, r) => n + moneyUnits(r.value!) * BigInt(r.probability!), 0n) + 50n) / 100n),
    wonValue: sum(pipeline.filter((r) => r.stage === "Won"), "value"),
    lostValue: sum(pipeline.filter((r) => r.stage === "Lost"), "value"),
    deliveryBudget: sum(delivery, "budget"), deliveryBurn: sum(delivery, "burn") };
}

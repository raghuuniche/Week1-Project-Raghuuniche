import { CreateWorkspaceRecordBody, ImportWorkspacePipelineBody, UpdateWorkspaceRecordBody, DeleteWorkspaceRecordBody } from "@workspace/api-zod";

export class BusinessError extends Error {
  constructor(public status: number, public code: string) { super(code); }
}
export const normalizeDuplicateKey = (text: string) => text.normalize("NFKC").trim().replace(/\s+/g, " ").toLowerCase();
export const validCalendarDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value) &&
  Number.isFinite(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
const decimal = /^(?:0|[1-9]\d{0,13})(?:\.\d{1,2})?$/;
const string = CreateWorkspaceRecordBody.shape.name;
export const recordInputSchema = CreateWorkspaceRecordBody.extend({
  name: string.trim().min(1),
  dueDate: string.refine(validCalendarDate, "Use a valid YYYY-MM-DD calendar date"),
  client: string.trim().min(1).optional(),
  unit: string.trim().min(1).max(80).optional(),
}).strict().superRefine((row, ctx) => {
  const fields = row.kind === "pipeline" ? ["client", "stage", "value", "probability"] :
    row.kind === "delivery" ? ["client", "status", "budget", "burn"] : ["current", "target", "unit"];
  const extra = ["client", "stage", "value", "probability", "status", "budget", "burn", "current", "target", "unit"];
  for (const key of extra) {
    const value = row[key as keyof typeof row];
    if (fields.includes(key) ? value === undefined : value !== undefined) {
      ctx.addIssue({ code: "custom", path: [key], message: "Missing or inapplicable field" });
    }
  }
  for (const key of ["value", "budget", "burn", "current", "target"] as const) {
    const value = row[key];
    if (value !== undefined && (!decimal.test(value) || (key === "target" && Number(value) <= 0))) {
      ctx.addIssue({ code: "custom", path: [key], message: "Use a nonnegative decimal with at most 2 fractional digits; target must be positive" });
    }
  }
});
export const importInputSchema = ImportWorkspacePipelineBody.extend({ rows: recordInputSchema.array().min(1).max(1000) }).strict()
  .refine((data) => data.rows.every((row) => row.kind === "pipeline"), "Pipeline rows only");
export const updateInputSchema = UpdateWorkspaceRecordBody.extend({ record: recordInputSchema.optional() }).strict();
export const deleteInputSchema = DeleteWorkspaceRecordBody.strict();
export type RecordInput = ReturnType<typeof recordInputSchema.parse>;
export function parseInput<T>(schema: { safeParse: (value: unknown) => { success: true; data: T } | { success: false } }, value: unknown): T {
  const result = schema.safeParse(value);
  if (!result.success) throw new BusinessError(422, "invalid_record");
  return result.data;
}
export function requireUuid(value: unknown): string {
  if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) throw new BusinessError(400, "invalid_identifier");
  return value;
}
export const moneyUnits = (value: string) => {
  const [whole, fraction = ""] = value.split(".");
  return BigInt(whole) * 100n + BigInt(fraction.padEnd(2, "0"));
};
export const moneyText = (units: bigint) => `${units / 100n}.${String(units % 100n).padStart(2, "0")}`;

import { and, eq } from "drizzle-orm";
import type { Request } from "express";
import type { db as Db } from "@workspace/db";
import { BusinessError } from "./validation";

export type Transaction = Parameters<Parameters<typeof Db.transaction>[0]>[0];
export async function database() { return import("@workspace/db"); }
export function provider(req: Request) {
  const identity = req.session.identity;
  if (!identity) throw new BusinessError(401, "authentication_required");
  if (identity.kind !== "provider") throw new BusinessError(403, "verified_identity_required");
  return identity;
}
export async function resolveUser(req: Request, tx?: Transaction) {
  const identity = provider(req);
  const { db, identityLinks, users } = await database();
  const query = (tx ?? db).select({ userId: users.id }).from(users).innerJoin(identityLinks, eq(identityLinks.userId, users.id))
    .where(and(eq(users.status, "active"), eq(identityLinks.issuer, identity.issuer), eq(identityLinks.subject, identity.subject)));
  // Disable/revoke writes wait until a currently authorized transaction commits.
  const [user] = await (tx ? query.for("share", { of: users }) : query);
  if (!user) throw new BusinessError(401, "identity_inactive");
  return user.userId;
}
export async function practiceAccess(req: Request, practiceId: string, tx?: Transaction) {
  const userId = await resolveUser(req, tx);
  const { db, practices, practiceMemberships } = await database();
  const query = (tx ?? db).select({ practice: practices, role: practiceMemberships.role })
    .from(practiceMemberships).innerJoin(practices, eq(practices.id, practiceMemberships.practiceId))
    .where(and(eq(practiceMemberships.userId, userId), eq(practiceMemberships.practiceId, practiceId), eq(practiceMemberships.active, true)));
  const [row] = await (tx ? query.for("share", { of: practiceMemberships }) : query);
  if (!row || row.role === "administrator") throw new BusinessError(403, "practice_access_denied");
  return { ...row, userId };
}
export function requireWrite(role: string, kind: string, deletion = false) {
  const allowed = role === "practice_director" ||
    (role === "manager" && (kind === "pipeline" || (kind === "delivery" && !deletion)));
  if (!allowed) throw new BusinessError(403, "role_denied");
}
export async function requireAssignee(tx: Transaction, practiceId: string, userId: string) {
  const { users, practiceMemberships, identityLinks } = await database();
  const [row] = await tx.select({ id: users.id }).from(users)
    .innerJoin(practiceMemberships, and(eq(practiceMemberships.userId, users.id), eq(practiceMemberships.practiceId, practiceId), eq(practiceMemberships.active, true)))
    .innerJoin(identityLinks, eq(identityLinks.userId, users.id))
    .where(and(eq(users.id, userId), eq(users.status, "active")))
    .for("share", { of: [users, practiceMemberships] });
  if (!row) throw new BusinessError(422, "invalid_assignment");
  const [membership] = await tx.select().from(practiceMemberships).where(and(eq(practiceMemberships.userId, userId), eq(practiceMemberships.practiceId, practiceId)));
  if (membership.role === "administrator") throw new BusinessError(422, "invalid_assignment");
}

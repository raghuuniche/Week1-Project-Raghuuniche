import type { BusinessRecord } from "@workspace/db";
import type { WorkspaceRecord } from "@workspace/api-zod";
import { and, eq, isNull } from "drizzle-orm";
import { database, type Transaction } from "./access";
import { BusinessError, normalizeDuplicateKey, type RecordInput } from "./validation";

export function recordValues(row: RecordInput) {
  return { ...row, nameKey: row.kind === "pipeline" ? normalizeDuplicateKey(row.name) : null, clientKey: row.kind === "pipeline" ? normalizeDuplicateKey(row.client!) : null };
}
export function serializeRecord(row: BusinessRecord, role: string): WorkspaceRecord {
  const base = { id: row.id, practiceId: row.practiceId, version: row.version, kind: row.kind, name: row.name, assignedUserId: row.assignedUserId, dueDate: row.dueDate };
  if (row.kind === "pipeline") {
    if (role === "team_member") throw new BusinessError(403, "financial_access_denied");
    return { ...base, client: row.client!, stage: row.stage as WorkspaceRecord["stage"], value: row.value!, probability: row.probability! };
  }
  if (row.kind === "delivery") return { ...base, status: row.status as WorkspaceRecord["status"], ...(role === "team_member" ? {} : { client: row.client!, budget: row.budget!, burn: row.burn! }) };
  return { ...base, current: row.current!, target: row.target!, unit: row.unit! };
}
export async function audit(tx: Transaction, practiceId: string, actorUserId: string, action: string, before: BusinessRecord | null, after: BusinessRecord | null) {
  const { businessAudits } = await database();
  await tx.insert(businessAudits).values({ practiceId, actorUserId, action, recordId: after?.id ?? before?.id, before, after });
}
export async function findRecord(practiceId: string, id: string, tx?: Transaction) {
  const { db, businessRecords: table } = await database();
  const query = (tx ?? db).select().from(table).where(and(eq(table.practiceId, practiceId), eq(table.id, id), isNull(table.deletedAt)));
  const [row] = await (tx ? query.for("update") : query);
  if (!row) throw new BusinessError(404, "record_not_found");
  return row;
}

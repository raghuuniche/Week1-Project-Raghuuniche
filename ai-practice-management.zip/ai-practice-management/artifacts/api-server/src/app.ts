import express, { type Express, type ErrorRequestHandler } from "express";
import session from "express-session";
import helmet from "helmet";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { readAuthConfig } from "./auth/config";
import { createFoundationRouter } from "./routes/foundation";
import { createBusinessRouter } from "./routes/business";
import { DatabaseSessionStore } from "./auth/session-store";

export function createApp(env: NodeJS.ProcessEnv = process.env, installVerifiedIdentityAdapter?: (app: Express) => void): Express {
const config = readAuthConfig(env);
const secret = env.SESSION_SECRET;
if (!secret || secret.length < 32) throw new Error("SESSION_SECRET must be configured with at least 32 characters.");
const app: Express = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    autoLogging: env.NODE_ENV !== "test",
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(helmet());
app.use("/api/workspace", express.json({ limit: "5mb" }));
app.use(express.json({ limit: "16kb" }));
// This in-memory store is deliberately DEMO ONLY. Real authentication is
// deferred, so no persistent/live identity sessions are supported here.
app.use("/api", session({
  name: config.mode === "entra" ? "northstar.sid" : "northstar.demo.sid",
  store: config.mode === "entra" ? new DatabaseSessionStore() : undefined,
  secret,
  resave: false,
  saveUninitialized: false,
  cookie: { path: "/api", httpOnly: true, sameSite: "lax", secure: env.NODE_ENV === "production", maxAge: 60 * 60 * 1000 },
}));
// Integration seam for the separately commissioned Microsoft adapter. No
// provider identity is derived from headers, role pickers or a public fallback.
if (config.mode === "entra") installVerifiedIdentityAdapter?.(app);
app.use("/api", (req, _res, next) => {
  // Invalidate stale identities on any mode change. Provider verification is
  // not implemented and no incoming header can establish a provider identity.
  if ((config.mode === "demo" && req.session.identity?.kind !== "demo") ||
      (config.mode === "entra" && req.session.identity?.kind !== "provider") || config.mode === "disabled") {
    delete req.session.identity;
  }
  next();
});

app.use("/api", router);
app.use("/api", createFoundationRouter(config));
app.use("/api/workspace", createBusinessRouter());
app.use("/api", (_req, res) => { res.status(404).json({ error: "not_found" }); });
const errorHandler: ErrorRequestHandler = (error, req, res, _next) => {
  if (error?.type === "entity.too.large") { res.status(413).json({ error: "request_too_large" }); return; }
  if (error?.type === "entity.parse.failed") { res.status(400).json({ error: "invalid_json" }); return; }
  req.log.error("Request failed");
  if (!res.headersSent) res.status(500).json({ error: "internal_server_error" });
};
app.use(errorHandler);
return app;
}

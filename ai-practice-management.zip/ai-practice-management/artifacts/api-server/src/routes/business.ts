import { createHash } from "node:crypto";
import { Router, type Request, type Response, type NextFunction } from "express";
import { and, eq, gte, lte, inArray, isNull, sql } from "drizzle-orm";
import rateLimit from "express-rate-limit";
import { requireCsrf } from "../middlewares/access";
import { database, practiceAccess, provider, requireAssignee, requireWrite, resolveUser } from "../business/access";
import { audit, findRecord, recordValues, serializeRecord } from "../business/records";
import { BusinessError, deleteInputSchema, importInputSchema, parseInput, recordInputSchema, requireUuid, updateInputSchema, validCalendarDate } from "../business/validation";
import { summarize } from "../business/summary";

type Handler = (req: Request, res: Response, next: NextFunction) => Promise<void>;
const wrap = (handler: Handler): Handler => async (req, res, next) => {
  try { await handler(req, res, next); }
  catch (error) {
    if (error instanceof BusinessError) {
      if (error.status === 401 && req.session.identity?.kind === "provider") {
        // A disabled/de-linked identity must not remain "signed in" on the
        // status endpoint and re-enable protected queries in a retry loop.
        try {
          await new Promise<void>((resolve, reject) => req.session.destroy((failure) => failure ? reject(failure) : resolve()));
          res.clearCookie("northstar.sid", { path: "/api" });
        } catch (failure) { next(failure); return; }
      }
      res.status(error.status).json({ error: error.code }); return;
    }
    // Drizzle wraps PostgreSQL errors in a query error; never expose its SQL
    // or parameters while translating constraint failures.
    const failure = error as { code?: string; cause?: { code?: string } };
    const code = failure.code ?? failure.cause?.code;
    if (code === "23505") { res.status(409).json({ error: "duplicate_record" }); return; }
    if (code === "23503" || code === "23514") { res.status(422).json({ error: "invalid_record" }); return; }
    next(error);
  }
};
export function createBusinessRouter() {
  const router = Router();
  router.use((_req, res, next) => { res.setHeader("Cache-Control", "no-store"); next(); });
  router.use(wrap(async (req, _res, next) => { provider(req); next(); }));
  router.use(rateLimit({ windowMs: 60_000, limit: 300 }));
  router.get("/", wrap(async (req, res) => {
    const userId = await resolveUser(req);
    const { db, practiceMemberships, practices } = await database();
    const rows = await db.select({ id: practices.id, organizationId: practices.organizationId, name: practices.name, currency: practices.currency, reportingTimeZone: practices.reportingTimeZone, role: practiceMemberships.role })
      .from(practiceMemberships).innerJoin(practices, eq(practices.id, practiceMemberships.practiceId))
      .where(and(eq(practiceMemberships.userId, userId), eq(practiceMemberships.active, true)));
    res.json({ userId, practices: rows.filter((p) => p.role !== "administrator") });
  }));
  router.get("/summary", wrap(async (req, res) => {
    const userId = await resolveUser(req);
    const { db, practices, practiceMemberships, businessRecords: table } = await database();
    const allowed = await db.select({ practice: practices }).from(practiceMemberships)
      .innerJoin(practices, eq(practices.id, practiceMemberships.practiceId))
      .where(and(eq(practiceMemberships.userId, userId), eq(practiceMemberships.active, true), eq(practiceMemberships.role, "executive")));
    if (!allowed.length) throw new BusinessError(403, "executive_required");
    const from = req.query.from, to = req.query.to;
    if ((from !== undefined && (typeof from !== "string" || !validCalendarDate(from))) ||
        (to !== undefined && (typeof to !== "string" || !validCalendarDate(to))) ||
        (typeof from === "string" && typeof to === "string" && from > to)) throw new BusinessError(400, "invalid_date_range");
    const rows = await db.select().from(table).where(and(inArray(table.practiceId, allowed.map((a) => a.practice.id)), isNull(table.deletedAt),
      typeof from === "string" ? gte(table.dueDate, from) : undefined, typeof to === "string" ? lte(table.dueDate, to) : undefined));
    const groups = new Map<string, typeof allowed>();
    for (const p of allowed) {
      const key = JSON.stringify([p.practice.currency, p.practice.reportingTimeZone]);
      groups.set(key, [...(groups.get(key) ?? []), p]);
    }
    res.json({ practiceCount: allowed.length, groups: [...groups.values()].map((members) => ({
      currency: members[0].practice.currency, reportingTimeZone: members[0].practice.reportingTimeZone,
      ...summarize(rows.filter((r) => members.some((p) => p.practice.id === r.practiceId)), false),
    })) });
  }));
  router.use("/practices/:practiceId", wrap(async (req, _res, next) => { requireUuid(req.params.practiceId); next(); }));
  router.get("/practices/:practiceId/staff", wrap(async (req, res) => {
    const id = requireUuid(req.params.practiceId);
    const access = await practiceAccess(req, id);
    requireWrite(access.role, "pipeline");
    const { db, practiceMemberships, users, identityLinks } = await database();
    const rows = await db.selectDistinct({ userId: users.id, role: practiceMemberships.role }).from(users)
      .innerJoin(practiceMemberships, and(eq(practiceMemberships.userId, users.id), eq(practiceMemberships.practiceId, id), eq(practiceMemberships.active, true)))
      .innerJoin(identityLinks, eq(identityLinks.userId, users.id)).where(eq(users.status, "active"));
    res.json(rows.filter((r) => r.role !== "administrator").map((r) => ({ userId: r.userId, label: `${r.role.replaceAll("_", " ")} · ${r.userId}` })));
  }));
  router.get("/practices/:practiceId/records", wrap(async (req, res) => {
    const id = requireUuid(req.params.practiceId);
    const access = await practiceAccess(req, id);
    const kind = req.query.kind;
    if (!["pipeline", "delivery", "goal"].includes(String(kind))) throw new BusinessError(400, "invalid_kind");
    if (access.role === "team_member" && kind === "pipeline") throw new BusinessError(403, "financial_access_denied");
    const { db, businessRecords: table } = await database();
    const rows = await db.select().from(table).where(and(eq(table.practiceId, id), eq(table.kind, kind as "pipeline" | "delivery" | "goal"), isNull(table.deletedAt),
      access.role === "team_member" ? eq(table.assignedUserId, access.userId) : undefined)).orderBy(table.name, table.id);
    res.json(rows.map((row) => serializeRecord(row, access.role)));
  }));
  router.get("/practices/:practiceId/records/:recordId", wrap(async (req, res) => {
    const id = requireUuid(req.params.practiceId);
    const access = await practiceAccess(req, id);
    const row = await findRecord(id, requireUuid(req.params.recordId));
    if (access.role === "team_member" && row.assignedUserId !== access.userId) throw new BusinessError(404, "record_not_found");
    res.json(serializeRecord(row, access.role));
  }));
  router.post("/practices/:practiceId/records", requireCsrf, wrap(async (req, res) => {
    const id = requireUuid(req.params.practiceId);
    const input = parseInput(recordInputSchema, req.body);
    const { db, businessRecords: table } = await database();
    const result = await db.transaction(async (tx) => {
      const access = await practiceAccess(req, id, tx);
      requireWrite(access.role, input.kind);
      await requireAssignee(tx, id, input.assignedUserId);
      const [row] = await tx.insert(table).values({ ...recordValues(input), practiceId: id, organizationId: access.practice.organizationId }).returning();
      await audit(tx, id, access.userId, "create", null, row);
      return serializeRecord(row, access.role);
    });
    res.status(201).json(result);
  }));
  router.patch("/practices/:practiceId/records/:recordId", requireCsrf, wrap(async (req, res) => {
    const id = requireUuid(req.params.practiceId);
    const recordId = requireUuid(req.params.recordId);
    const input = parseInput(updateInputSchema, req.body);
    const { db, businessRecords: table } = await database();
    const result = await db.transaction(async (tx) => {
      const access = await practiceAccess(req, id, tx);
      const before = await findRecord(id, recordId, tx);
      let values;
      if (access.role === "team_member") {
        if (before.kind !== "delivery" || before.assignedUserId !== access.userId || input.record || !input.status) throw new BusinessError(403, "own_status_only");
        values = { status: input.status };
      } else {
        requireWrite(access.role, before.kind);
        if (!input.record || input.status || input.record.kind !== before.kind) throw new BusinessError(422, "invalid_record");
        await requireAssignee(tx, id, input.record.assignedUserId);
        values = recordValues(input.record);
      }
      if (before.version !== input.version) throw new BusinessError(409, "version_conflict");
      const [row] = await tx.update(table).set({ ...values, version: before.version + 1, updatedAt: new Date() })
        .where(and(eq(table.id, recordId), eq(table.practiceId, id), eq(table.version, input.version))).returning();
      if (!row) throw new BusinessError(409, "version_conflict");
      await audit(tx, id, access.userId, "update", before, row);
      return serializeRecord(row, access.role);
    });
    res.json(result);
  }));
  router.delete("/practices/:practiceId/records/:recordId", requireCsrf, wrap(async (req, res) => {
    const id = requireUuid(req.params.practiceId);
    const recordId = requireUuid(req.params.recordId);
    const input = parseInput(deleteInputSchema, req.body);
    const { db, businessRecords: table } = await database();
    await db.transaction(async (tx) => {
      const access = await practiceAccess(req, id, tx);
      const before = await findRecord(id, recordId, tx);
      requireWrite(access.role, before.kind, true);
      if (before.version !== input.version) throw new BusinessError(409, "version_conflict");
      const [row] = await tx.update(table).set({ deletedAt: new Date(), updatedAt: new Date(), version: before.version + 1 }).where(eq(table.id, before.id)).returning();
      await audit(tx, id, access.userId, "delete", before, row);
    });
    res.status(204).end();
  }));
  router.post("/practices/:practiceId/imports", requireCsrf, rateLimit({ windowMs: 60_000, limit: 20 }), wrap(async (req, res) => {
    const id = requireUuid(req.params.practiceId);
    const input = parseInput(importInputSchema, req.body);
    // Hash validated canonical field order, not raw JSON property order.
    const payloadHash = createHash("sha256").update(JSON.stringify(input.rows)).digest("hex");
    const { db, businessRecords, businessImports } = await database();
    const result = await db.transaction(async (tx) => {
      const access = await practiceAccess(req, id, tx);
      requireWrite(access.role, "pipeline");
      // A per-practice advisory lock serializes import receipt checks. The
      // unique partial index also protects against concurrent individual entry.
      await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${id}, 0))`);
      const [receipt] = await tx.select().from(businessImports).where(and(eq(businessImports.practiceId, id), eq(businessImports.actorUserId, access.userId), eq(businessImports.key, input.key)));
      if (receipt) {
        if (receipt.payloadHash !== payloadHash) throw new BusinessError(409, "import_key_reused");
        return receipt.result;
      }
      for (const userId of [...new Set(input.rows.map((row) => row.assignedUserId))].sort()) await requireAssignee(tx, id, userId);
      let inserted = 0;
      for (const inputRow of input.rows) {
        const [row] = await tx.insert(businessRecords).values({ ...recordValues(inputRow), practiceId: id, organizationId: access.practice.organizationId }).onConflictDoNothing().returning();
        if (row) { inserted++; await audit(tx, id, access.userId, "import", null, row); }
      }
      const summary = { inserted, skipped: input.rows.length - inserted };
      await tx.insert(businessImports).values({ practiceId: id, actorUserId: access.userId, key: input.key, payloadHash, result: summary });
      await tx.insert((await database()).businessAudits).values({ practiceId: id, actorUserId: access.userId, action: "import_confirmation", after: summary });
      return summary;
    });
    res.json(result);
  }));
  router.get("/practices/:practiceId/summary", wrap(async (req, res) => {
    const id = requireUuid(req.params.practiceId);
    const access = await practiceAccess(req, id);
    const from = req.query.from, to = req.query.to;
    if (req.query.report !== undefined && !["true", "false"].includes(String(req.query.report))) throw new BusinessError(400, "invalid_report_flag");
    if (access.role === "team_member" && req.query.report === "true") throw new BusinessError(403, "aggregate_reports_denied");
    if ((from !== undefined && (typeof from !== "string" || !validCalendarDate(from))) ||
        (to !== undefined && (typeof to !== "string" || !validCalendarDate(to))) ||
        (typeof from === "string" && typeof to === "string" && from > to)) throw new BusinessError(400, "invalid_date_range");
    const { db, businessRecords: table } = await database();
    const rows = await db.select().from(table).where(and(eq(table.practiceId, id), isNull(table.deletedAt),
      access.role === "team_member" ? eq(table.assignedUserId, access.userId) : undefined,
      access.role === "team_member" ? sql`${table.kind} <> 'pipeline'` : undefined,
      typeof from === "string" ? gte(table.dueDate, from) : undefined, typeof to === "string" ? lte(table.dueDate, to) : undefined));
    res.json({ currency: access.practice.currency, reportingTimeZone: access.practice.reportingTimeZone, ...summarize(rows, access.role === "team_member") });
  }));
  return router;
}

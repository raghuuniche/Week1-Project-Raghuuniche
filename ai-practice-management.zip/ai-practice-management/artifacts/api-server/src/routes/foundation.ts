import { randomBytes } from "node:crypto";
import { Router, type Request } from "express";
import rateLimit from "express-rate-limit";
import { GetAuthStatusResponse, GetFoundationResponse, StartDemoResponse, GetPracticeAccessResponse, GetAdministratorSetupResponse } from "@workspace/api-zod";
import type { AuthConfig } from "../auth/config";
import { DEMO_IDENTITY, DEMO_PRACTICE_ID } from "../auth/identity";
import { authorizePractice, hasGlobalAdministratorGrant } from "../auth/authorization";
import { requireAuthentication, requireCsrf } from "../middlewares/access";

export function createFoundationRouter(config: AuthConfig) {
  const router = Router();
  const status = (req: Request) => {
    req.session.csrfToken ??= randomBytes(32).toString("hex");
    const identity = req.session.identity;
    return {
      mode: config.mode,
      demoAvailable: config.demoAvailable,
      configurationReason: config.reason,
      sessionActive: Boolean(identity),
      csrfToken: req.session.csrfToken,
      displayName: identity?.kind === "demo" ? identity.displayName : identity?.kind === "provider" ? "Signed-in staff" : null,
      role: identity?.kind === "demo" ? identity.role : null,
      practiceId: identity?.kind === "demo" ? identity.practiceId : null,
      administrator: false,
      synthetic: identity?.kind === "demo",
    };
  };
  router.use((_req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    next();
  });
  router.get("/auth/status", rateLimit({ windowMs: 60_000, limit: 120 }), (req, res) => {
    res.json(GetAuthStatusResponse.parse(status(req)));
  });
  router.post("/auth/demo", rateLimit({ windowMs: 60_000, limit: 15, standardHeaders: "draft-8", legacyHeaders: false }), requireCsrf, (req, res, next) => {
    if (!config.demoAvailable) {
      res.status(403).json({ error: "demo_unavailable" });
      return;
    }
    // Rotate both session ID and CSRF token to prevent session fixation.
    req.session.regenerate((error) => {
      if (error) { next(error); return; }
      req.session.identity = { ...DEMO_IDENTITY };
      const payload = StartDemoResponse.parse(status(req));
      req.session.save((saveError) => {
        if (saveError) { next(saveError); return; }
        res.json(payload);
      });
    });
  });
  router.post("/auth/logout", requireCsrf, (req, res, next) => {
    req.session.destroy((error) => {
      if (error) { next(error); return; }
      res.clearCookie(config.mode === "entra" ? "northstar.sid" : "northstar.demo.sid", { httpOnly: true, sameSite: "lax", path: "/api" });
      res.status(204).end();
    });
  });
  router.get("/foundation", requireAuthentication, async (req, res): Promise<void> => {
    const access = await authorizePractice(req.session.identity ?? null, DEMO_PRACTICE_ID);
    if (!access.allowed || !access.synthetic) {
      res.status(403).json({ error: "demo_scope_required" });
      return;
    }
    res.json(GetFoundationResponse.parse({
      practiceName: "AI Practice · Demonstration",
      scope: DEMO_PRACTICE_ID,
      identityVerified: false,
      realDataAccess: false,
      businessModulesEnabled: false,
      administratorAccess: false,
      entraImplemented: false,
    }));
  });
  router.get("/practices/:practiceId/access", requireAuthentication, async (req, res): Promise<void> => {
    const practiceId = req.params.practiceId;
    if (typeof practiceId !== "string" || (practiceId !== DEMO_PRACTICE_ID && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(practiceId))) {
      res.status(400).json({ error: "invalid_practice_id" });
      return;
    }
    const access = await authorizePractice(req.session.identity ?? null, practiceId);
    if (!access.allowed) {
      res.status(403).json({ error: "practice_access_denied", reason: access.reason });
      return;
    }
    res.json(GetPracticeAccessResponse.parse(access));
  });
  router.get("/admin/setup", requireAuthentication, async (req, res): Promise<void> => {
    if (!await hasGlobalAdministratorGrant(req.session.identity ?? null)) {
      res.status(403).json({ error: "administrator_required" });
      return;
    }
    res.json(GetAdministratorSetupResponse.parse({ administrator: true, bootstrap: "Operator-only CLI; no HTTP provisioning is available." }));
  });
  return router;
}
